package tool.com.hsbc.au.db2db;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class DbCopyConfig {
	private static Properties properties = new Properties();
	private static List<String> excludedTables=new ArrayList<String>();
	private static List<String> toBeDeletedTables=new ArrayList<String>();
	private static Map<String, String> partialCopyTables=new HashMap<String, String>();

	
	static {
		InputStream input = null;

		try {

			String filename = "dbcopy.properties";
			input = DbCopyConfig.class.getClassLoader().getResourceAsStream(
					filename);
			if (input == null) {
				System.out.println("Sorry, unable to find " + filename);
				System.exit(1);
			}

			// load a properties file from class path, inside static method
			properties.load(input);
			
			
			// load excluded tables
			input = DbCopyConfig.class.getClassLoader().getResourceAsStream("dbcopy.excluded_tables.properties");
			if (input != null) {
				Properties excludedTablesProperties=new Properties();
				excludedTablesProperties.load(input);
				Enumeration e = excludedTablesProperties.propertyNames();

			    while (e.hasMoreElements()) {
			      String key = (String) e.nextElement();
			      excludedTables.add(key.trim());
			    }
			}
			
			// load toBeDeleted tables
			input = DbCopyConfig.class.getClassLoader().getResourceAsStream("dbcopy.to_be_deleted_tables.properties");
			if (input != null) {
				Properties toBeDeletedTablesProperties=new Properties();
				toBeDeletedTablesProperties.load(input);
				Enumeration e = toBeDeletedTablesProperties.propertyNames();

			    while (e.hasMoreElements()) {
			      String key = (String) e.nextElement();
			      toBeDeletedTables.add(key.trim());
			    }
			}

			// load to be partially loaded tables
			input = DbCopyConfig.class.getClassLoader().getResourceAsStream("dbcopy.partial_copy_tables.properties");
			if (input != null) {
				Properties partialCopyTablesProperties=new Properties();
				partialCopyTablesProperties.load(input);
				Enumeration e = partialCopyTablesProperties.propertyNames();

			    while (e.hasMoreElements()) {
			      String key = (String) e.nextElement();
			      String value=partialCopyTablesProperties.getProperty(key);
			      partialCopyTables.put(key, value);
			    }
			}
			
		} catch (IOException ex) {
			ex.printStackTrace();
			System.exit(1);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static String getSourceDbUrl(){
        return properties.getProperty("source.db.url");
	}
	
	public static String getSourceDbUser(){
        return properties.getProperty("source.db.user");
	}
	
	public static String getSourceDbPassword(){
        return properties.getProperty("source.db.password");
	}
	
	public static String getSourceDbSchema(){
        return properties.getProperty("source.db.schema");
	}
	
	public static String getTargetDbUrl(){
        return properties.getProperty("target.db.url");
	}
	
	public static String getTargetDbUser(){
        return properties.getProperty("target.db.user");
	}
	
	public static String getTargetDbPassword(){
        return properties.getProperty("target.db.password");
	}
	
	public static String getTargetDbSchema(){
        return properties.getProperty("target.db.schema");
	}
	
	public static List<String> getExcludedTables(){
		return excludedTables;
	}
	
	public static List<String> getToBeDeletedTables(){
		return toBeDeletedTables;
	}
	
	public static Map<String, String> getPartialCopyTables(){
		return partialCopyTables;
	}
	


}
