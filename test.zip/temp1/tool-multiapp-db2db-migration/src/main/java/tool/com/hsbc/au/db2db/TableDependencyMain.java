package tool.com.hsbc.au.db2db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

import tool.com.hsbc.au.db2db.util.TableDependencyUtil;

public class TableDependencyMain {
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd-mm.hh.ss.SSSSSS");

	public static void main(String[] argv) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;

		}

		Connection conn1 = null;


		try {
			long start = System.currentTimeMillis();

			// STEP 3: Open a connection
			System.out.println("Connecting to a selected database...");
			/*conn1 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//tkdp2datdbcc13n4-scan.p2g.netd.hk.hsbc:1521/dswift01.hk.hsbc",
							"swft01ua1", "CKENXP_9Y6");
			// conn1 = DriverManager.getConnection(
			// "jdbc:oracle:thin:@//hkpa8ls0015n2-scan.gss3.hk.hsbc:51100/swf01po1.hk.hsbc",
			// "swft01pa1",
			// "knzp+5325");
			conn2 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//tkdp2datdbcc13n4-scan.p2g.netd.hk.hsbc:1521/dswift01.hk.hsbc",
							"mcn01ua1", "CKENXP_9Y6");

			conn1 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//tkdp2datdbcc13n4-scan.p2g.netd.hk.hsbc:1521/dswift01.hk.hsbc",
							"mcn01ua1", "CKENXP_9Y6");
			String sourceSchema = "MCN01UA1";
							*
							*/
			
			/**
source.db.url=jdbc:oracle:thin:@//hkpa8ls0015n2-scan.gss3.hk.hsbc:51100/swf01po1.hk.hsbc
source.db.user=swft01pa1
source.db.password=knzp+5325
source.db.schema=SWFT01PA1
			 */
			
			conn1 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//hkpa8ls0015n2-scan.gss3.hk.hsbc:51100/swf01po1.hk.hsbc",
							"swft01pa1", "knzp+5325");
			String sourceSchema = "SWFT01PA1";

	
			
			// drop all the tables first
			try {
				// get table list
				System.out.println("-------------------------- insert order ");
				List<String> orderedTableNames=TableDependencyUtil.getTableNamesOrderByChildToParent(conn1, sourceSchema, null);
				for (String string : orderedTableNames) {
					System.out.println(string);
					
				}
				
				System.out.println("\n-------------------------- delete order ");
				Collections.reverse(orderedTableNames);
				for (String string : orderedTableNames) {
					System.out.println(string);
					
				}				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(1);
			}


			conn1.close();
			long end = System.currentTimeMillis();

			System.out.println("total amount of time spent:" + (end - start)
					/ 1000 + " seconds");

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
	}

	


}