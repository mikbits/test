package tool.com.hsbc.au.db2db;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import oracle.jdbc.driver.DBConversion;

import org.apache.commons.io.FileUtils;

import tool.com.hsbc.au.db2db.index.IndexUtil;
import tool.com.hsbc.au.db2db.trigger.TriggerUtil;
import tool.com.hsbc.au.db2db.util.TableDependencyUtil;
import tool.com.hsbc.au.db2db.views.ViewUtil;
import de.jcon.dbcopy.DBCommand;
import de.jcon.dbcopy.ProgressMonitor;

public class DbCopyMain {
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd-mm.hh.ss.SSSSSS");

	public static void main(String[] argv) {
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {
			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;
		}

		Connection sourceConnection = null;
		Connection targetConnection = null;

		try {
			long start = System.currentTimeMillis();

			// source DB connection
			System.out.println("Connecting to Source database...");
			sourceConnection = DriverManager.getConnection(
					DbCopyConfig.getSourceDbUrl(),
					DbCopyConfig.getSourceDbUser(),
					DbCopyConfig.getSourceDbPassword());
			
			System.out.println("Source Connection successfully... "+sourceConnection);
			
			// target DB connection
			System.out.println("Connecting to Target database...");
			targetConnection = DriverManager.getConnection(
					DbCopyConfig.getTargetDbUrl(),
					DbCopyConfig.getTargetDbUser(),
					DbCopyConfig.getTargetDbPassword());
			
			System.out.println("Target Connection successfully... "+targetConnection);			

			String sourceSchema = DbCopyConfig.getSourceDbSchema();
			String targetSchema = DbCopyConfig.getTargetDbSchema();

			System.out.println("Copy tables from " + sourceSchema + " to "	+ targetSchema);

			ArrayList<String> manualIndex = null;
			try {
								
				// get existing table list from target DB ordered by parent to child
//				List<String> existingTables = TableDependencyUtil.getTableNamesOrderByParentToChild(targetConnection, targetSchema, null);
//				System.out.println("existingTables " + existingTables);
//
//				for (String targetTableName : existingTables) {
//					// drop all the tables first from target DB
//					System.out.println("drop table " + targetTableName + " .....");
//					
//					DBCommand.dropTable(targetConnection, targetTableName);
//					System.out.println("table dropped " + targetTableName + " ..... completed");
//				}
				
				List<String> existingTables = TableDependencyUtil.getTableNamesOrderByParentToChild(targetConnection, targetSchema, null);
				List<String> toBeDeletedTables =DbCopyConfig.getToBeDeletedTables();
				System.out.println("to be deleted " + toBeDeletedTables);
				if(toBeDeletedTables==null || toBeDeletedTables.size()==0){
					toBeDeletedTables=existingTables;
				}

				for (String targetTableName : toBeDeletedTables) {
					if(existingTables.contains(targetTableName)){
						// drop all the tables first from target DB
						System.out.println("drop table " + targetTableName + " .....");
						
						DBCommand.dropTable(targetConnection, targetTableName);
						System.out.println("table dropped " + targetTableName + " ..... completed");
					}
				}
						
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}

			System.out.println("###########################################################################");

			try {
				
				System.out.println("find out all the tables in "+sourceSchema);
				List<String> tablesToBeCopied=TableDependencyUtil.getTableNamesOrderByChildToParent(sourceConnection, sourceSchema, DbCopyConfig.getExcludedTables());
				System.out.println("tables to be copied:"+tablesToBeCopied);
				Map<String, String> partialCopyTables = DbCopyConfig.getPartialCopyTables();
				
				String targetSID = DbCopyConfig.getTargetDbUrl();	// jdbc:oracle:thin:@//133.10.240.50:1522/gl.hk.hsbc
				targetSID = targetSID.substring(targetSID.lastIndexOf("@//") + 3);

				// generating triggers
				StringBuffer triggerBatchFileContents = new StringBuffer();

				triggerBatchFileContents.append("set SQLPLUS_HOME=C:\\ORACLE\\ORACLE_1120\\product\\11.2.0\\client_1\\bin").append("\n");
				triggerBatchFileContents.append("set ORACLE_USER=").append(DbCopyConfig.getTargetDbUser()).append("\n");
				triggerBatchFileContents.append("set ORACLE_PWD=").append(DbCopyConfig.getTargetDbPassword()).append("\n");
				
			
				triggerBatchFileContents.append("set ORACLE_SID=").append(targetSID).append("\n");
				triggerBatchFileContents.append("set SCRIPT_DIR=%~dp0").append("\n");
				
				for (int i = 0; i < tablesToBeCopied.size(); i++) {
					System.out.println("###########################################################################");
					/*
					Runtime runtime = Runtime.getRuntime();
				    long total = runtime.totalMemory();
				    long free = runtime.freeMemory();
				    long max = runtime.maxMemory();
				    long used = total - free;   
				    System.out.println(Math.round(max / 1e6) + " MB available before Cycle");
				    System.out.println(Math.round(total / 1e6) + " MB allocated before Cycle");
				    System.out.println(Math.round(free / 1e6) + " MB free before Cycle");
				    System.out.println(Math.round(used / 1e6) + " MB used before Cycle");
				    */
					String sourceTableName = tablesToBeCopied.get(i);
					System.out.println("Copy " + sourceTableName + " .....");

					boolean createTables = true;
					boolean dropFirst = false;
					boolean createForeignKeyConstraint = true;
					int maxErrors = 1;
					ProgressMonitor aMonitor = null;
					String apostrophe = "\"";
					boolean partialCopy = false;
					int partialCopyLimit = 0;
					String partialCopyCriteria = "DESC";
					
					boolean copyData=true;
					if(partialCopyTables.containsKey(sourceTableName)){						
						String partialCopyConfig = partialCopyTables.get(sourceTableName);
						if(partialCopyConfig.indexOf(":")>0){
							partialCopyLimit=new Integer(partialCopyConfig.substring(0,partialCopyConfig.indexOf(":")));
							partialCopyCriteria=partialCopyConfig.substring(partialCopyConfig.indexOf(":"+1));
						}else{
							partialCopyLimit=new Integer(partialCopyConfig.trim());
						}
						
						partialCopy =  true;
						if(partialCopyLimit==0){
							copyData=false;
						}
				      }
					
					DBCommand.copy(sourceConnection, sourceSchema,
							targetConnection, targetSchema, sourceTableName,
							createTables, dropFirst, copyData,
							createForeignKeyConstraint, maxErrors, aMonitor,
							apostrophe, partialCopy, partialCopyLimit, partialCopyCriteria);
					
					
					StringBuffer triggers = TriggerUtil.getTrigger(sourceConnection, sourceSchema, sourceTableName,TRIGGERS_TO_BE_REMOVED);
					String triggerSqlFileName = "trigger_" + sourceTableName+ ".sql";
					FileUtils.writeStringToFile(new File("output/triggers/"+triggerSqlFileName),triggers.toString());
					System.out.println("Copy " + sourceTableName + " ..... completed");
					triggerBatchFileContents
							.append("%SQLPLUS_HOME%\\sqlplus -s %ORACLE_USER%/%ORACLE_PWD%@\\\"%ORACLE_SID%\\\" @\"%SCRIPT_DIR%")
							.append(triggerSqlFileName).append("\"\n");
				}
				
				// create trigger batch file
				String triggerBatchFileName = "output/triggers/"+targetSchema+"-add-triggers.bat";
				FileUtils.writeStringToFile(new File(triggerBatchFileName),triggerBatchFileContents.toString());
				
				
				//generating manual index
				manualIndex = IndexUtil.getManualIndices(sourceConnection);
				if(manualIndex != null){
					IndexUtil.createManualIndices(sourceConnection, sourceSchema, manualIndex);
					
					StringBuffer indexBatchFileContents = new StringBuffer();				

					indexBatchFileContents.append("set SQLPLUS_HOME=C:\\ORACLE\\ORACLE_1120\\product\\11.2.0\\client_1\\bin").append("\n");
					indexBatchFileContents.append("set ORACLE_USER=").append(DbCopyConfig.getTargetDbUser()).append("\n");
					indexBatchFileContents.append("set ORACLE_PWD=").append(DbCopyConfig.getTargetDbPassword()).append("\n");
					
					indexBatchFileContents.append("set ORACLE_SID=").append(targetSID).append("\n");
					indexBatchFileContents.append("set SCRIPT_DIR=%~dp0").append("\n");
					
					for(String index : manualIndex){
						if(!index.contains("$")){
						indexBatchFileContents
						.append("%SQLPLUS_HOME%\\sqlplus -s %ORACLE_USER%/%ORACLE_PWD%@\\\"%ORACLE_SID%\\\" @\"%SCRIPT_DIR%")
						.append(index).append(".sql").append("\"\n");
						}
					}				

					String indexBatchFileName = "output/indices/"+targetSchema+"-add-index.bat";
					FileUtils.writeStringToFile(new File(indexBatchFileName),indexBatchFileContents.toString());
				}
				
				// generating views	
				System.out.println("###########################################################################");
				System.out.println("Generating Views");
				
				List<String> viewsInTargetDB= ViewUtil.getViewList(targetConnection,sourceSchema);
				
				System.out.println("Existing Views: "	+ viewsInTargetDB);
				
				for (String viewName : viewsInTargetDB) {
					// drop all the views first from target DB
					System.out.println("drop view " + viewName + " .....");
					
					DBCommand.dropView(targetConnection, viewName);
					System.out.println("view dropped " + viewName + " ..... completed");
				}
				
				StringBuffer viewBatchFileContents = new StringBuffer();				

				viewBatchFileContents.append("set SQLPLUS_HOME=C:\\ORACLE\\ORACLE_1120\\product\\11.2.0\\client_1\\bin").append("\n");
				viewBatchFileContents.append("set ORACLE_USER=").append(DbCopyConfig.getTargetDbUser()).append("\n");
				viewBatchFileContents.append("set ORACLE_PWD=").append(DbCopyConfig.getTargetDbPassword()).append("\n");
				
				viewBatchFileContents.append("set ORACLE_SID=").append(targetSID).append("\n");
				viewBatchFileContents.append("set SCRIPT_DIR=%~dp0").append("\n");
			
				List<String> viewUtil= ViewUtil.getView(sourceConnection,sourceSchema);
				for(String view : viewUtil){
					viewBatchFileContents
					.append("%SQLPLUS_HOME%\\sqlplus -s %ORACLE_USER%/%ORACLE_PWD%@\\\"%ORACLE_SID%\\\" @\"%SCRIPT_DIR%")
					.append(view).append("\"\n");		
				}				

				String viewBatchFileName = "output/views/"+targetSchema+"-add-views.bat";
				FileUtils.writeStringToFile(new File(viewBatchFileName),viewBatchFileContents.toString());


			} catch (Exception e) {
				e.printStackTrace();
			}

			targetConnection.close();
			sourceConnection.close();
			long end = System.currentTimeMillis();

			System.out.println("total amount of time spent:" + (end - start)/ 1000 + " seconds");

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
	}
	
	


	public static String[] TRIGGERS_TO_BE_REMOVED = { "SECSAVINGSDEPOSITS" };



}