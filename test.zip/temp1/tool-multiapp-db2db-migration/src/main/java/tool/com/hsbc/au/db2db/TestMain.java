package tool.com.hsbc.au.db2db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import de.jcon.dbcopy.AppLogger;
import de.jcon.dbcopy.DBCommand;
import de.jcon.dbcopy.ProgressMonitor;
import tool.com.hsbc.au.db2db.util.TableDependencyUtil;

public class TestMain {
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd-mm.hh.ss.SSSSSS");

	public static void main(String[] argv) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;

		}

		Connection conn1 = null;


		try {
			long start = System.currentTimeMillis();

			// STEP 3: Open a connection
			System.out.println("Connecting to a selected database...");
			/*conn1 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//tkdp2datdbcc13n4-scan.p2g.netd.hk.hsbc:1521/dswift01.hk.hsbc",
							"swft01ua1", "CKENXP_9Y6");
			// conn1 = DriverManager.getConnection(
			// "jdbc:oracle:thin:@//hkpa8ls0015n2-scan.gss3.hk.hsbc:51100/swf01po1.hk.hsbc",
			// "swft01pa1",
			// "knzp+5325");
			conn2 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//tkdp2datdbcc13n4-scan.p2g.netd.hk.hsbc:1521/dswift01.hk.hsbc",
							"mcn01ua1", "CKENXP_9Y6");

			conn1 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//tkdp2datdbcc13n4-scan.p2g.netd.hk.hsbc:1521/dswift01.hk.hsbc",
							"mcn01ua1", "CKENXP_9Y6");
			String sourceSchema = "MCN01UA1";
							*
							*/
			
			/**
source.db.url=jdbc:oracle:thin:@//hkpa8ls0015n2-scan.gss3.hk.hsbc:51100/swf01po1.hk.hsbc
source.db.user=swft01pa1
source.db.password=knzp+5325
source.db.schema=SWFT01PA1
			 */
			
			conn1 = DriverManager
					.getConnection(
							"jdbc:oracle:thin:@//hkpa8ls0015n2-scan.gss3.hk.hsbc:51100/swf01po1.hk.hsbc",
							"swft01pa1", "knzp+5325");
			String sourceSchema = "SWFT01PA1";

	
			
			// drop all the tables first
			try {
				// get table list
//				TestMain.getTableList(conn1, sourceSchema, null);
				
				TestMain.test(conn1, sourceSchema, "MULTI_CONTACT_DETAILS");
//				List<String> orderedTableNames=TableDependencyUtil.getTableNamesOrderByChildToParent(conn1, sourceSchema, null);
//				for (String string : orderedTableNames) {
//					System.out.println(string);
//					
//				}
//				
//				System.out.println("--------------------------");
//				Collections.reverse(orderedTableNames);
//				for (String string : orderedTableNames) {
//					System.out.println(string);
//					
//				}				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(1);
			}


			conn1.close();
			long end = System.currentTimeMillis();

			System.out.println("total amount of time spent:" + (end - start)
					/ 1000 + " seconds");

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
	}
	
	public static void test(Connection aSourceCon,
			String aSourceSchema, String tableName) throws SQLException {
		DatabaseMetaData theMetaData = aSourceCon.getMetaData();

		ResultSet aSet = theMetaData.getImportedKeys(null,aSourceSchema, tableName);
		System.out.println("select * from "+ tableName+" where ");
		
		while (aSet.next()) {
			String aTableName = aSet.getString("PKTABLE_NAME");
			String aColumnName=aSet.getString("PKCOLUMN_NAME");
			String currentColumnName=aSet.getString("FKCOLUMN_NAME");
			System.out.println(currentColumnName+" in (select "+aColumnName+" from "+aTableName+")");
		}
	}

	public static String[] getTableList(Connection aSourceCon,
			String aSourceSchema, ProgressMonitor monitor) throws SQLException {
		DatabaseMetaData theMetaData = aSourceCon.getMetaData();
		ResultSet aSet = theMetaData.getTables(aSourceCon.getCatalog(),
				aSourceSchema, null, new String[] { "TABLE" });
		Vector aTemp = new Vector();
		if (monitor != null)
			monitor.beginTask("Reading Tables", 100);

		int nRows = 0;
		String aTableName = null;

		while (aSet.next()) {
			aTableName = aSet.getString("TABLE_NAME");
			aTemp.addElement(aTableName);

			if ((nRows < 100) && (monitor != null)) {
				monitor.worked(++nRows);
			}
		}

		if (monitor != null)
			monitor.done();

		String[] aTableList = null;
		aTableList = (String[]) aTemp.toArray(new String[aTemp.size()]);

		return aTableList;
	}
	
	private static String getForeignKeyConstraints(Connection rSrcConnection,
			ResultSetMetaData rSrcRSMeta, String sSourceSchema,
			String sTargetSchema, String sTable) throws SQLException {
		DatabaseMetaData rDBMeta = rSrcConnection.getMetaData();
		StringBuffer aResult = new StringBuffer();
		String sCatalog = rSrcConnection.getCatalog();

		// String sSchema = rSrcRSMeta.getSchemaName(1);
		String sSchema = sSourceSchema;

		// String sTable = rSrcRSMeta.getTableName(1);
		int attempt = 1;
		int nPos = 0;
		int aFullCount = 0;
		int aHitCount = 0;

		/**
		 * DOCUMENT ME!
		 * 
		 * @author $author$
		 * @version $Revision: 1.14 $
		 */
		class ForeignKeyData {
			String sExtTable = null;

			Vector aColumns = null;
		}

		/*
		 * if ((nPos = sTable.indexOf(".")) >= 0) { sSchema =
		 * sTable.substring(0, nPos); sTable = sTable.substring(nPos + 1); }
		 * else if (sSchema.length() == 0) { //sSchema = null; sSchema = ""; }
		 */
		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable
						+ "] Retrieve FK for Catalog: " + sCatalog
						+ " Schema: " + sSchema + " Table: " + sTable);

		ResultSet aSet = rDBMeta.getImportedKeys(sCatalog, sSchema, sTable);
		Map aKeyMap = new HashMap();

		while (aSet.next()) {
			aFullCount++;

			int nKeySeq = aSet.getInt("KEY_SEQ");
			String sKeyName = aSet.getString("FK_NAME");

			ForeignKeyData aFKData = (ForeignKeyData) aKeyMap.get(sKeyName);

			if (aFKData == null) {
				aFKData = new ForeignKeyData();
				aFKData.aColumns = new Vector();
				aKeyMap.put(sKeyName, aFKData);
			}

			if (nKeySeq > aFKData.aColumns.size()) {
				aFKData.aColumns.setSize(nKeySeq);
			}

			if (aFKData.sExtTable == null) {
				aFKData.sExtTable = aSet.getString("PKTABLE_NAME");
			}

			String sExtCol = aSet.getString("PKCOLUMN_NAME");
			String sCol = aSet.getString("FKCOLUMN_NAME");
			aFKData.aColumns.set(nKeySeq - 1, new String[] { sCol, sExtCol });
		}

		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] has " + aFullCount
						+ " FK references.");

		Iterator aKeyMapIter = aKeyMap.values().iterator();

		while (aKeyMapIter.hasNext()) {
			aHitCount++;

			ForeignKeyData aFKData = (ForeignKeyData) aKeyMapIter.next();

			if (aFKData.aColumns.size() > 0) {
				StringBuffer aReferencesPart = new StringBuffer();

				aResult.append("foreign key (");
				aReferencesPart.append(" references " + sTargetSchema + "."
						+ aFKData.sExtTable + " (");

				for (int i = 0; i < aFKData.aColumns.size(); i++) {
					if (i > 0) {
						aResult.append(",");
						aReferencesPart.append(",");
					}

					String[] aColumns = (String[]) aFKData.aColumns.get(i);
					aResult.append(aColumns[0]);
					aReferencesPart.append(aColumns[1]);
				}

				aResult.append(")");
				aReferencesPart.append(")");
				aResult.append(aReferencesPart);
			}

			if (aKeyMapIter.hasNext()) {
				aResult.append('|');
			}
		}

		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] used " + aHitCount
						+ " FK references for table statement.");

		String aResultString = aResult.toString();
		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] FK statement: "
						+ aResultString);

		System.out.print(aResultString);
		return aResultString;
	}


}