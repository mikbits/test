package tool.com.hsbc.au.db2db.trigger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TriggerUtil {

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param String
	 *            aDBConnection
	 * 
	 * @return DOCUMENT ME!
	 * 
	 * @throws Exception
	 *             DOCUMENT ME!
	 **************************************************************************/
	public static StringBuffer getTrigger(Connection aConnection,
			String aSchema, String aTableName,String[] trigersToBeRemoved) throws SQLException,
			ClassNotFoundException {
		
		StringBuffer result=new StringBuffer();
		String aSelectStmt="select * from user_triggers where table_name='"+aTableName+"'";
		Statement aSelectStmtObj = aConnection.createStatement();
		aSelectStmtObj.setFetchSize(1000);
		ResultSet aSet = aSelectStmtObj.executeQuery(aSelectStmt);

			try {
				while (aSet.next()) {
					String triggerName=aSet.getString("TRIGGER_NAME");
					if(trigersToBeRemoved!=null && trigersToBeRemoved.length>0){
						for (int i = 0; i < trigersToBeRemoved.length; i++) {
							if(triggerName.equalsIgnoreCase(trigersToBeRemoved[i])){
								result.append("QUIT;\n");
								continue;
							}
						}
					}
					String triggerEvent=aSet.getString("TRIGGERING_EVENT");
					String triggerBody=aSet.getString("TRIGGER_BODY");
					String referenceNames=aSet.getString("REFERENCING_NAMES");
					String triggerType=aSet.getString("TRIGGER_TYPE");
					String triggerTypePrefix=triggerType.substring(0,triggerType.indexOf(" "));
					String triggerTypeSurfix=triggerType.substring(triggerType.indexOf(" ")+1);
					
					result.append("CREATE OR REPLACE TRIGGER ").append(triggerName).append("\n");
					result.append(triggerTypePrefix).append(" ").append(triggerEvent).append("\n");
					result.append("ON ").append(aTableName).append("\n");
					result.append(referenceNames).append("\n");
					result.append("FOR ").append(triggerTypeSurfix).append("\n");
					result.append(triggerBody).append("\n");
					result.append("/").append("\n");
					result.append("ALTER TRIGGER ").append(triggerName).append(" ENABLE;").append("\n");
				}
				result.append("QUIT;\n");
			} finally {
				if (aSet != null) {
					aSet.close();
				}
			}


		return result;
	}

}
