package tool.com.hsbc.au.db2db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import de.jcon.dbcopy.DBCommand;

public class DbTableDeleteMain {
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd-mm.hh.ss.SSSSSS");

	public static void main(String[] argv) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;

		}

		Connection conn2 = null;

		try {
			long start = System.currentTimeMillis();

			// STEP 3: Open a connection
			System.out.println("Connecting to a selected database...");
			conn2 = DriverManager
					.getConnection(DbCopyConfig.getTargetDbUrl(),DbCopyConfig.getTargetDbUser(),DbCopyConfig.getSourceDbPassword());
			System.out.println("Connected database successfully...");

			String sourceSchema = DbCopyConfig.getSourceDbSchema();
			String targetSchema = DbCopyConfig.getTargetDbSchema();

			System.out.println("Copy tables from "+sourceSchema +" to "+targetSchema);			
			
			// drop all the tables first
			try {
				// get table list
				String[] existingTables = DBCommand.getTableList(conn2,
						targetSchema, null);

				for (int i = 0; i < TABLES_TO_BE_DELETED.length; i++) {
					String sourceTableName = TABLES_TO_BE_DELETED[i];
					boolean found = false;
					for (int j = 0; j < existingTables.length; j++) {
						if (existingTables[j].equalsIgnoreCase(sourceTableName)) {
							found = true;
							break;
						}
					}
					if (found) {
						System.out.println("drop table " + sourceTableName
								+ " .....");
						DBCommand.dropTable(conn2, sourceTableName);
						System.out.println("drop table " + sourceTableName
								+ " ..... completed");
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(1);
			}

			
			// conn2.commit();
			conn2.close();
			long end = System.currentTimeMillis();

			System.out.println("total amount of time spent:" + (end - start)
					/ 1000 + " seconds");

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
	}
	
//	public static String[] TRIGGERS_TO_BE_REMOVED={
//		"SECSAVINGSDEPOSITS"
//	};

	
	// delete table should be in right order; otherwise the foreign key constrain will fail table deletion
	public static String[] TABLES_TO_BE_DELETED = {

// ---- RALF Tables ----
//		"RALF_ACCESS_CONTROL",
//		"RALF_BRANCH",
//		"RALF_LEAD",
//		"RALF_CUSTOMER",
//		"RALF_ADDRESS",
//		"RALF_USER_ATTRIBUTE",
//		"RALF_USER",
//		"MO_MERCHANT_GROUP", 
//		"MO_STORE",
		
// ---- HORAS Tables ----
//		"TB_MULTIAPP_ADDRESS",
//		"TB_MULTIAPP_APPLICANT",
//		"TB_MULTIAPP_APPLICATION",
//		"TB_MULTIAPP_BELL_AUDIT",
//		"TB_MULTIAPP_CDM_DECISION_AUDIT",
//		"TB_MULTIAPP_COUNTRY",
//		"TB_MULTIAPP_EMAIL_AUDIT",
//		"TB_MULTIAPP_EVID_AUDIT",
//		"TB_MULTIAPP_GENERAL_LOOKUP",
//		"TB_MULTIAPP_HUB_DECISION_AUDIT",
//		"TB_MULTIAPP_INTEREST_RATE",
//		"TB_MULTIAPP_MANUAL_ID_AUDIT",
//		"TB_MULTIAPP_STAFFLOG_DETAILS",
//		"TB_MULTIAPP_CUSTOMER_CAMPAIGN",
//		"TB_MULTIAPP_RATES"		
		
//		"TB_MULTIAPP_SETTLEMENT",
//		"TB_MULTIAPP_SETTLEMENT_OUT",
//		"TB_MULTIAPP_SETTLEMENT_REF",
//		"TB_MULTIAPP_SETTLEMENT_TEMP",
//		"TEMP_INTEREST_RATES_DATA",
//		"WF_ACCESS_CONTROL",
//		"WF_DUMMY_RESPONSE",
//		"WF_MAPS_DATA_TEMP",
//		"WF_MAPS_REQ_DATA_TEMP",
//		"WF_NEWS_ATTACHMENT",
//		"WF_USERLOG_DETAILS",
//		"MO_MERCHANT_GROUP",
//		"MO_PROMOTION",
//		"MO_STORE",
//		"TB_MULTIAPP_ADDON",
//		"TB_MULTIAPP_APP_AUDIT",
//		"WF_BOOKLET_ID",
//		"WF_DOC",
//		"WF_FIS_DATA_TEMP",
//		"WF_FIS_FILE_MONITOR",
//		"WF_MAPS_FILE_MONITOR",
//		"WF_MERCHANT_NOTES",
//		"WF_NEWS",
//		"WF_RCTI_TEMP",
//		"WF_USER",
//		"WF_USER_PSW_HISTORY",
//		"WF_USER_ROLES",
//		"TB_MULTIAPP_CITYNET_REC",
		
		"RALF_USER_TEAM",
		"RALF_ACCESS_CONTROL",
		"RALF_TEAM2",
		"RALF_TEAM1",
		"RALF_BRANCH",
		"RALF_LEAD",
		"RALF_CUSTOMER",
		"RALF_ADDRESS",
		"RALF_USER_ATTRIBUTE",
		"RALF_USER",
		"RALF_REFERAL",
		"RALF_NOTE",
		


		"MO_MERCHANT_GROUP", 
		"MO_STORE", 
		"TB_MULTIAPP_ADDRESS",
		"TB_MULTIAPP_APPLICANT",
		"TB_MULTIAPP_APPLICATION",
		"TB_MULTIAPP_BELL_AUDIT",
		"TB_MULTIAPP_CDM_DECISION_AUDIT",
		"TB_MULTIAPP_COUNTRY",
		"TB_MULTIAPP_EMAIL_AUDIT",
		"TB_MULTIAPP_EVID_AUDIT",
		"TB_MULTIAPP_GENERAL_LOOKUP",
		"TB_MULTIAPP_HUB_DECISION",
		"TB_MULTIAPP_HUB_DECISION_AUDIT",
		"TB_MULTIAPP_INTEREST_RATE",
		"TB_MULTIAPP_RATES",				
		"TB_MULTIAPP_MANUAL_ID_AUDIT",
		"TB_MULTIAPP_STAFFLOG_DETAILS",
		"TB_MULTIAPP_CUSTOMER_CAMPAIGN",
		"TB_MULTIAPP_MAPSDECISION",
		"TB_MULTIAPP_MAPSDECISION_AUDIT",
		"TB_MULTIAPP_APP_AUDIT",
		"TB_MULTIAPP_CUSTOMER",
		"TB_MULTIAPP_CONTACT_AUDIT",
		"TB_MULTI_HOMELOAN_RESULT_AUDIT",
		"TB_MULTI_HOMELOAN_RESULT",
		"MULTI_CUSTOMER_ASSET",
		"MULTI_CUSTOMER",
		"MULTI_HOMELOAN_RESULT_AUDIT",
		"MULTI_HOMELOAN_RESULT",
		"MULTI_HOMELOAN",
		"MULTI_HUBDECISION_AUDIT",
		"MULTI_HUBDECISION",
		"MULTI_MAPSDECISION_AUDIT",
		"MULTI_MAPSDECISION",
		"MULTI_CONTACT_DETAILS",
		"MULTI_CONTACT_AUDIT",
		"MULTI_DOCUPLOAD_DETAILS",
		"MULTI_DOCUPLOAD_AUDIT"
			};


}