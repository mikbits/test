package tool.com.hsbc.au.db2db.views;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class ViewUtil {

	public static List<String> getView(Connection aConnection, String sourceSchema) throws SQLException, ClassNotFoundException {

		List<String> viewSqlFileName = new ArrayList<String>();
		List<String> viewList = new ArrayList<String>();
		String query = "select * from user_views";

		ResultSet viewResult = null;
		ResultSet viewResultSet = null;
		try {
			Statement aSelectStmtObj = aConnection.createStatement();
			viewResult = aSelectStmtObj.executeQuery(query);
			while (viewResult.next()) {
				String viewName = viewResult.getString("VIEW_NAME");
				viewList.add(viewName);
			}

			for (String viewName : viewList) {

				String omitSchemaQuery = "begin dbms_metadata.set_transform_param (dbms_metadata.session_transform,'EMIT_SCHEMA',false); end;";
				Statement st = aConnection.createStatement();
				st.executeUpdate(omitSchemaQuery);

				String viewQuery = "SELECT DBMS_METADATA.get_ddl('VIEW','"+ viewName + "') from dual";

				Statement selectStmtObj = aConnection.createStatement();
				viewResultSet = selectStmtObj.executeQuery(viewQuery);
				while (viewResultSet.next()) {
					StringBuffer result = new StringBuffer();
					String view = viewResultSet.getString(1);
					view = view.replaceAll(sourceSchema+".", "").replaceAll("[\n]{2,}", "\n");					
					result.append(view).append("\n");
					result.append("/\n");
					result.append("QUIT;\n");
					viewSqlFileName.add(viewName + ".sql");
					FileUtils.writeStringToFile(new File("output/views/" + viewName + ".sql"),
							result.toString());
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (viewResult != null) {
				viewResult.close();
			}
		}
		return viewSqlFileName;
	}
	public static List<String> getViewList(Connection aConnection, String sourceSchema) throws SQLException, ClassNotFoundException {

		List<String> viewList = new ArrayList<String>();
		String query = "select * from user_views";

		ResultSet viewResult = null;
		try {
			Statement aSelectStmtObj = aConnection.createStatement();
			viewResult = aSelectStmtObj.executeQuery(query);
			while (viewResult.next()) {
				String viewName = viewResult.getString("VIEW_NAME");
				viewList.add(viewName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (viewResult != null) {
				viewResult.close();
			}
		}
		return viewList;
	}

}
