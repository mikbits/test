package tool.com.hsbc.au.db2db.util;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TableDependencyUtil {
	
	public static List<String> getTableNamesOrderByParentToChild(Connection aSourceCon,
			String aSourceSchema, List<String> tablesToBeExcluded) throws SQLException {
		List<String> tableNames=getTableNamesOrderByChildToParent(aSourceCon, aSourceSchema, tablesToBeExcluded);
		Collections.reverse(tableNames);
		return tableNames;
	}
	
	public static List<String> getTableNamesOrderByChildToParent(Connection aSourceCon,
			String aSourceSchema, List<String> toBeExcludedTableList) throws SQLException {
		DatabaseMetaData theMetaData = aSourceCon.getMetaData();
		ResultSet aSet = theMetaData.getTables(aSourceCon.getCatalog(),
				aSourceSchema, null, new String[] { "TABLE" });
		
		if(toBeExcludedTableList==null){
			toBeExcludedTableList=new ArrayList<String>();
		}


		// get all the table names
		List<String> allTableNames = new ArrayList<String>();
		String aTableName = null;
		while (aSet.next()) {
			aTableName = aSet.getString("TABLE_NAME");
			if(!toBeExcludedTableList.contains(aTableName)){
				allTableNames.add(aTableName);
			}
		}
		
		// get the dependency for each 
		List<String> resolvedTableNames=new ArrayList<String>();
		Map<String, List<String>> pendingTables=new HashMap<String, List<String>>();
		for (String tableName : allTableNames) {
			List<String> dependentTables=getDependentTables(aSourceCon, aSourceSchema, tableName);
			if(dependentTables==null || dependentTables.size()==0){
				resolvedTableNames.add(tableName);
			} else {

				pendingTables.put(tableName,dependentTables);

			}
		}

	
	
		Map<String, List<String>> newPendingTables=new HashMap<String, List<String>>();
		while(pendingTables.size()>0){
			newPendingTables=new HashMap<String, List<String>>();
			for (Map.Entry<String,  List<String>> entry : pendingTables.entrySet()){
				List<String> dependentTables=entry.getValue();
				for (String resolvedTableName : resolvedTableNames) {
					if(dependentTables.contains(resolvedTableName)){
						dependentTables.remove(resolvedTableName);
					}
				}
				
				// remove dependencies according to excluded tables
				for (String toBeExcludedTable :toBeExcludedTableList) {
					if(dependentTables.contains(toBeExcludedTable)){
						dependentTables.remove(toBeExcludedTable);
					}
				}
				
				if(dependentTables.size()==0){
					// all resolved
					resolvedTableNames.add(entry.getKey());
				}else{
					// carry to new pending tables
					newPendingTables.put(entry.getKey(), dependentTables);
				}
			}
			
			pendingTables=newPendingTables;
		}


		return resolvedTableNames;
	}
	
	public static List<String> getDependentTables(Connection aSourceCon,
			String aSourceSchema, String sTable) throws SQLException {
		DatabaseMetaData theMetaData = aSourceCon.getMetaData();		
		
		// for each of the table, find its foreign key dependencies
		String sCatalog = aSourceCon.getCatalog();
		ResultSet aSet = theMetaData.getImportedKeys(sCatalog, aSourceSchema, sTable);
		List<String> dependencyTables=new ArrayList<String>();
		while (aSet.next()) {
			String sExtTable = aSet.getString("PKTABLE_NAME");
			dependencyTables.add(sExtTable);
		}	
		return dependencyTables;
		
	}

}
