package tool.com.hsbc.au.db2db.index;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class IndexUtil {
	
	public static void createManualIndices(Connection aConnection, String sourceSchema, ArrayList<String> manualIndex) throws SQLException, ClassNotFoundException {
		
		List<String> indexSqlFileName = new ArrayList<String>();
		ResultSet indexResult = null;
		ResultSet indexResultSet = null;
		try {
				for (String mi : manualIndex) {
		
					String omitSchemaQuery = "begin dbms_metadata.set_transform_param (dbms_metadata.session_transform,'EMIT_SCHEMA',false); end;";
					Statement st = aConnection.createStatement();
					st.executeUpdate(omitSchemaQuery);
		
					String viewQuery = "SELECT DBMS_METADATA.get_ddl('INDEX','"+ mi + "') from dual";
		
					Statement selectStmtObj = aConnection.createStatement();
					indexResult = selectStmtObj.executeQuery(viewQuery);
					while (indexResult.next()) {
						StringBuffer result = new StringBuffer();
						String index = indexResult.getString(1);
						index = index.replaceAll(sourceSchema+".", "").replaceAll("[\n]{2,}", "\n");
						if (index.contains("PCTFREE")){
							index = index.substring(0, index.indexOf("PCTFREE")); 
						}
						result.append(index).append("\n");
						result.append("/\n");
						result.append("QUIT;\n");
						indexSqlFileName.add(mi + ".sql");
						FileUtils.writeStringToFile(new File("output/indices/" + mi + ".sql"),
								result.toString());
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (indexResultSet != null) {
					indexResultSet.close();
				}
			}
		
	}
	
	public static ArrayList<String> getManualIndices(Connection aConnection) throws SQLException, ClassNotFoundException {

		ArrayList<String> manualIndex = new ArrayList<String>();
		ArrayList<String> tableList = new ArrayList<String>();
		ArrayList<String> indexList = new ArrayList<String>();
		ArrayList<String> primaryIndexList = new ArrayList<String>();
		String query = "select * from user_tables";

		ResultSet tableResult = null;
		ResultSet indexResult = null;
		ResultSet viewResultSet = null;
		ResultSet primaryIndexResult = null;
		try {
			Statement aSelectStmtObj = aConnection.createStatement();
			tableResult = aSelectStmtObj.executeQuery(query);
			while (tableResult.next()) {
				String viewName = tableResult.getString("TABLE_NAME");
				tableList.add(viewName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (tableResult != null) {
				tableResult.close();
			}
		}
		
		System.out.println("Table List "+ tableList);
		
		query = "select TABLE_NAME, INDEX_NAME from USER_INDEXES order by TABLE_NAME asc";
		
		try {
			Statement aSelectStmtObj = aConnection.createStatement();
			indexResult = aSelectStmtObj.executeQuery(query);
			while (indexResult.next()) {
				String indexName = indexResult.getString("INDEX_NAME");
				indexList.add(indexName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (indexResult != null) {
				indexResult.close();
			}
		}
		
		System.out.println("Index List " + indexList);
		
		StringBuilder out = new StringBuilder();
		for (Object o : tableList)
		{
		  out.append("'");
		  out.append(o.toString());
		  out.append("'");
		  out.append(",");
		}
		System.out.println( "Index List with comma and quotes" + out.toString());
		
		query = "select table_name, constraint_name, constraint_type, index_name from user_constraints where constraint_type='P' and table_name in ("+out.toString().substring(0, out.toString().length()-1)+")";
		
		try {
			Statement aSelectStmtObj = aConnection.createStatement();
			primaryIndexResult = aSelectStmtObj.executeQuery(query);
			while (primaryIndexResult.next()) {
				String indexName = primaryIndexResult.getString("INDEX_NAME");
				primaryIndexList.add(indexName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (primaryIndexResult != null) {
				primaryIndexResult.close();
			}
		}
		
		System.out.println("Primary Index List " + primaryIndexList);
		indexList.removeAll(primaryIndexList);
		System.out.println("Difference Index List " + indexList);
		
		return indexList;
	}
}
