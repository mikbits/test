package tool.com.hsbc.au.db2db;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import tool.com.hsbc.au.db2db.trigger.TriggerUtil;
import tool.com.hsbc.au.db2db.util.SequenceUtil;
import tool.com.hsbc.au.db2db.util.TableDependencyUtil;
import tool.com.hsbc.au.db2db.views.ViewUtil;
import de.jcon.dbcopy.DBCommand;
import de.jcon.dbcopy.ProgressMonitor;

public class SequenceCopyMain {
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd-mm.hh.ss.SSSSSS");

	public static void main(String[] argv) {
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {
			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;
		}

		Connection sourceConnection = null;
		Connection targetConnection = null;

		try {
			long start = System.currentTimeMillis();

			// source DB connection
			System.out.println("Connecting to Source database...");
			sourceConnection = DriverManager.getConnection(
					DbCopyConfig.getSourceDbUrl(),
					DbCopyConfig.getSourceDbUser(),
					DbCopyConfig.getSourceDbPassword());
			
			System.out.println("Source Connection successfully... "+sourceConnection);
			
			// target DB connection
			System.out.println("Connecting to Target database...");
			targetConnection = DriverManager.getConnection(
					DbCopyConfig.getTargetDbUrl(),
					DbCopyConfig.getTargetDbUser(),
					DbCopyConfig.getTargetDbPassword());
			
			System.out.println("Target Connection successfully... "+targetConnection);			

			String sourceSchema = DbCopyConfig.getSourceDbSchema();
			String targetSchema = DbCopyConfig.getTargetDbSchema();

			System.out.println("Copy tables from " + sourceSchema + " to "	+ targetSchema);

			
			try {
				//delete all the existing sequences from target schema
				SequenceUtil.deleteSequence(targetConnection, targetSchema);
				// get existing table list from target DB ordered by parent to child
				 SequenceUtil.copySequence(sourceConnection, sourceSchema, targetConnection, targetSchema);



			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}

		
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
	}
	
	


	public static String[] TRIGGERS_TO_BE_REMOVED = { "SECSAVINGSDEPOSITS" };



}