package tool.com.hsbc.au.db2db.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import de.jcon.dbcopy.AppLogger;
import de.jcon.dbcopy.DBCommand;

public class SequenceUtil {
	public static int FETCH_SIZE=500;
	
	public static void  deleteSequence(Connection aTargetCon, String targetSchema){
		String aSelectStmt="select * from user_sequences";
		AppLogger.getLogger(DBCommand.class).info("Execute " + aSelectStmt);
		Statement aSelectStmtObj=null;
		try {
			aSelectStmtObj = aTargetCon.createStatement();
			aSelectStmtObj.setFetchSize(FETCH_SIZE);
			ResultSet resultset = aSelectStmtObj.executeQuery(aSelectStmt);
			while (resultset.next()) { 
				String sequenceName=resultset.getString("SEQUENCE_NAME");
				String sql="drop sequence "+sequenceName;
				System.out.println(sql);
				Statement dropSequenceStatement=aTargetCon.createStatement();
				dropSequenceStatement.execute(sql);
			}
		}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}finally{
			if(aSelectStmtObj!=null){
				try {
					aSelectStmtObj.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	public static void  copySequence(Connection aSourceCon, String sourceSchema, Connection aTargetCon, String targetSchema){

		String aSelectStmt="select * from user_sequences";
		AppLogger.getLogger(DBCommand.class).info(
				"Execute " + aSelectStmt);
		Statement aSelectStmtObj=null;
		try {
			aSelectStmtObj = aSourceCon.createStatement();
			aSelectStmtObj.setFetchSize(FETCH_SIZE);
			ResultSet resultset = aSelectStmtObj.executeQuery(aSelectStmt);
			while (resultset.next()) {    
				
/**
 * DROP SEQUENCE CUST_CDD_DECISION_AUDIT_SEQ
/

CREATE SEQUENCE CUST_CDD_DECISION_AUDIT_SEQ 
  START WITH 1
  INCREMENT BY 1
  CACHE 100
/
 * 
 */
				String sequenceName=resultset.getString("SEQUENCE_NAME");
				String minValue=resultset.getString("MIN_VALUE");
				String maxValue=resultset.getString("MAX_VALUE");
				String incrementBy=resultset.getString("INCREMENT_BY");
				
				String cycleFlag=resultset.getString("CYCLE_FLAG");
				String orderFlag=resultset.getString("ORDER_FLAG");
				
				
				
				String cacheSize=resultset.getString("CACHE_SIZE");
				long lastNumber=resultset.getLong("LAST_NUMBER");
				
				System.out.println("\nsequenceName="+sequenceName);

				String sql="select * from user_sequences where sequence_name='"+sequenceName+"'";
				Statement querySeqStatement=aTargetCon.createStatement();
				querySeqStatement.setFetchSize(FETCH_SIZE);
				ResultSet querySeqResultset = querySeqStatement.executeQuery(sql);
				if(querySeqResultset!=null && querySeqResultset.next()){
					// drop the sequence first
					sql="drop sequence "+sequenceName;
					System.out.println(sql);
					Statement dropSequenceStatement=aTargetCon.createStatement();
					dropSequenceStatement.execute(sql);
				}
				sql="CREATE SEQUENCE "+sequenceName+" MINVALUE "+minValue+" MAXVALUE "+maxValue+" INCREMENT BY "+incrementBy;
				if(!"0".equals(cacheSize)){
					sql=sql+" CACHE "+cacheSize;
				} else {
					sql=sql+" NOCACHE ";
				}
				if(lastNumber>1){
					sql = sql + " START WITH "+ lastNumber;
				}
				if("Y".equals(cycleFlag)){
					sql = sql + " CYCLE ";
				}else{
					sql = sql + " NOCYCLE ";					
				}
				if("Y".equals(orderFlag)){
					sql = sql + " ORDER ";
				}else{
					sql = sql + " NOORDER ";
				}

				System.out.println(sql);
				Statement createSequenceStatement=aTargetCon.createStatement();
				createSequenceStatement.execute(sql);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(aSelectStmtObj!=null){
				try {
					aSelectStmtObj.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
