package de.jcon.dbcopy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * 
 * Main class for creating db actions. Can be accessed from the command line
 * too.
 * 
 * @author Oliver Gries
 * @version $Revision: 1.14 $ / $Date: 2006/07/18 20:09:12 $
 */
public class DBCommand  {
	
	
	public static int FETCH_SIZE=500;
	// ~ Static fields/initializers
	// -----------------------------------------------------------------

	private static Hashtable _sqlTypRep = null;

	static int maxRows = 10;

	// ~ Instance fields
	// ----------------------------------------------------------------------------

	Connection myConnection = null;

	String _db = null;

	String[] _command = null;

	// ~ Constructors
	// -------------------------------------------------------------------------------



	// ~ Methods
	// ------------------------------------------------------------------------------------



	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param String
	 *            aDBConnection
	 * 
	 * @return DOCUMENT ME!
	 * 
	 * @throws Exception
	 *             DOCUMENT ME!
	 **************************************************************************/
	public static ColumnDescription[] getColumns(Connection aConnection,
			String aSchema, String aTableName) throws SQLException,
			ClassNotFoundException {
		final String aColName = "COLUMN_NAME";
		final String aColType = "DATA_TYPE";
		final String aColSize = "COLUMN_SIZE";
		final String aColTypeName = "TYPE_NAME";
		final String aColNullable = "NULLABLE";
		final String aDecimalDigits="DECIMAL_DIGITS";

		DatabaseMetaData aMData = aConnection.getMetaData();
		String aCatalog = aConnection.getCatalog();
		String aColPattern = "%";

		if ((aSchema != null) && ("".equals(aSchema.trim()))) {
			aSchema = null;
		}

		if ((aCatalog != null) && ("".equals(aCatalog.trim()))) {
			aCatalog = aCatalog.trim();
		}

		int aCount = 0;
		int attempt = 0;
		int maxAttempts = 4;
		Vector aVector = new Vector();
		Object aCol = null;

		while ((aCount == 0) && (attempt < maxAttempts)) {
			// first try to use the standard patterns for catalog and null for
			// schema
			attempt++;
			AppLogger.getLogger(DBCommand.class).debug(
					attempt + ". attempt [" + aTableName
							+ "] Retrieve Cols for Catalog: " + aCatalog
							+ " Schema: " + aSchema + " Table: " + aTableName
							+ " ColPattern: " + aColPattern);

			ResultSet aSet = aMData.getColumns(aCatalog, aSchema, aTableName,
					aColPattern);

			try {
				while (aSet.next()) {
					String colName=aSet.getString(aColName);
					
					// aVector.add(new
					// ColumnDescription(aSet.getString(aColName),
					// getColumnTypeName(aSet.getShort(aColType)),
					// aSet.getInt(aColSize)));
					aVector.add(new ColumnDescription(aSet.getString(aColName),
							aSet.getString(aColTypeName), aSet
									.getShort(aColType), aSet.getInt(aColSize),aSet.getInt(aDecimalDigits),
							(DatabaseMetaData.columnNullable == aSet
									.getInt(aColNullable))));
					aCount++;
				}
			} finally {
				if (aSet != null) {
					aSet.close();
				}
			}

			AppLogger.getLogger(DBCommand.class).debug(
					attempt + ". attempt [" + aTableName + "] got " + aCount
							+ " columns.");

			// a table without cols?? fallback to other catalog settings
			if (aCount == 0) {
				// att.1 change catalog
				if (attempt == 1) {
					if (aCatalog == null) {
						aCatalog = "";
					} else if ("".equals(aCatalog)) {
						aCatalog = null;
					}
				}
				// att.2 change col. like clause
				else if (attempt == 2) {
					if (aCatalog == null) {
						aCatalog = "";
						aColPattern = "";
					} else if ("".equals(aCatalog)) {
						aCatalog = null;
						aColPattern = "";
					}
				}
				// att.3 change col. like clause
				else if (attempt == 3) {
					if (aCatalog == null) {
						aCatalog = "";
						aColPattern = "";
					} else if ("".equals(aCatalog)) {
						aCatalog = null;
						aColPattern = "";
					}
				}
			}
		}

		return (ColumnDescription[]) aVector
				.toArray(new ColumnDescription[aVector.size()]);
	}




	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aDB
	 *            DOCUMENT ME!
	 * @param aTableName
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	public static String getFullTableName(String aDB, String aTableName) {
		if ((aDB == null) || ("".equals(aDB.trim()))) {
			return aTableName;
		} else {
			return aDB + "." + aTableName;
		}
	}



	/***************************************************************************
	 * TODO: DOCUMENT ME!
	 * 
	 * @param aSourceCon
	 *            TODO: DOCUMENT ME!
	 * @param monitor
	 *            TODO: DOCUMENT ME!
	 * 
	 * @return TODO: DOCUMENT ME!
	 * 
	 * @throws SQLException
	 *             TODO: DOCUMENT ME!
	 */
	public static String[] getTableList(Connection aSourceCon,
			String aSourceSchema, ProgressMonitor monitor) throws SQLException {
		DatabaseMetaData theMetaData = aSourceCon.getMetaData();
		ResultSet aSet = theMetaData.getTables(aSourceCon.getCatalog(),
				aSourceSchema, null, new String[] { "TABLE" });
		Vector aTemp = new Vector();
		if (monitor != null)
			monitor.beginTask("Reading Tables", 100);

		int nRows = 0;
		String aTableName = null;

		while (aSet.next()) {
			aTableName = aSet.getString("TABLE_NAME");
			aTemp.addElement(aTableName);

			if ((nRows < 100) && (monitor != null)) {
				monitor.worked(++nRows);
			}
		}

		if (monitor != null)
			monitor.done();

		String[] aTableList = null;
		aTableList = (String[]) aTemp.toArray(new String[aTemp.size()]);

		return aTableList;
	}


	
	
	public static boolean copy(Connection aSourceCon, String sourceSchema, Connection aTargetCon, String targetSchema,
			String sourceTableName, boolean createTables, boolean dropFirst,
			boolean copyData, boolean createForeignKeyConstraint,
			int maxErrors, ProgressMonitor aMonitor, String apostrophe, boolean partialCopy, int partialCopyLimit, String partialCopyCriteria)
			throws SQLException {
		int currentErrors = 0;

		apostrophe = (apostrophe == null) ? "" : apostrophe;

		int aMaxColSize =-1;

		try {
			
			TableMap sourceTableMap=new TableMap(sourceTableName, null);

			if (aMonitor != null) {
				aMonitor.beginTask("Start copying table '"+sourceTableName+"'", 1);
			}

			ResultSet aSource = null;
			String aSelectStmt = null;
			String aInsertStmt = null;
			Statement aSelectStmtObj = null;
			String aMsg = "";
			String aSourceTable = null;
			String aTargetTable = null;
			PreparedStatement aInsertPStmt = null;
			Statement stmt = null;

			// iterate over all tables

				aSourceTable = getFullTableName(null, sourceTableMap
						.getSourceTable());
				aTargetTable = getFullTableName(null, sourceTableMap
						.getFinalTargetTableName());
				currentErrors = 0;

				aMsg = "Copy from table " + aSourceTable + " to "
						+ aTargetTable;

				if (aMonitor != null) {
					aMonitor.subTask(aMsg);
				}

				AppLogger.getLogger(DBCommand.class).info(aMsg);

				if(partialCopy){
					aSelectStmt = getPartialSelectStatement(aSourceTable,  sourceTableMap.getSourceWhereClause(), partialCopyLimit, partialCopyCriteria);			
				} else{
					aSelectStmt = getSelectAllStatement(aSourceTable, sourceTableMap.getSourceWhereClause());
				}
			

				AppLogger.getLogger(DBCommand.class).info(
						"Execute " + aSelectStmt);
				aSelectStmtObj = aSourceCon.createStatement();
				aSelectStmtObj.setFetchSize(FETCH_SIZE);
				aSource = aSelectStmtObj.executeQuery(aSelectStmt);

				if (dropFirst) {
					try {
						if (aMonitor != null) {
							aMonitor.subTask("Dropping table " + aTargetTable);
						}

						dropTable(aTargetCon, aTargetTable);
					} catch (SQLException e) {
						// this may happen if the table doesn't exist, so we
						// consume it and log a warning
						AppLogger.getLogger(DBCommand.class).warn(
								"Warning: Table " + aTargetTable
										+ " could not be dropped: "
										+ e.getLocalizedMessage());
					}
				}

				if (createTables) {
					try {
						if (aMonitor != null) {
							aMonitor.subTask("Creating table " + aTargetTable);
						}


						createTable(aSourceCon, aSource, aTargetCon,
								sourceSchema, targetSchema, sourceTableMap
										.getSourceTable(), sourceTableMap
										.getFinalTargetTableName(),
								aMaxColSize, createForeignKeyConstraint,
								apostrophe);
					} catch (SQLException sqe) {
						AppLogger.getLogger(DBCommand.class).error(
								"Exception: " + sqe.getLocalizedMessage(), sqe);

						// failed to create the table, exit
						System.exit(1);
					}
				}

				if (copyData) {
					int aCount = 0;
					int aStep = FETCH_SIZE;
					long aStartTime = System.currentTimeMillis();
					List aMap;// = new Vector();
					List copyRecorsList = new ArrayList();
					ColumnDescription[] aColumns = null;
										
					try {
						aColumns = getColumns(aSourceCon, sourceSchema, sourceTableMap
								.getSourceTable());
						
						aInsertStmt = getInsertStatement(aColumns,aSource, aTargetTable,
								sourceTableMap, apostrophe);
						//System.out.print("insert ***** "+aInsertStmt);
						AppLogger.getLogger(DBCommand.class).info(
								"Use prepared Statement for copy:" 	+ aInsertStmt);
						aInsertPStmt = aTargetCon.prepareStatement(aInsertStmt);

						while (((aMonitor == null) || !aMonitor.isCanceled())
								&& aSource.next()
								&& (currentErrors < maxErrors)) {
							aMap = new Vector();
							try {
								aMap.clear();
								aMap = fillPreparedStatement(aColumns,aInsertPStmt,
										sourceTableMap, aSource, aMap);	
								
								aInsertPStmt.addBatch();
								copyRecorsList.add(aMap);						
								
								aCount++;
								
									if ((aCount % aStep) == 0) {
									aInsertPStmt.executeBatch();
									copyRecorsList.clear();
									long aTime = (System.currentTimeMillis() - aStartTime) / 1000;
									aMsg = aSourceTable + " -> " + aTargetTable
											+ ": " + aCount + " records in "
											+ aTime + "s";

									if (aMonitor != null) {
										aMonitor.subTask(aMsg);
									}

									AppLogger.getLogger(DBCommand.class).info(
											aMsg);

									// force garbage collection during long
									// transfers
									System.gc();
								}
							} catch (BatchUpdateException e) {	
								aTargetCon.rollback();
								aInsertPStmt.clearBatch();
																
								processFailedRecords(aColumns,aSource, aTargetTable, sourceTableMap, apostrophe,copyRecorsList, aTargetCon);
							}						
						}						
						aInsertPStmt.executeBatch();	
						copyRecorsList.clear();						
					} catch (BatchUpdateException e) {	
						aTargetCon.rollback();
						aInsertPStmt.clearBatch();					
						processFailedRecords(aColumns,aSource, aTargetTable, sourceTableMap, apostrophe,copyRecorsList, aTargetCon);
						
					} finally {
						if (aInsertStmt != null) {
							aInsertPStmt.close();
						}
						if (stmt != null) {
						stmt.close();	
						}

						if (aSelectStmtObj != null) {
							aSelectStmtObj.close();
						}
					}

					if (currentErrors >= maxErrors) {
						aMsg = "To many errors during copy " + aSourceTable
								+ " -> " + aTargetTable + ". Stopped transfer.";
						AppLogger.getLogger(DBCommand.class).info(aMsg);
					}

					long nEndTime = (System.currentTimeMillis() - aStartTime) / 1000;
					aMsg = "Finished " + aSourceTable + " -> " + aTargetTable
							+ ": " + aCount + " records in " + nEndTime + "s";
					AppLogger.getLogger(DBCommand.class).info(aMsg);
				}

		}
		catch (Throwable exc) {			
			exc.printStackTrace();
			 AppLogger.getLogger(DBCommand.class).info(
						"fffffffffffffff");
			AppLogger.getLogger(DBCommand.class).error(
					"Got Exception: " + exc.getLocalizedMessage(), exc);
			//throw new RuntimeException("Failed to copy data");
		} 

		return (currentErrors == 0);
	}
	
	public static void processFailedRecords(ColumnDescription[] aColumns,ResultSet aSource,String aTargetTable,TableMap sourceTableMap,String apostrophe, List copyRecorsList,Connection aTargetCon){
		int failedCount =0;
		
		 int i =0;
		 for(;i<copyRecorsList.size();i++){
			 List data = (List) copyRecorsList.get(i);
			 									 
			 String insertStatement=null;
			 Statement stmt = null;
			try {	
				insertStatement = prepareInsertStatement(aColumns,aSource, aTargetTable, sourceTableMap, apostrophe, data);
			
			 stmt = aTargetCon.createStatement();
			 stmt.execute(insertStatement);
			 AppLogger.getLogger(DBCommand.class).info(
					 "copy to table '"+aTargetTable+"'. Failed record inserted:" + i);
			 if (insertStatement != null) {
					stmt.close();	
				}
			 }catch(Exception ex){
				 AppLogger.getLogger(DBCommand.class).warn("failed insert:"+insertStatement);
				 AppLogger.getLogger(DBCommand.class).warn("copy to table '"+aTargetTable+"'. exception:"+ex);
				 ex.printStackTrace();												
				 failedCount++;
			 } finally {
				 if(stmt!=null){
					 try {
						stmt.close();
					} catch (SQLException e) {
						System.out.println("Ignored exception when finally close the insert statement:"+e);
					}
				 }
			 }
			}	
		 AppLogger.getLogger(DBCommand.class).warn("copy to table '"+aTargetTable+"'. Number of failed record:" + failedCount);
		 copyRecorsList.clear();
	}




	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @throws SQLException
	 *             DOCUMENT ME!
	 **************************************************************************/
	public void close() throws SQLException {
		if (myConnection != null) {
			myConnection.close();
		}
	}




	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aFileName
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	public static Vector openStatementList(String aFileName) {
		Vector aVector = null;

		try {
			BufferedWriter aWriter = new BufferedWriter(new FileWriter(
					"out.txt"));
			aWriter.write("test");
			aWriter.close();

			BufferedReader aNewReader = new BufferedReader(new FileReader(
					aFileName));
			aVector = createStatements(aNewReader);
			aNewReader.close();
		} catch (Exception exc) {
			exc.printStackTrace();
		}

		return aVector;
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aBuffer
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	public static Vector openStatementList(StringBuffer aBuffer) {
		Vector aVector = null;

		if (aBuffer == null) {
			return null;
		}

		try {
			BufferedReader aNewReader = new BufferedReader(new StringReader(
					aBuffer.toString()));
			aVector = createStatements(aNewReader);
			aNewReader.close();
		} catch (Exception exc) {
			exc.printStackTrace();
		}

		return aVector;
	}





	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aSQLType
	 *            DOCUMENT ME!
	 * @deprecated
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	private static String getColumnTypeName(int aSQLType) {
		String aName = (String) getTypeRepository().get("" + aSQLType);

		if (aName == null) {
			aName = "VARCHAR";
		}

		return aName;
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aSet
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 * 
	 * @throws Exception
	 *             DOCUMENT ME!
	 **************************************************************************/
	private static int[] getColumnTypes(ResultSet aSet) throws Exception {
		ResultSetMetaData aData = aSet.getMetaData();

		int aSize = aData.getColumnCount();
		int[] theTypes = new int[aSize];

		for (int i = 0; i < aSize; i++) {
			theTypes[i] = aData.getColumnType(i + 1);
		}

		return theTypes;
	}

//	/***************************************************************************
//	 * DOCUMENT ME!
//	 * 
//	 * @param aSet
//	 *            DOCUMENT ME!
//	 * 
//	 * @return DOCUMENT ME!
//	 * @deprecated Some driver don't deliver the proper column type names from a
//	 *             result set. Use the column functionality from
//	 *             DatabaseMetaData for it; its more reliable.
//	 * 
//	 * @throws Exception
//	 *             DOCUMENT ME!
//	 **************************************************************************/
//	private static ColumnDescription[] getColumns(ResultSet aSet)
//			throws Exception {
//		ResultSetMetaData aData = aSet.getMetaData();
//
//		int aSize = aData.getColumnCount();
//		ColumnDescription[] theCols = new ColumnDescription[aSize];
//
//		int aSetPos = 0;
//
//		for (int i = 0; i < aSize; i++) {
//			aSetPos = i + 1;
//			theCols[i] = new ColumnDescription(aData.getColumnName(aSetPos),
//					aData.getColumnTypeName(aSetPos), aData
//							.getColumnType(aSetPos), -1,
//					(ResultSetMetaData.columnNullable == aData
//							.isNullable(aSetPos)));
//		}
//
//		return theCols;
//	}

	/***************************************************************************
	 * TODO: DOCUMENT ME!
	 * 
	 * @param rConnection
	 *            TODO: DOCUMENT ME!
	 * @param aSet
	 *            TODO: DOCUMENT ME!
	 * @param sTargetSchema
	 *            TODO: DOCUMENT ME!
	 * @param sTableName
	 *            TODO: DOCUMENT ME!
	 * @param aMaxColSize
	 *            TODO: DOCUMENT ME!
	 * 
	 * @return TODO: DOCUMENT ME!
	 * 
	 * @throws SQLException
	 *             TODO: DOCUMENT ME!
	 */
	private static String getCreateTableStmt(Connection rConnection,
			ResultSet aSet, String sSourceSchema, String sTargetSchema,
			String sSourceTableName, String sTargetTableName, int aMaxColSize,
			boolean bForeignKey, String apostroph) throws SQLException,
			ClassNotFoundException {
		ResultSetMetaData rRSMeta = aSet.getMetaData();
		StringBuffer aBuffer = new StringBuffer("create table ");
		aBuffer.append(getFullTableName(sTargetSchema, sTargetTableName));
		aBuffer.append(" (");

		ColumnDescription[] theCols = getColumns(rConnection, sSourceSchema,
				sSourceTableName);

		for (int i = 0; i < theCols.length; i++) {

			String aName = theCols[i].getColName();
			int aCSize = theCols[i].getColSize();
			int aDecimalDigits = theCols[i].getDecimalDigits();
			int aTypeInt = theCols[i].getColType();
			boolean bNoNulls = !theCols[i].isNullable();
			String aType = theCols[i].getColTypeName();

			AppLogger.getLogger(DBCommand.class).debug(
					"Column Type: " + aTypeInt + " TypeName: " + aType
							+ " JavaTypeName: " + getColumnTypeName(aTypeInt)
							+ " ColName: " + aName);

			aBuffer.append(" ");
			aBuffer.append(apostroph);
			aBuffer.append(aName);
			aBuffer.append(apostroph);
			aBuffer.append(" ");
			aBuffer.append(aType);
			
			int columnSize=getTargetColSize(aCSize, aMaxColSize);
			
			if(columnSize>0){
				if ((aTypeInt == java.sql.Types.CHAR)
						|| (aTypeInt == java.sql.Types.VARCHAR)
						|| (aTypeInt == java.sql.Types.DECIMAL)
						|| (aTypeInt == java.sql.Types.CLOB)
						|| (aTypeInt == java.sql.Types.NUMERIC)
						|| (aTypeInt == java.sql.Types.FLOAT)) {
					aBuffer.append("(");
					aBuffer.append("" + getTargetColSize(aCSize, aMaxColSize));
					if(aTypeInt == java.sql.Types.DECIMAL  && aDecimalDigits>0){
						aBuffer.append("," +aDecimalDigits);
					}
					aBuffer.append(")");
				}
			}

			if (bNoNulls) {
				aBuffer.append(" not null");
			}

			if (i < (theCols.length - 1)) {
				aBuffer.append(", ");
			}
		}

		String sPK = getPrimaryKeyConstraint(rConnection, rRSMeta,
				sSourceSchema, sSourceTableName);

		if (sPK.length() > 0) {
			aBuffer.append(", " + sPK);
		}

		aBuffer.append(") ");

		return aBuffer.toString();
	}

	/***************************************************************************
	 * Creates the SQL string for the foreign key constraints of a particular
	 * database table. This is done by analyzing the metadata of a database
	 * connection and a ResultSet for the table.
	 * 
	 * @param rSrcConnection
	 *            The Connection where the ResultSet has been created on
	 * @param rSrcRSMeta
	 *            The metadata of a ResultSet for the table
	 * @param sTargetSchema
	 *            The schema name (table prefix) of the target database
	 * 
	 * @return The foreign key constraint (empty if no constraint exists)
	 * 
	 * @throws SQLException
	 *             If accessing the metadata fails
	 */
	private static String getForeignKeyConstraints(Connection rSrcConnection,
			ResultSetMetaData rSrcRSMeta, String sSourceSchema,
			String sTargetSchema, String sTable) throws SQLException {
		DatabaseMetaData rDBMeta = rSrcConnection.getMetaData();
		StringBuffer aResult = new StringBuffer();
		String sCatalog = rSrcConnection.getCatalog();

		// String sSchema = rSrcRSMeta.getSchemaName(1);
		String sSchema = sSourceSchema;

		// String sTable = rSrcRSMeta.getTableName(1);
		int attempt = 1;
		int nPos = 0;
		int aFullCount = 0;
		int aHitCount = 0;

		/**
		 * DOCUMENT ME!
		 * 
		 * @author $author$
		 * @version $Revision: 1.14 $
		 */
		class ForeignKeyData {
			String sExtTable = null;

			Vector aColumns = null;
		}

		/*
		 * if ((nPos = sTable.indexOf(".")) >= 0) { sSchema =
		 * sTable.substring(0, nPos); sTable = sTable.substring(nPos + 1); }
		 * else if (sSchema.length() == 0) { //sSchema = null; sSchema = ""; }
		 */
		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable
						+ "] Retrieve FK for Catalog: " + sCatalog
						+ " Schema: " + sSchema + " Table: " + sTable);

		ResultSet aSet = rDBMeta.getImportedKeys(sCatalog, sSchema, sTable);
		Map aKeyMap = new HashMap();

		while (aSet.next()) {
			aFullCount++;

			int nKeySeq = aSet.getInt("KEY_SEQ");
			String sKeyName = aSet.getString("FK_NAME");

			ForeignKeyData aFKData = (ForeignKeyData) aKeyMap.get(sKeyName);

			if (aFKData == null) {
				aFKData = new ForeignKeyData();
				aFKData.aColumns = new Vector();
				aKeyMap.put(sKeyName, aFKData);
			}

			if (nKeySeq > aFKData.aColumns.size()) {
				aFKData.aColumns.setSize(nKeySeq);
			}

			if (aFKData.sExtTable == null) {
				aFKData.sExtTable = aSet.getString("PKTABLE_NAME");
			}

			String sExtCol = aSet.getString("PKCOLUMN_NAME");
			String sCol = aSet.getString("FKCOLUMN_NAME");
			aFKData.aColumns.set(nKeySeq - 1, new String[] { sCol, sExtCol });
		}

		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] has " + aFullCount
						+ " FK references.");

		Iterator aKeyMapIter = aKeyMap.values().iterator();

		while (aKeyMapIter.hasNext()) {
			aHitCount++;

			ForeignKeyData aFKData = (ForeignKeyData) aKeyMapIter.next();

			if (aFKData.aColumns.size() > 0) {
				StringBuffer aReferencesPart = new StringBuffer();

				aResult.append("foreign key (");
				aReferencesPart.append(" references " + sTargetSchema + "."
						+ aFKData.sExtTable + " (");

				for (int i = 0; i < aFKData.aColumns.size(); i++) {
					if (i > 0) {
						aResult.append(",");
						aReferencesPart.append(",");
					}

					String[] aColumns = (String[]) aFKData.aColumns.get(i);
					aResult.append(aColumns[0]);
					aReferencesPart.append(aColumns[1]);
				}

				aResult.append(")");
				aReferencesPart.append(")");
				aResult.append(aReferencesPart);
			}

			if (aKeyMapIter.hasNext()) {
				aResult.append('|');
			}
		}

		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] used " + aHitCount
						+ " FK references for table statement.");

		String aResultString = aResult.toString();
		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] FK statement: "
						+ aResultString);

		System.out.print(aResultString);
		return aResultString;
	}

	/***************************************************************************
	 * TODO: DOCUMENT ME!
	 * 
	 * @param aSet
	 *            TODO: DOCUMENT ME!
	 * @param sTable
	 *            TODO: DOCUMENT ME!
	 * 
	 * @return TODO: DOCUMENT ME!
	 * 
	 * @throws Exception
	 *             TODO: DOCUMENT ME!
	 */
	private static String getInsertStatement(ColumnDescription[] aColumns, ResultSet aSet,
			String sTargetTable, TableMap aTableMap, String apostroph)
			throws Exception {
		StringBuffer aInsertPart = new StringBuffer("insert into "
				+ sTargetTable + " (");
		StringBuffer aValuesPart = new StringBuffer(") values (");
		Object aValue = null;
		int nMax = aColumns.length - 1;
		String aSourceCol = null;
		String aTargetCol = null;
		String _temp = null;

		for (int i = 0; i <= nMax; i++) {
			aSourceCol = aColumns[i].getColName();
			aTargetCol = null;

			if (aTableMap != null) {
				if (!aTableMap.isToBeIgnoredForCopy(aSourceCol)) {
					_temp = aTableMap.getTargetColName(aSourceCol);
					aTargetCol = (_temp != null) ? _temp : aSourceCol;
				}
			} else {
				aTargetCol = aSourceCol;
			}

			if (aTargetCol != null) {
				aInsertPart.append(apostroph);
				aInsertPart.append(aTargetCol);
				aInsertPart.append(apostroph);
				aValuesPart.append("?");
			

				// won't work anyway
				// if (i < nMax) {
				aInsertPart.append(",");
				aValuesPart.append(",");

				// }
			}
		}

		// unfortunately we have to test this as well
		// because we don't really know when the last token has been occured
		// due to the "ignore" feature
		int aLastIndex = 0;

		if (',' == aInsertPart.charAt((aLastIndex = aInsertPart.length() - 1))) {
			aInsertPart.deleteCharAt(aLastIndex);
		}

		if (',' == aValuesPart.charAt((aLastIndex = aValuesPart.length() - 1))) {
			aValuesPart.deleteCharAt(aLastIndex);
		}

		aValuesPart.append(")");

		return aInsertPart.append(aValuesPart).toString();
	}

	/***************************************************************************
	 * Creates a SQL primary key constraint string from a particular source
	 * table. This is done by analyzing the metadata of the source database
	 * connection and a ResultSet for the source table.
	 * 
	 * @param rSrcConnection
	 *            The Connection where the ResultSet has been created on
	 * @param rSrcRSMeta
	 *            The metadata of a ResultSet for the table
	 * 
	 * @return The primary key constraint (empty if none exists)
	 * 
	 * @throws SQLException
	 *             If accessing the metadata fails
	 */
	private static String getPrimaryKeyConstraint(Connection rSrcConnection,
			ResultSetMetaData rSrcRSMeta, String sSourceSchema, String sTable)
			throws SQLException {
		DatabaseMetaData rDBMeta = rSrcConnection.getMetaData();
		StringBuffer aResult = new StringBuffer();
		String sCatalog = rSrcConnection.getCatalog();
		String sSchema = sSourceSchema;

		// String sSchema = rSrcRSMeta.getSchemaName(1);
		// String sTable = rSrcRSMeta.getTableName(1);
		int nPos;
		int aCount = 0;
		int attempt = 1;

		/*
		 * if ((nPos = sTable.indexOf(".")) >= 0) { sSchema =
		 * sTable.substring(0, nPos); sTable = sTable.substring(nPos + 1); }
		 * else if (sSchema.length() == 0) { sSchema = null; }
		 */
		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable
						+ "] Retrieve PK for Catalog: " + sCatalog
						+ " Schema: " + sSchema + " Table: " + sTable);

		ResultSet aSet = rDBMeta.getPrimaryKeys(sCatalog, sSchema, sTable);
		Vector aKeyColumns = new Vector();

		try {
			while (aSet.next()) {
				aCount++;

				int pos = aSet.getInt("KEY_SEQ") - 1;

				if (pos >= aKeyColumns.size()) {
					aKeyColumns.setSize(pos + 1);
				}

				aKeyColumns.set(pos, aSet.getString("COLUMN_NAME"));
			}
		} finally {
			if (aSet != null) {
				aSet.close();
			}
		}

		AppLogger.getLogger(DBCommand.class).debug(
				attempt + ". attempt [" + sTable + "] has " + aCount
						+ " PK definitions.");

		if (aKeyColumns.size() > 0) {
			aResult.append("primary key (");

			for (int i = 0; i < aKeyColumns.size(); i++) {
				if (i > 0) {
					aResult.append(",");
				}

				aResult.append(aKeyColumns.elementAt(i));
			}

			aResult.append(")");
		}

		return aResult.toString();
	}

	/***************************************************************************
	 * To create a select statement for all columns of a particular table with
	 * an optional WHERE clause.
	 * 
	 * @param aTable
	 *            The fully qualified table name
	 * @param sWhere
	 *            The optional WHERE clause
	 * 
	 * @return The resulting select statement string
	 */
	private static String getSelectAllStatement(String aTable, String sWhere) {
		StringBuffer aBuffer = new StringBuffer("select * from ");

		aBuffer.append(aTable);

		if ((sWhere != null) && (sWhere.length() > 0)) {
			aBuffer.append(" WHERE ");
			aBuffer.append(sWhere);
			
		}

		System.out.print("aBuffer***** "+aBuffer);;
		return aBuffer.toString();
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aSourceValue
	 *            DOCUMENT ME!
	 * @param aMaxColSize
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	private static int getTargetColSize(int aSourceValue, int aMaxColSize) {
		if (aMaxColSize == -1) {
			return aSourceValue;
		} else {
			if (aSourceValue > aMaxColSize) {
				return aMaxColSize;
			} else {
				return aSourceValue;
			}
		}
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	private static Hashtable getTypeRepository() {
		try {
			if (_sqlTypRep == null) {
				_sqlTypRep = new Hashtable();

				// initialisieren
				// schwerer hack um ueber den SQL Type an den Namen
				Field[] javaSQLTypes = java.sql.Types.class.getFields();
				Field _currentField = null;
				int aKey = 0;
				String aName = null;

				for (int i = 0; i < javaSQLTypes.length; i++) {
					_currentField = javaSQLTypes[i];
					aKey = _currentField.getInt(null);
					aName = _currentField.getName();
					_sqlTypRep.put("" + aKey, aName);
				}
			}
		} catch (Exception exc) {
			exc.printStackTrace();
		}

		return _sqlTypRep;
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aMap
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	private static String getValues(List aMap) {
		final String aStd = "[Map values not set]";

		if ((aMap == null) || (aMap.size() == 0)) {
			return aStd;
		}

		StringBuffer aBuffer = new StringBuffer("[");
		Object anObject = null;

		for (int i = 0; i < aMap.size(); i++) {
			aBuffer.append("(");
			aBuffer.append("" + (i + 1) + "-");
			aBuffer.append(((anObject = aMap.get(i)) == null) ? "null"
					: anObject.toString());
			aBuffer.append(") ");
		}

		aBuffer.append("]");

		return aBuffer.toString();
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aCommand
	 *            DOCUMENT ME!
	 * @param theCommands
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 **************************************************************************/
	private static String[] getValues(String aCommand, String[] theCommands) {
		if (theCommands != null) {
			for (int i = 0; i < theCommands.length; i++) {
				// AppLogger.getLogger(DBCommand.class).info("compare " +
				// theCommands[i] + " with " + aCommand);
				if (theCommands[i].equals(aCommand)) {
					// AppLogger.getLogger(DBCommand.class).info("matched");
					Vector aVector = new Vector();

					for (int y = i + 1; y < theCommands.length; y++) {
						// wenn kein neuer switch da ist
						if (theCommands[y].indexOf("-") == -1) {
							aVector.addElement(theCommands[y]);
						} else {
							break;
						}
					}

					return (String[]) aVector
							.toArray(new String[aVector.size()]);
				}
			}
		}

		return null;
	}

	/***************************************************************************
	 * DOCUMENT ME!
	 * 
	 * @param aNewReader
	 *            DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 * 
	 * @throws IOException
	 *             DOCUMENT ME!
	 **************************************************************************/
	private static Vector createStatements(BufferedReader aNewReader)
			throws IOException {
		Vector aVector = new Vector();
		String aLine = "";

		while ((aLine = aNewReader.readLine()) != null) {
			if (!(aLine.startsWith("#") || aLine.startsWith("//")
					|| aLine.startsWith("--") || aLine.trim().equals(""))) {
				// AppLogger.getLogger(JDBCCommand.class).debug("Zeile
				// hinzugef�gt: " + aLine);
				aVector.addElement(aLine);
			}
		}

		return aVector;
	}

	/***************************************************************************
	 * To create a new table in a target database from it's metadata definition
	 * in a source database.
	 * 
	 * @param aSourceCon
	 *            The source database connection
	 * @param aSourceResult
	 *            A result set of the source connection describing the table to
	 *            be copied
	 * @param aTargetCon
	 *            The target database connection
	 * @param sTargetSchema
	 *            The schema (table prefix) in the target database
	 * @param sTable
	 *            The table name
	 * @param nMaxColSize
	 *            The maximum data size of text columns in the new table
	 * 
	 * @throws SQLException
	 *             If accessing either database fails
	 */
	private static void createTable(Connection aSourceCon,
			ResultSet aSourceResult, Connection aTargetCon,
			String sSourceSchema, String sTargetSchema, String sSourceTable,
			String sTargetTable, int nMaxColSize, boolean bForeignKey,
			String apostrophe) throws SQLException, ClassNotFoundException {
		Statement aStmt = null;
		String aFullTargetTableName = getFullTableName(sTargetSchema,
				sTargetTable);
		String aFullSourceTableName = getFullTableName(sSourceSchema,
				sSourceTable);

		try {
			AppLogger.getLogger(DBCommand.class).info(
					"Create table " + aFullTargetTableName);

			String sCreateStmt = getCreateTableStmt(aSourceCon, aSourceResult,
					sSourceSchema, sTargetSchema, sSourceTable, sTargetTable,
					nMaxColSize, bForeignKey, apostrophe);
			AppLogger.getLogger(DBCommand.class).info("execute [" + sCreateStmt+"]");

			aStmt = aTargetCon.createStatement();
			aStmt.execute(sCreateStmt);
		} finally {
			if (aStmt != null) {
				aStmt.close();
			}
		}

		if (bForeignKey) {
			
			String aFK = getForeignKeyConstraints(aSourceCon, aSourceResult
					.getMetaData(), sSourceSchema, sTargetSchema,
					sSourceTable);
			if ((aFK != null) && (!"".equals(aFK.trim()))){

				String[] foreignKeys = aFK.split("\\|");
				for(int i = 0; i<foreignKeys.length; i++){
					try {
						
		
						if ((foreignKeys[i] != null) && (!"".equals(foreignKeys[i].trim()))) {
							StringBuffer aBuffer = new StringBuffer("alter table ");
							aBuffer.append(aFullTargetTableName);
							aBuffer.append(" add ");
							aBuffer.append(foreignKeys[i]);
		
							String aFKStmt = aBuffer.toString();
							System.out.print("aFKStmt *** "+aFKStmt);
		
							AppLogger.getLogger(DBCommand.class).info(
									"execute " + aFKStmt);
		
							aStmt = aTargetCon.createStatement();
							aStmt.execute(aFKStmt);
						}
					} catch (Exception exc) {
						AppLogger.getLogger(DBCommand.class).error(
								"Error by retrieving foreign key constaints.", exc);
						AppLogger.getLogger(DBCommand.class).warn(
								"FK constraints ignored.");
					} finally {
						if (aStmt != null) {
							aStmt.close();
						}
					}
				}
			}
		}
	}

	/***************************************************************************
	 * To drop a table in a target database.
	 * 
	 * @param aTargetCon
	 *            The target database connection
	 * @param sTargetTable
	 *            The fully qualified table name
	 * 
	 * @throws SQLException
	 *             TODO: DOCUMENT ME!
	 */
	public static void dropTable(Connection aTargetCon, String sTargetTable)
			throws SQLException {
		Statement aStmt;
		AppLogger.getLogger(DBCommand.class).info("Drop table " + sTargetTable);

		String sDropStmt = "drop table " + sTargetTable;
		AppLogger.getLogger(DBCommand.class).info("execute " + sDropStmt);
		aStmt = aTargetCon.createStatement();
		aStmt.execute(sDropStmt);
		aStmt.close();
	}

	/***************************************************************************
	 * To drop a table in a target database.
	 * 
	 * @param aTargetCon
	 *            The target database connection
	 * @param sTargetView
	 *            The fully qualified View name
	 * 
	 * @throws SQLException
	 *             TODO: DOCUMENT ME!
	 */
	public static void dropView(Connection aTargetCon, String sTargetView)
			throws SQLException {
		Statement aStmt;
		AppLogger.getLogger(DBCommand.class).info("Drop view " + sTargetView);

		String sDropStmt = "drop view " + sTargetView;
		AppLogger.getLogger(DBCommand.class).info("execute " + sDropStmt);
		aStmt = aTargetCon.createStatement();
		aStmt.execute(sDropStmt);
		aStmt.close();
	}
	
	/***************************************************************************
	 * To fill a prepared statement with all the values from a ResultSet.
	 * 
	 * @param aStmt
	 *            The prepared Statement to fill
	 * @param aResult
	 *            The result set to read the values from
	 * 
	 * @throws SQLException
	 *             TODO: DOCUMENT ME!
	 */
	private static List fillPreparedStatement(ColumnDescription[] aColumns, PreparedStatement aStmt,
			TableMap aTableMap, ResultSet aResult, List aMap) throws Exception {

		Object aValue = null;
		int nMax = aColumns.length - 1;
		String aSourceCol = null;
		String aTargetCol = null;
		String _temp = null;
		int aCount = 0;
		int aPos = 0;

		for (int i = 0; i <= nMax; i++) {
			aSourceCol = aColumns[i].getColName();
			aTargetCol = null;

			try {
				aValue = aResult.getObject(i + 1);

				/*
				 * aValue = null; try { aValue = aResult.getObject(i + 1); }
				 * catch (Exception exc) {
				 * AppLogger.getLogger(DBCommand.class).error("Error by
				 * retrieving value for column " + (i + 1)+" using null
				 * instead.", exc); }
				 */
				if (aTableMap != null) {
					if (!aTableMap.isToBeIgnoredForCopy(aSourceCol)) {
						aPos = aCount + 1;

						// some driver don't like to set null
						if (aValue != null) {
							aStmt.setObject(aPos, aValue);
						} else {
							// AppLogger.getLogger(DBCommand.class).warn("Ignoring
							// value null at pos: " + aPos + " from origin pos "
							// + (i + 1));
							aStmt.setNull(aPos, aColumns[i].getColType());
						}

						aCount++;
					}
				} else {
					aPos = i + 1;

					if (aValue != null) {
						aStmt.setObject(aPos, aValue);
					} else {
						// AppLogger.getLogger(DBCommand.class).warn("Ignoring
						// value null at pos: " + aPos + " from origin pos " +
						// (i + 1));
						aStmt.setNull(aPos, aColumns[i].getColType());
					}
				}

 			aMap.add(aValue);
				
			} catch (Exception exc) {
				AppLogger.getLogger(DBCommand.class).error(
						"Error during filling of prepared statement at pos: "
								+ aPos + " with Value: " + aValue
								+ " from origin pos " + (i + 1), exc);
				throw exc;
			}
		}

		return aMap;
	}
	
	/***************************************************************************
	 * DOCUMENT ME!
	 **************************************************************************/
	private static void showUsage() {
		AppLogger
				.getLogger(DBCommand.class)
				.info(
						"Usage: java DBCommand -file fileWithSQLStatements || -copy aSourceDefinition aTargetDefinition <-create> <-drop> <-withfk> <-tables aName1 aName2 ...>");
	}
	
	
	private static String prepareInsertStatement(ColumnDescription[] aColumns, ResultSet aSet,
			String sTargetTable, TableMap aTableMap, String apostroph,List data)
			throws Exception {
		StringBuffer aInsertPart = new StringBuffer("insert into "+ sTargetTable + " (");
		StringBuffer aValuesPart = new StringBuffer(") values (");
		Object aValue = null;
		int nMax = aColumns.length - 1;
		String aSourceCol = null;
		int aSourceColType;
		String aTargetCol = null;
		String _temp = null;

		for (int i = 0; i <= nMax; i++) {
			aSourceCol = aColumns[i].getColName();
			aSourceColType = aColumns[i].getColType();
		
			aTargetCol = null;

			if (aTableMap != null) {
				if (!aTableMap.isToBeIgnoredForCopy(aSourceCol)) {
					_temp = aTableMap.getTargetColName(aSourceCol);
					aTargetCol = (_temp != null) ? _temp : aSourceCol;
				}
			} else {
				aTargetCol = aSourceCol;
			}

			if (aTargetCol != null) {
				aInsertPart.append(apostroph);
				aInsertPart.append(aTargetCol);
				aInsertPart.append(apostroph);
				
				if(data.get(i) != null){
					if ((aSourceColType == java.sql.Types.CHAR)
							|| (aSourceColType == java.sql.Types.VARCHAR)){
						aValuesPart.append("'");					
					}
				
					if (aSourceColType == java.sql.Types.TIMESTAMP){
						aValuesPart.append("TO_TIMESTAMP('");					
					}
					if (aSourceColType == java.sql.Types.DATE){
						aValuesPart.append("TO_DATE('");					
					}
				}
				aValuesPart.append(data.get(i));
				
				if(data.get(i) != null){
					if (aSourceColType == java.sql.Types.DATE){
						aValuesPart.append("',");
						aValuesPart.append("'YYYY-MM-DD')");				
					}
					if (aSourceColType == java.sql.Types.TIMESTAMP){
						aValuesPart.append("',");
						aValuesPart.append("'YYYY-MM-DD HH24:MI:ss:FF')");
					}				
					if ((aSourceColType == java.sql.Types.CHAR)
							|| (aSourceColType == java.sql.Types.VARCHAR)){
						aValuesPart.append("'");				
					}
				}
				aInsertPart.append(",");
				aValuesPart.append(",");
			}
		}

		// unfortunately we have to test this as well
		// because we don't really know when the last token has been occured
		// due to the "ignore" feature
		int aLastIndex = 0;

		if (',' == aInsertPart.charAt((aLastIndex = aInsertPart.length() - 1))) {
			aInsertPart.deleteCharAt(aLastIndex);
		}

		if (',' == aValuesPart.charAt((aLastIndex = aValuesPart.length() - 1))) {
			aValuesPart.deleteCharAt(aLastIndex);
		}

		aValuesPart.append(")");

		return aInsertPart.append(aValuesPart).toString();
	}

	
	private static String getPartialSelectStatement(String aTable, String sWhere, int limit, String partialCopyCriteria) {
		StringBuffer aBuffer = new StringBuffer("select * from ("+getSelectAllStatement(aTable,sWhere) +" order by rownum "+partialCopyCriteria+") where rownum < "+limit+"");
		return aBuffer.toString();
	}
	
	



}
