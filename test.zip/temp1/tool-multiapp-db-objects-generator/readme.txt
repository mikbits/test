

Usage Guide

Prerequisite
==================
- ant
- maven


Manual Procedure
===================
Step 1: download all the dependencies to local directory
-- command
mvn dependency:copy-dependencies 
-- output
the dependent jar files will be downloaded to .\target\dependency folder

Step 2: generate Hibernate mapping files
-- command
ant
-- output
Hibernate mapping files and java objects will be generated to .\target\generated

Auto Procedure
==================
-- command
generate.bat


