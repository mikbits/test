#!/usr/bin/python

'''
This dummyserver is used to return dummy json response to client side

start the server:
	cd $web_root$    -- change directory to where the web root stays
	python -m CGIHTTPServer

data file:
	data file should be put under $web_root$/data folder
	data file should be named as $cmd$_$identifier1$_$identifier2$....txt

settings:
	settings file should be put under $web_root$/cgi folder, the same folder where dummyserver.py exists
	settings file contains a dictionary as follows:
		{
			"retrieve":["option1.applicationId","option1.birthDate"],
			"submitIds":["evidData.applicantType"]
		}
	explanation:
		{
			"retrieve":									---- should match the value of the reqDict['cmd']
				["option1.applicationId", 				---- identifier1=the value of reqDict['option1']['applicationId']
					"option1.birthDate"], 				---- identifier2=the value of reqDict['option1']['birthData']
			"submitIds":
				["evidData.applicantType"]
		}
'''



import cgi, cgitb,json
import sys, time

global SETTINGS


DATA_FILE_ROOT='/data'
SETTINGS_FILE="dummyserver.settings"
SETTINGS=[]

def loadSettings():
	import os, sys
	currentFileFullPath = os.path.realpath( __file__ )
	debug('currentFileFullPath='+currentFileFullPath)
	currentFilePath = os.path.dirname(currentFileFullPath)
	debug('currentFilePath='+currentFilePath)

	global SETTINGS
	if len(SETTINGS)==0:
		f = open(currentFilePath+'/'+SETTINGS_FILE,'r')
		contents = f.read()
		SETTINGS=json.loads(contents)
	return SETTINGS

def findIdentifiers(reqDict):
	global SETTINGS
	cmd= reqDict['cmd']
	identifiers=[]
	identifiers.append(cmd);
	if cmd in SETTINGS:
		matchedIdentifierSettings= SETTINGS[cmd]
		for matchedIdentifier in matchedIdentifierSettings:
			idPaths=matchedIdentifier.split('.')
			value=reqDict
			found = True
			for idPath in idPaths:
				if idPath in value:
					value=value[idPath]
				else:
					found = False
					break
			if found:
				identifiers.append(value)
	return identifiers


def getResponseDict(identifiers):

	import os, sys
	currentFileFullPath = os.path.realpath( __file__ )
	debug('currentFileFullPath='+currentFileFullPath)
	currentFilePath = os.path.dirname(currentFileFullPath)
	debug('currentFilePath='+currentFilePath)
	currentFilePath = os.path.dirname(currentFilePath)
	debug('currentFilePath='+currentFilePath)

	found = False
	while len(identifiers)>0:
		identifier = '_'.join(identifiers).replace('/','-') + '.txt'
		filePath= currentFilePath + DATA_FILE_ROOT + '/' +identifier
		debug('filePath='+filePath)

		if os.path.isfile(filePath) != True:
			debug('cannot find file '+filePath)
			del identifiers[-1]
		else:
			found = True
			break


	if found != True:
		debug('cannot find file '+filePath)
		respDict = {"responseStatus":"error", "errorCode":"GE10001"}
	else:
		debug('found file '+filePath)
		f = open(filePath, 'r')
		contents = f.read()
		debug('responseString='+contents)

		respDict = json.loads(contents)

	return respDict

def debug(str):
  if DEBUG_ENABLED:
        sys.stderr.write('[DEBUG] %s - %s\n' % (time.ctime(time.time()), str))
        sys.stderr.flush()
  pass


def renderDictToJson(response_data):
	json_string=json.dumps(response_data)
	debug('response json='+json_string)
	print json_string



def handleRequestDict(reqDict):
	loadSettings();
	identifiers = findIdentifiers(reqDict)

	respDict = getResponseDict(identifiers)

	return respDict

def cgi_main():

	loadSettings();
	data = sys.stdin.read()
	debug('request data=['+data+']')
	response_data={}

	json_request_object = json.loads(data)

	''' response_data['request']=json.dumps(json_request_object)  '''

	print "Content-type:application/json\r\n\r\n"
	response_data=handleRequestDict(json_request_object)

	renderDictToJson(response_data)


# Main program starts here
DEBUG_ENABLED = 1

'''

if __name__ == '__main__':
	debug('enter __main__')

	requestString = '{"cmd":"retrieve","option1":{"birthDate":"05/12/1980","applicationId":"TT1111111"},"option2":null}'
	reqDict= json.loads(requestString)

	contents = handleRequestDict(reqDict)
	debug(contents)
else:

'''
debug('enter cgi_main')
cgi_main()
