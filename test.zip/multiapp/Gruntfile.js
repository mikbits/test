module.exports = function (grunt) {

    var yeomanConfig = {
        app: 'app',
        dist: 'dist',
    };

    // Project configuration.
    grunt.initConfig({
        yeoman: yeomanConfig,
        pkg: grunt.file.readJSON('package.json'),
        
        // Setup the enviroment parms
        // 
        config: {
			dev: {
				options: {
					variables: {
						'concatOptions': {
							maps: [{
								src: "@@iaUri@@",
								rpl: "https://203.112.83.75:30101/multiapp/multiapp/docready/"
							}, {
								src: "@@lnUri@@",
								rpl: "https://203.112.83.75:30101/multiapp/plcontract/"
							}]
						}
					}
				}
			},
			uat: {
				options: {
					variables: {
						'concatOptions': {
							maps: [{
								src: "@@iaUri@@",
								rpl: "https://multiapp-uat.hsbc.com.au/multiapp/docready/"
							}, {
								src: "@@lnUri@@",
								rpl: "https://multiapp-uat.hsbc.com.au/multiapp/plcontract/"
							}]
						}
					}
				}
			},
			prod: {
				options: {
					variables: {
						'concatOptions': {
							maps: [{
								src: "@@iaUri@@",
								rpl: "https://apply.hsbc.com.au/multiapp/docready/"
							}, {
								src: "@@lnUri@@",
								rpl: "https://apply.hsbc.com.au/multiapp/plcontract/"
							}]
						}
					}
				}
			}
        },

        env : {
            dev: {
                NODE_ENV : 'DEVELOPMENT'
            },
            prod : {
                NODE_ENV : 'PRODUCTION'
            }
        },
        
        // Preprocess HTML with directives based off custom or ENV configuration
        preprocess: {
        	prod: {
        		src: ['dist_prd/app/index.html', 'dist_prd/app/creditapp.html'],
        		options: {
        			inline: true,
        			context: {
        				production: true  // important
        			}
        		}
        	},
        	// development version
        	dev: {
        		src: ['dist_dev/app/index.html', 'dist_dev/app/creditapp.html'],
        		options: {
        			inline: true,
        			context: {
        				production: false  // important
        			}
        		}
        	}
        },
        
        clean: {
            options: {
                force: true
            },
            build: ['build'],
            dev: ['dist_dev'],
            prd: ['dist_prd']
        },

        jsvalidate: {
            files: ['app/(js)/**/*.js', 'app/lib/**/*.js', 'app/(creditapp-js)/**/*.js']
        },

		emberTemplates: {
			compile: {
				options: {
					templateName: function(sourceFile) {
						var templatePath = 'app/templates/';
						return sourceFile.replace(templatePath, '');
					}
				},
				files: {
					"build/js/templates_multiapp.js": "app/templates/*.hbs"
				}
			},
			credtiapp: {
				options: {
					templateName: function(sourceFile) {
						var templatePath = 'app/creditapp/';
						return sourceFile.replace(templatePath, '');
					}
				},
				files: {
					"build/js/templates_creditapp.js": "app/creditapp/**/*.hbs"
				}
            }
        },

        jshint: {
            options: {
                curly: false,
                eqeqeq: false,
                eqnull: false,
                browser: false,
                globals: {
                    jQuery: false
                }
            },
            uses_defaults: [ '(js)/**/*.js' ]
        },
        
        
        copy: {
            main: {
                files: [
                    // includes files within path and its sub-directories
                    {expand: true, src: ['app/css/**'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/fonts/**'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/images/**'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/img/**'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/creditapp.html'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/index.html'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/exchangerates/*'], dest: 'dist_dev/'},
                    {expand: true, src: ['app/info/**','!app/info/js/**'], dest: 'dist_dev/'},
                    {expand: true, cwd: 'build',src: ['js/dependencies.js','js/dist_*.js','js/ie.js','info/**'], dest: 'dist_dev/app/'},
                    // copy dependencies to exchangerates folder
                    {expand: true, cwd: 'build/js',src: ['dependencies.js'], dest: 'dist_dev/app/exchangerates/'}                  
                ]
            },
            backend: {
                files: [
                    {expand: true, src: ['backend_emulator/**'], dest: 'build/'},
                    {expand: true, cwd: 'dist_dev/app', src: ['**'], dest: 'build/backend_emulator/multiapp'},
                ]
            },
            backend_emulator: {
                files: [
                	{expand: true, src: ['backend_emulator/**'], dest: 'build/'},
                    {expand: true, cwd: 'build',src: ['js/dependencies.js','js/dist_*.js','js/ie.js'], dest: 'build/backend_emulator/multiapp'},
                ]
            },            
            prd: {
                files: [
                    {expand: true, cwd: 'dist_dev', src: ['app/**'], dest: 'dist_prd/'}
                ]
            }            
        },    

        watch: {
            emberTemplates: {
                files: [ 'app/templates/*.hbs', 'app/creditapp/**/*.hbs', ],
                tasks: [ 'emberTemplates','uglify:dev_target']
            },
            uglify: {
                files: [ 'app/(js)/**/*.js', 'app/(creditapp-js)/**/*.js' ],
                tasks: [ 'neuter:appCreditapp','neuter:appMultiapp', 'uglify:dev_target']
            },
            backend: {
            	files: [ 'backend_emulator/**','build/js/dependencies.js','build/js/dist_*.js','build/js/ie.js'],
            	tasks: ['copy:backend_emulator']
            }
        },
        
        neuter: {
            options: {
                template: "{%= src %}",
                basePath: "./",
                includeSourceMap: true,
                process: function(src, filepath) {
                    var src = '\n\n/**    ' + filepath + '    **/\n\n' + src.replace();

                    var concatOptions = grunt.config.get('concatOptions');
                    var maps = concatOptions.maps;

                    for (var i = 0; i < maps.length; i++) {
                        src = src.replace(maps[i].src, maps[i].rpl);
                    }

                    return src;
                }
                
            },
            dependencies: {
                src: 'build_scripts/req_dependencies.js',
                dest: 'build/js/dependencies.js'
            },            
            appCreditapp: {
                src: 'build_scripts/req_main_creditapp.js',
                dest: 'build/js/main_creditapp.js'
            },
            appMultiapp: {
                src: 'build_scripts/req_main_multiapp.js',
                dest: 'build/js/main_multiapp.js'
            },
            ie: {
                src: 'build_scripts/req_ie.js',
                dest: 'build/js/ie.js'
            }
        },        

       
        uglify: {
            dev_target: {
                options: {
                    mangle: false,
                    compress: false,
                    beautify: true,
                    preserveComments: 'all'
                    
                },
                files: {
                'build/js/dist_creditapp.js': 'build/js/main_creditapp.js',
            'build/js/dist_multiapp.js': ['build/js/main_multiapp.js','build/js/templates_multiapp.js']
                }
            },
            prd_target: {
                files: {
                'dist_prd/app/exchangerates/app.js': 'dist_prd/app/exchangerates/app.js',                
                'dist_prd/app/exchangerates/dependencies.js': 'dist_prd/app/exchangerates/dependencies.js',        
                    'dist_prd/app/js/dist_creditapp.js': 'dist_prd/app/js/dist_creditapp.js',
                'dist_prd/app/js/dist_multiapp.js': 'dist_prd/app/js/dist_multiapp.js',
                'dist_prd/app/js/dependencies.js': 'dist_prd/app/js/dependencies.js',
            'dist_prd/app/js/ie.js': 'dist_prd/app/js/ie.js'                    
                }
            }
        },
        
        htmlmin: {
			prd: {
				options: {
					removeComments: true,
					collapseWhitespace: true
				},
				files: {
					'dist_prd/app/creditapp.html': 'dist_prd/app/creditapp.html',
					'dist_prd/app/index.html': 'dist_prd/app/index.html',
					'dist_prd/app/exchangerates/index.html': 'dist_prd/app/exchangerates/index.html'
				}
			}
		}
        
        
    });


    // Load the plugin that provides the "uglify" task.
    grunt.loadNpmTasks('grunt-contrib-uglify');

 
    // Default task(s).
    grunt.registerTask('default', ['jsvalidate', 'emberTemplates', 'neuter']);
    grunt.registerTask('build', ['default', 'uglify:dev_target', 'copy:main']);
    grunt.registerTask('build_dev_backend', ['dev', 'copy:backend']);

    grunt.registerTask('task', ['clean:build','clean:dev', 'jsvalidate', 'emberTemplates', 'neuter', 'uglify:dev_target', 'copy:main']);  
    grunt.registerTask('dev', ['config:dev', 'task']);
    grunt.registerTask('uat', ['config:uat', 'task']);
    grunt.registerTask('prd', ['config:prod', 'task', 'clean:prd', 'copy:prd', 'uglify:prd_target']);    
    
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-ember-templates');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-jsvalidate');
    grunt.loadNpmTasks('grunt-neuter');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-env');
    grunt.loadNpmTasks('grunt-config');
    grunt.loadNpmTasks('grunt-preprocess');
	
};
