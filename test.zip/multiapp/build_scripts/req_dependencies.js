/**
 * shared javascript libraries
 */
require("app/libs/jquery-1.9.1");
require("app/libs/jquery-ui-1.10.2.custom.js");
require("app/libs/jquery.maskedinput.js");
require("app/libs/jquery.simplemodal.1.4.4.js");
require("app/libs/moment.js");
require("app/libs/prototype.ucwords.js");
require("app/bower_components/handlebars/handlebars.js");
require("app/bower_components/ember/ember.prod.js");