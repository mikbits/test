/**
 * javascript libraries for IE prior to v9
 */
require("app/libs/html5shiv.js");
require("app/libs/json2.js");
