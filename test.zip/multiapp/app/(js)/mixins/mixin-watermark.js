/*****************************************************************************
 * MIXIN Watermark
 *****************************************************************************/


App.Watermark = Ember.Mixin.create({


    /**
     * Methods
     */


    getWatermark:function (field, watermark) {
        return '<div class="watermark" em-field="' + field + '">' + watermark + '</div>';
    },


    displayWatermark:function (field, tagName, watermark) {
        if($("div.watermark[em-field='"+field+"']").size()===0){
            $(tagName + '[em-field="' + field + '"]').before(this.getWatermark(field, watermark));
            // register the hook to handle watermark
            $("div.watermark[em-field='"+field+"']").click( function(){
                $(tagName + '[em-field="' + field + '"]').focus();
            });
        }
    },


    removeWatermark:function (field) {
        $('div.watermark[em-field=' + field + ']').remove();
    }


});