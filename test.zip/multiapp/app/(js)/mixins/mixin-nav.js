/*****************************************************************************
 * MIXIN Navigation
 *****************************************************************************/


App.Nav = Em.Mixin.create({

    validateStep: function($n,$currentStep) {
        var _this = this;
        if($n === 1){
        	_this.goRoute('step1Bundle'+App.get('bundle'));
        }else{
        	_this.goRoute('step' + $n);
        }
        Ember.run.next(this, function() {
            var errors = App.inputErrors;
            errors.clear();
            $('input, select, div.focusOut').trigger('focusout');

            //console.log('Step %@ Error %@ Length %@'.fmt($n,errors.total(),$('.error').length));

            if (errors.total() || $('.error').length) {
                App.ux.scrollFirstError();
                App.setReady();
            } else {
                if ($n < $currentStep) {
                    _this.validateStep($n + 1,$currentStep);
                } else {
                	_this.goRoute('step' + $currentStep);        	
                }
            }
        });
    },	
    /**
     * Methods
     */

	actions: {
		goToStep: function (step) {

	        if (step === 1) {
	            this.goRoute('step1Bundle' + App.get('bundle'));

	        } else {
	            this.goRoute('step' + step);
	        }

	        App.ux.scrollTop();
	    }
	},


    goRoute: function (route) {
        var router = this.get('target');
        router.transitionTo(route);

    },


    goRouteAndReset: function (route) {
        this.goRoute(route);

        // Kill personal data
        App.retrieveData.set('option', null);
        App.set('step1Data', App.Step1Data.create());
        App.set('step2Data', App.Step2Data.create());
        App.set('step3Data', App.Step3Data.create());
        App.set('step4Data', App.Step4Data.create());
        App.set('step5Data', App.Step5Data.create());
        App.set('step6Data', App.Step6Data.create());

        // Reset some App properties
        App.set('refresh', true);
        App.set('isStep0', false);
        App.set('isStep1', false);
        App.set('isStep2', false);
        App.set('isStep3', false);
        App.set('isStep4', false);
        App.set('isStep5', false);
        App.set('isStep6', false);
        App.set('hasSavedStep1', false);
        App.set('hasSavedStep2', false);
        App.set('hasSavedStep3', false);
        App.set('hasSavedStep4', false);
        App.set('hasSavedStep5', false);
        App.set('isStep1Dirty', true);
        App.set('isStep2Dirty', true);
        App.set('isStep3Dirty', true);
        App.set('isStep4Dirty', true);
        App.set('isStep5Dirty', true);
        App.set('lastSavedStepAsJointApp', null);
        App.set('lastSavedStepAsIndividualApp', null);
    }


});