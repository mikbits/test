/*****************************************************************************
 * MIXIN Bundle logic
 *****************************************************************************/


App.BundleLogic = Ember.Mixin.create({


    /**
     * Methods
     */


    hasDtd: function (bundle) {
        return bundle === 1 || bundle === 4 || bundle === 5 || bundle === 6 || bundle === 8 || bundle === 9;
    },


    hasSeriousSaver: function (bundle) {
        return bundle === 3 || bundle === 5;
    },


    hasMultiCurrency: function (bundle) {
        return bundle === 2 || bundle === 6;
    },


    hasOnlineTrading: function (bundle) {
        return bundle === 4 || bundle === 9;
    },


    hasFlexiSaver: function (bundle) {
    	return bundle === 7 || bundle === 8 || bundle === 9 || bundle === 10;
    },


    hasMultipleAccounts: function (bundle) {
        return bundle === 4 || bundle === 5 || bundle === 6 || bundle === 8 || bundle === 9;
    },


    hasCustomerCheck: function () {
        return true;
    },


    /**
     * Step 2
     */


    displayPartnerNames: function () {
        return App.get('bundle') === 2 || App.get('bundle') === 3 || App.get('bundle') === 7;
    }.property('App.bundle'),


    /**
     * Step 5
     */


    displaySaverOptions: function () {
        var bundle = App.get('bundle');
        return bundle === 3;
    }.property('App.bundle'),


    displayD2dStep5: function () {
        var bundle = App.get('bundle');
        return !this.hasDtd(bundle) && (bundle != 3) && (bundle != 2);
    }.property('App.bundle'),


    displayFlexiSaverStep5: function () {
        var bundle = App.get('bundle');
        return !this.hasFlexiSaver(bundle) && !this.hasSeriousSaver(bundle) && (bundle != 2);
    }.property('App.bundle'),


    displayFlexiSaverAndD2dStep5: function () {
        return App.get('bundle') === 2;
    }.property('App.bundle'),


    displayMultiCurrencyStep5: function () {
        var bundle = App.get('bundle');

        if (bundle == 10) return false;

        return !this.hasMultiCurrency(bundle) && (bundle != 4 || bundle != 10);
    }.property('App.bundle'),


    /**
     * Step 6
     */


    subtitle: function () {

        switch (App.get('bundle')) {
            case 1:
                return 'Day to Day account';
            case 2:
                return 'Multi Currency account';
            case 3:
                return 'Serious Saver account';
            case 4:
                return 'Online Share Trading & Day to Day linked accounts';
            case 5:
                return 'Serious Saver & Day to Day linked accounts';
            case 6:
                return 'Multi Currency & Day to Day accounts';
            case 7:
                return 'Flexi Saver account';
            case 8:
                return 'Flexi Saver & Day to Day accounts';
            case 9:
                return 'Wealth Package';
            default:
                return null;
        }

    }.property('App.bundle'),


    displaySeriousSaverEditButton: function () {
        return App.get('bundle') != 5;
    }.property('App.bundle'),


    seriousSaverEditBackAtStart: function () {
        return (App.get('bundle') === 3) && App.step1Data.get('isSaverLinkedToHsbc');
    }.property('App.bundle', 'App.step1Data.isSaverLinkedToHsbc'),


    displayFlexiSaverEditButton: function () {
        var bundle = App.get('bundle');
        return !this.hasFlexiSaver(bundle);
    }.property('App.bundle'),


    displayDtdEditButton: function () {
        return !this.hasDtd(App.get('bundle'));
    }.property('App.bundle'),


    currencyEditBackAtStart: function () {
        return App.get('bundle') === 2 || App.get('bundle') === 6;
    }.property('App.bundle'),


    hideDebitCards: function () {
        var result=false;
        if($.inArray('CMG',App.step5Data.get('accountTypesRe'))<0){
                result = true;
        }
        return result;
    }.property('App.step5Data.accountTypesRe'),


    displayMultiCurrencyStep6: function () {
        return App.step5Data.get('multiCurrency') === true || this.hasMultiCurrency(App.get('bundle'));
    }.property('App.step5Data.multiCurrency', 'App.bundle'),


    displaySeriousSaverStep6: function () {
        var bundle = App.get('bundle');
        return this.hasSeriousSaver(bundle);
    }.property('App.bundle'),


    displayFlexiSaverStep6: function () {
        var bundle = App.get('bundle');
        return (App.step5Data.get('flexiSaver') === true || this.hasFlexiSaver(bundle));
    }.property('App.step5Data.flexiSaver', 'App.bundle'),


    displayOstStep6: function () {
        var bundle = App.get('bundle');
        return bundle === 4 || bundle === 9;
    }.property('App.bundle'),


    displayDtdStep6: function () {
        var result=true;
        if($.inArray('CMG',App.step5Data.get('accountTypesRe'))<0){
                result = false;
        }
        return result;
    }.property('App.step5Data.accountTypesRe'),


    /**
     * Approved page
     */


    isPlural: function () {
        return this.hasMultipleAccounts(App.get('bundle'));
    }.property('App.bundle')


});