/*****************************************************************************
 * MIXIN Options
 *****************************************************************************/


App.Options = Ember.Mixin.create({


    /**
     * Computed properties
     */


    options:function () {
        var $select = $('<select>');

        this.get('content').forEach(function (item) {
            var $option = $('<option>').attr('value', item.code).html(item.name);
            $select.append($option);
        });

        return $select.html();
    }.property('content')


});