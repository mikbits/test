/*****************************************************************************
 * MIXIN List of checkboxes
 *****************************************************************************/
 
 
App.Checkboxes = Ember.Mixin.create({


    /**
     * Methods
     */


    checkboxes:function () {
        var $container = $('<div>');

        this.get('content').forEach(function (item) {
            var $cb = $('<div>').attr('em-code', item.code).addClass('currency');
            var $button = $('<div>').attr('em-code', item.code).addClass('checkboxButton');
            var $label = $('<label>').attr('em-code', item.code).addClass('checkbox').html(item.name);

            $cb.append($button).append($label).append('<br>');
            $container.append($cb);
        });

        return $container.html();
    }.property('content')


});