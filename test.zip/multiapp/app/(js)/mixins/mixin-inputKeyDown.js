/*****************************************************************************
 * MIXIN Input max length
 *****************************************************************************/


App.InputKeyDown = Ember.Mixin.create({


    /**
     * Events
     */


    keyDown:function (e) {
        var target = $(e.target);
        var valid = target.attr('em-valid');
        var ops = [];
        if(valid) {
            ops=valid.split(' ');
        }
        var length = ops.length;

        // Block if max chars reached
        for (var i = 0; i < length; i++) {
            var op = ops[i];

            if (op.substring(0, 3) === 'max' && !this.isOverMax(target.val(), op.split('_')[1] - 1)) {
                if (e.which != 8 && e.which != 9 && e.which != 35 && e.which != 36 && e.which != 37 && e.which != 38 && e.which != 39 && e.which != 40 && e.which != 46) {
                    return false;
                }
            }

        }

        // Block if starts with space
        // depends on jquery.maskedinput.js
        if (this.$().caret().begin === 0 && e.which === 32) {
            return false;
        }

        return true;
    },


    /**
     * Methods
     */


    isOverMax:function (value, max) {
        var string = value || '';
        return string.length <= max;
    }


});