/*****************************************************************************
 * MIXIN Multi currencies
 *****************************************************************************/


App.MultiCurrencies = Ember.Mixin.create({


    /**
     * Methods
     */


    updateCurrencies:function (newMainCurrency) {
        var $button = $('div[em-multi="currencies"]').find('div[em-code="' + newMainCurrency + '"].checkboxButton');

        if ($button.hasClass('checked')) {
            $button.click();
        }

        $('div.currency').removeClass('destroyed');
        $('div[em-code="' + newMainCurrency + '"].currency').addClass('destroyed');
    }


});