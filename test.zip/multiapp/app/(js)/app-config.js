/*****************************************************************************
 * MODEL Step 1
 *****************************************************************************/


App.Config = Ember.Object.extend({


    /**
     * Properties
     */

    captchaType: 1,
    captchaUrlRoot: '/multiapp/captcha',
    locationHost:'localhost:8000',

    jsonApiUrl: function(){
        if(this.get('locationHost') === 'localhost:8000') return 'http://localhost:8000/cgi-bin/dummyserver.py';
        return 'multiapp';
    }.property('locationHost'),


    isImageCaptchaType:function(){
    	return this.get('captchaType')==1;
    }.property('captchaType')

});


App.config = App.Config.create();
App.config.set('locationHost',window.location.host);