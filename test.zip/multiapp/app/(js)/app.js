/*****************************************************************************
 * APPLICATION
 *****************************************************************************/

// identify version of IE browser
for(var ie=-1,b=document.createElement("b");b.innerHTML="<!--[if gt IE "+ ++ie+"]>1<![endif]-->",+b.innerHTML;);


window.App = Ember.Application.create({


    /**
     * System settings
     */

    jsonTimeOut: 240000, // ms
    scrollSpeed: 500, // ms
    previousAddressTrigger: 3, // Customers have to fill previous address if nb of years at current address < x years
    inputTimer: 1000, // ms

    /**
     * System global variables
     */


    isBusy: true,
    refresh: true,
    refreshStep1: false,
    applicationId: null,
    bundle: null,
    isNotStep: false,
    isStep0: false,
    isStep1: false,
    isStep2: false,
    isStep3: false,
    isStep4: false,
    isStep5: false,
    isStep6: false,
    isStep7: false,
    hasSavedStep1: false,
    hasSavedStep2: false,
    hasSavedStep3: false,
    hasSavedStep4: false,
    hasSavedStep5: false,
    isStep1Dirty: true,
    isStep2Dirty: true,
    isStep3Dirty: true,
    isStep4Dirty: true,
    isStep5Dirty: true,
    lastSavedStepAsJointApp: null,
    lastSavedStepAsIndividualApp: null,


    /**
     * Methods
     */


    getCurrentStep: function () {

        for (var i = 0; i <= 7; i++) {

            if (this.get('isStep' + i)) {
                return i;
            }

        }

        return null;
    },


    setCurrentStepDirty: function () {
        this.set('isStep' + this.getCurrentStep() + 'Dirty', true);
    },


    nothingDirtyUntil: function (step) {
        for (var i = 1; i <= step; i++) {
            this.set('isStep' + i + 'Dirty', false);
        }
    },


    nothingSaved: function () {
        for (var i = 1; i <= 6; i++) {
            this.set('hasSavedStep' + i, false);
        }
    },


    getLastSavedStep: function () {
        var lastSaved = null;

        for (var i = 1; i <= 6; i++) {
            if (this.get('hasSavedStep' + i)) {
                lastSaved = i;
            }
        }

        return lastSaved;
    },


    setSavedUntil: function (step) {
        for (var i = 1; i <= step; i++) {
            this.set('hasSavedStep' + i, true);
        }
    },


    getCurrentStepData: function () {
        var step = this.getCurrentStep();

        switch (step) {

            case 0:
                return App.rampData;
                break;

            case 1:
                return App.step1Data;
                break;

            case 2:
                return App.step2Data;
                break;

            case 3:
                return App.step3Data;
                break;

            case 4:
                return App.step4Data;
                break;

            case 5:
                return App.step5Data;
                break;

            case 6:
                return App.step6Data;
                break;

            case 7:
                return App.selfIdData;
                break;

            default:
                return null;

        }
    },


    setStep: function (step, bundle) {
        if (bundle) this.set('bundle', bundle);

        for (var i = 0; i <= 7; i++) {
            this.set('isStep' + i, i === step);
        }

    },

    setBusy: function () {
        this.set('isBusy', true);
        $('div#busy').modal({focus: false});
        $('a.modalCloseImg').remove();
    },


    setReady: function () {
        this.set('isBusy', false);
        $.modal.close();
    },


    /**
     * Life cycle hooks
     */


    ready: function () {
        $(document).tooltip();
        $(document).on('focus', '.hasDatepicker', function() {
            $(this).val('');
        });
    }


});


App.reopen({


    /**
     * Veda Properties
     */


    checkVeda: true,


    /**
     * Veda Methods
     */


    checkGeoCoder: function () {
        App.callVeda('580 George St Sydney NSW 2000', 'ValidateAddress');
    },


    callVeda: function (address, endPoint) {
        var params = { address: address };
        //console.log('params: ' + JSON.stringify(params));

        $.ajax({
            url: 'https://geocoderweb.veda.com.au/' + endPoint + '?max=5',
            data: params, // data sent to server
            dataType: "jsonp", // Type of response received from server

            error: function () {
                App.vedaResponse.setProperties({ ajaxStatus: false, response: null });
            },

            success: function (response) {
                //console.log(JSON.stringify(response));
                App.vedaResponse.setProperties({ ajaxStatus: true, response: response });
            },

            timeout: 5000
        });

    }


});