/*****************************************************************************
 * ROUTER
 *****************************************************************************/


App.Router.map(function () {
    this.resource('ramp');
    this.resource('retrieve');
    this.resource('chooseApp');
    this.resource('timeout');
    this.resource('error');
    this.resource('errorAjax');
    
    this.resource('selfId');
    this.resource('pendingId');
    this.resource('processing');
    this.resource('approved');
   
    this.resource('step1Bundle1', {path: '/step1/bundle1'});
    this.resource('step1Bundle2', {path: '/step1/bundle2'});
    this.resource('step1Bundle3', {path: '/step1/bundle3'});
    this.resource('step1Bundle4', {path: '/step1/bundle4'});
    this.resource('step1Bundle5', {path: '/step1/bundle5'});
    this.resource('step1Bundle6', {path: '/step1/bundle6'});
    this.resource('step1Bundle7', {path: '/step1/bundle7'});
    this.resource('step1Bundle8', {path: '/step1/bundle8'});
    this.resource('step1Bundle9', {path: '/step1/bundle9'});
    this.resource('step1Bundle10', {path: '/step1/bundle10'});
    this.resource('step2');
    this.resource('step3');
    this.resource('step4');
    this.resource('step5');
    this.resource('step6');
    this.resource('crxRetrieve');
});


/*****************************************************************************
 * CLASSES
 *****************************************************************************/


// Retrieve, timeout or error page
App.Step0 = Ember.Route.extend({

    activate: function () {
        App.set('isNotStep', true);
        App.set('isBusy', false); // To display the page
    },

    model: function () {
        return App.retrieveData;
    }

});


// Step 1-6 Route
App.StepRoute = Ember.Route.extend({

    activate: function () {

        if (App.get('refresh') === true) {
            App.set('refresh', false);
            this.controllerFor('jsonRefresh').run();
        }

        if (App.get('checkVeda') === true) {
            App.set('checkVeda', false);
            App.checkGeoCoder();
        }

    }

});


// Step 1 all bundles
App.Step1 = App.StepRoute.extend({
    bundle: null,

    activate: function () {
        App.set('isNotStep', false);
        App.setStep(1, this.get('bundle'));
        this._super();
    },

    model: function () {
        return App.step1Data;
    }

});


// Step 2-6
App.StepIn = App.StepRoute.extend({
    step: null,

    activate: function () {
        App.set('isNotStep', false);
        App.setStep(this.get('step'));
        this._super();
    }

});

// Response pages
App.StepOut = Ember.Route.extend({

    activate: function () {
        App.set('isNotStep', true);
        App.set('isBusy', false); // To display the page

        if (App.get('refresh') === true) {
            App.set('refresh', false);
            this.controllerFor('jsonRefresh').run();
        }

    },

    model: function () {
        return App.responseData;
    }

});


/*****************************************************************************
 * ROUTE INDEX
 *****************************************************************************/


App.IndexRoute = Ember.Route.extend({

    redirect: function () {
        this.transitionTo('retrieve');
    }

});


/*****************************************************************************
 * ROUTES STEP 0
 *****************************************************************************/


App.RampRoute = App.Step0.extend({

    activate: function () {
        App.setStep(0);
        App.set('isNotStep', true);
        App.set('isBusy', false); // To display the page
    },

    model: function () {
        return App.rampData;
    }

});

App.TimeoutRoute = App.Step0.extend();
App.RetrieveRoute = App.Step0.extend();
App.ErrorRoute = App.Step0.extend();
App.ErrorAjaxRoute = App.Step0.extend();
App.ChooseAppRoute = App.Step0.extend();


/*****************************************************************************
 * ROUTES STEPS 1-6
 *****************************************************************************/


App.Step1Bundle1Route = App.Step1.extend({
    bundle: 1
});


App.Step1Bundle2Route = App.Step1.extend({
    bundle: 2
});


App.Step1Bundle3Route = App.Step1.extend({
    bundle: 3
});


App.Step1Bundle4Route = App.Step1.extend({
    bundle: 4
});


App.Step1Bundle5Route = App.Step1.extend({
    bundle: 5
});


App.Step1Bundle6Route = App.Step1.extend({
    bundle: 6
});


App.Step1Bundle7Route = App.Step1.extend({
    bundle: 7
});


App.Step1Bundle8Route = App.Step1.extend({
    bundle: 8
});


App.Step1Bundle9Route = App.Step1.extend({
    bundle: 9
});

App.Step1Bundle10Route = App.Step1.extend({
    bundle: 10
});

App.Step2Route = App.StepIn.extend({
    step: 2,

    model: function () {
        return App.step2Data;
    }

});


App.Step3Route = App.StepIn.extend({
    step: 3,

    model: function () {
        return App.step3Data;
    }

});


App.Step4Route = App.StepIn.extend({
    step: 4,

    model: function () {
        return App.step4Data;
    }

});


App.Step5Route = App.StepIn.extend({
    step: 5,

    model: function () {
        return App.step5Data;
    }

});


App.Step6Route = App.StepIn.extend({
    step: 6,

    model: function () {
        return App.step6Data;
    }

});


/*****************************************************************************
 * ROUTES REPONSE PAGES
 *****************************************************************************/


App.SelfIdRoute = App.StepOut.extend({

    activate: function () {
        App.setStep(7);
        this._super();
    },

    model: function () {
        return App.selfIdData;
    }

});

App.PendingIdRoute = App.StepOut.extend();
App.ProcessingRoute = App.StepOut.extend();
App.ApprovedRoute = App.StepOut.extend();