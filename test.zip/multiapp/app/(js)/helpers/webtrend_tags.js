/*****************************************************************************
 * WebTrend Tag Handlerbar Helpers
 * Usage:
 *     {{WebTrendTagAllPageStart page="1"}}
 *     {{WebTrendTagFirstPageStart bundleBinding="App.bundle"}}
 *     {{WebTrendTagResultPageStart productsBinding="App.step5Data.accountTypesRe"}}
 *
 * Notes:
 *
 *      - page is the identifier of any page
 *****************************************************************************/


Ember.Handlebars.registerBoundHelper('WebTrendTagAllPageStart', function(options) {
    var bundle = options.hash['bundle'];
    var pageIdentifier = options.hash['page'];
    if (!pageIdentifier) {
        pageIdentifier = 'unknown';
    }

    // reset first page, last page tag
    HSBC.EXT.HSBC_e = null;
    HSBC.EXT.HSBC_u = null;
    HSBC.PAGE.pn_sku = null;
    HSBC.PAGE.si_n = null;
    HSBC.PAGE.si_x = null;
    HSBC.PAGE.tx_e = null;
    HSBC.PAGE.tx_i = null;
    HSBC.PAGE.tx_id = null;
    HSBC.PAGE.tx_it = null;
    HSBC.PAGE.tx_s = null;
    HSBC.PAGE.tx_u = null;
    HSBC.PAGE.decisionstatus = null;

    // start of all page tag
    HSBC.SITE.rgn = "Asia Pacific";
    HSBC.SITE.subrgn = "Rest of Asia Pacific";
    HSBC.SITE.cnty = "Australia";
    HSBC.SITE.ent = "HSBC Bank Australia Limited";
    HSBC.SITE.brand = "HSBC";
    HSBC.DCS.ID = "dcsoerk141000004jdy7sftrk_3m8z";
    HSBC.SITE.cam = "0";


    HSBC.DCS.DOMS = "www.hsbc.com.au,www.apps.asiapacific.hsbc.com,mmw.hsbc.com.au,online.hsbc.com.au,sharetrading.hsbc.com.au,apply.hsbc.com.au,credit.hsbc.com.au";


    var thisSiteType = "Public";
    HSBC.SITE.custgrp = "PFS";
    HSBC.SITE.busline = "General";
    HSBC.SITE.prodline = "Savings Accounts";
    HSBC.SITE.site = thisSiteType.substring(thisSiteType.indexOf('\;') + 1);
    HSBC.SITE.ibtype = thisSiteType.substring(0, thisSiteType.indexOf('\;'));
    HSBC.PAGE.cg_n = thisSiteType;
    HSBC.SITE.language = "en";

    switch (pageIdentifier) {
        case 'AP':
        
            HSBC.PAGE.decisionstatus = 'Approved';
            break;

        case 'ND':
        case 'PI':
        case 'SI':
            HSBC.PAGE.decisionstatus = 'Pending';



            break;

        case 'GE':
        case 'AE':
            HSBC.PAGE.decisionstatus = 'Declined';

            break; 
    }



    HSBC.LOG.dcsuri = '/furl/Content Root/Home/AUH2/Multi Account Application/Formid=auh2_deposits_bundle' + bundle + ',CurrentStep=' + pageIdentifier;

    var tag = '<span class="WebTrendTagAllPageStart"></span>';
    return new Handlebars.SafeString(tag);
});


Ember.Handlebars.registerBoundHelper('WebTrendTagAllPageEnd', function(options) {
    if (_tag) {
        _tag.dcsCollect();
    }

    var tag = '<span class="WebTrendTagAllPageEnd"></span>';
    return new Handlebars.SafeString(tag);
});

Ember.Handlebars.registerBoundHelper('WebTrendTagFirstPageStart', function(options) {
    var bundle = options.hash['bundle'];
    var prods = 'unknow';
    if (bundle) {
        prods = bundleToWebtrendProds(bundle);
    }
    if (typeof(HSBC) != "undefined") {
        HSBC.PAGE.pn_sku = prods;
        HSBC.EXT.HSBC_u = "1";
        HSBC.EXT.HSBC_e = "apst";
        HSBC.PAGE.si_n = "ProdConvAll";
        HSBC.PAGE.si_x = "2";
    }
    var tag = '<span class="WebTrendTagFirstPageStart"></span>';
    return new Handlebars.SafeString(tag);
});

function webTrendTagResultPageStart(products, sku) {
    var allProdCodeArray = products;
    var prods = 'unknow';
    if (allProdCodeArray) {
        prods = webTrendCrossSaleProdCodes(allProdCodeArray);
    }

    var curDateTime = new Date();
    var randNo = Math.round(Math.abs(Math.sin(curDateTime.getTime())) * 1000000000) % 10000000;
    var curHour = curDateTime.getHours();
    var curMin = curDateTime.getMinutes();
    var curSec = curDateTime.getSeconds();
    var curTime = ((curHour < 10) ? "0" : "") + curHour + ":" + ((curMin < 10) ? "0" : "") + curMin + ":" + ((curSec < 10) ? "0" : "") + curSec;

    var today = new Date();
    var month = today.getMonth() + 1;
    var year = today.getYear();
    var day = today.getDate();
    var curDate = "";
    if (day < 10) day = "0" + day;
    if (month < 10) month = "0" + month;
    if (year < 1000) year += 1900;
    curDate = month + "/" + day + "/" + year;

    HSBC.PAGE.pn_sku = prods;
    HSBC.PAGE.tx_u   = "1";
    HSBC.PAGE.tx_e   = "p";
    HSBC.PAGE.tx_s   = prods;
    HSBC.PAGE.tx_i   = randNo;
    HSBC.PAGE.tx_it  = curTime;
    HSBC.PAGE.tx_id  = curDate;
    HSBC.EXT.HSBC_u  = "1";
    HSBC.EXT.HSBC_e  = "apsu";
    HSBC.PAGE.si_n   = "ProdConvAll";
    HSBC.PAGE.si_x   = "3";

    if (_tag) {
        // Send application submit event based on the value of the Webtrends variable hsbc.e="apsu" for Causata
        // commented out on 10-03-2014 to remove the tag logic
        //jsHub.trigger('application-submit', {'custom-event': 'true', 'wt-pn-sku': HSBC.PAGE.pn_sku, 'wt-tx-u': HSBC.PAGE.tx_u, 'wt-tx-e': HSBC.PAGE.tx_e, 'wt-tx-s': HSBC.PAGE.tx_s, 'wt-tx-i': HSBC.PAGE.tx_i, 'wt-tx-it': HSBC.PAGE.tx_it, 'wt-tx-id': HSBC.PAGE.tx_id, 'hsbc-u': HSBC.EXT.HSBC_u, 'hsbc-e': HSBC.EXT.HSBC_e, 'wt-si-n': HSBC.PAGE.si_n, 'wt-si-x': HSBC.PAGE.si_x  });
        _tag.dcsCollect();
    }
}


function bundleToWebtrendProds(bundle) {
    var bundleString = '' + bundle;
    var prodCodes = 'unknown';

    switch (bundleString) {
        case "1":
            prodCodes = 'AUH_SavingsOSA01'; // day to day
            break;
        case "2":
            prodCodes = 'AUH_SavingsMCA01'; // multicurrency
            break;
        case "3":
            prodCodes = 'AUH_SavingsSS01'; // Serious Saver
            break;
        case "4":
            prodCodes = 'AUH_SavingsOSA01;AUH_InvestBroking01'; // day to day + online share trading
            break;
        case "5":
            prodCodes = 'AUH_SavingsOSA01;AUH_SavingsSS01'; // day to day + SeriousSaver
            break;
        case "6":
            prodCodes = 'AUH_SavingsOSA01;AUH_SavingsMCA01'; // day to day + MultiCurrency
            break;
        case "7":
            prodCodes = 'AUH_SavingsFSA01'; // Flexi Saver
            break;
        case "8":
            prodCodes = 'AUH_SavingsOSA01;AUH_SavingsFSA01'; // day to day + Flexi Saver
            break;
        case "9":
            prodCodes = 'AUH_SavingsOSA01;AUH_InvestBroking01;AUH_SavingsFSA01'; // day to day + online share trading + Flexi Saver
            break;
    }
    return prodCodes;
};

function webTrendCrossSaleProdCodes(allProdCodeArray) {
    var crossSaleProdCodes = '';
    if (allProdCodeArray) {
        var allCodes = [];
        allProdCodeArray.forEach(function(item) {
            switch (item) {
                case "CMG":
                    allCodes.push('AUH_SavingsOSA01');
                    break;
                case "MSV":
                    allCodes.push('AUH_SavingsMCA01');
                    break;
                case "SSP":
                    allCodes.push('AUH_SavingsSS01');
                    break;
                case "OST":
                    allCodes.push('AUH_InvestBroking01');
                    break;
                case "ACS":
                    allCodes.push('AUH_SavingsFSA01');
                    break;
            }
        });

        allCodes.forEach(function(item) {
            if (crossSaleProdCodes) {
                crossSaleProdCodes = crossSaleProdCodes + ';' + item;
            } else {
                crossSaleProdCodes = item;
            }
        });
    }
    return crossSaleProdCodes;
};