Ember.Handlebars.registerBoundHelper('LivePersonTagAllPageStart', function(options) {
    var bundle=options.hash['bundle'];
    var page=options.hash['page'];
    conversionStageNumber = pageToLPConversionStageNumber(page)
    conversionStage = pageToLPConversionStage(page)

    var section = 'ba-application';
    section = section + bundleToLivePersonSectionProd(bundle)
    
    var errorName = options.hash['errorName'];
    
    // reset first page, last page tag
    var pageVars = [
  		{ scope:'page', name:'unit', value:'sales-bank-accounts', mobile:true }, 
      	{ scope:'page', name:'Section', value:section, mobile:true },
      	{ scope:'page', name:'ConversionStageNumber', value:conversionStageNumber, mobile:true }, 
      	{ scope:'page', name:'ConversionStage', value:conversionStage, mobile:true },
      	{ scope:'page', name:'ErrorName', value:errorName, mobile:true },
     ];
    
    lpTag.section = 'sales-bank-accounts' //give lpTag.section the same value as 'unit'
    lpTag.vars.push(pageVars);
    
    var tag='<span class="LivePersonTagAllPageStart"></span>';
    return new Handlebars.SafeString(tag);
});

function pageToLPConversionStageNumber(page){
	 if(!page){
		 conversionStageNumber='';
	 }
	 
	 var pageString = ''+page;
	 
	 switch (pageString){
	 	case "1":
	 		conversionStageNumber = '1';
	 		break;
	 	case "2":
	 		conversionStageNumber = '2';
	 		break;
	 	case "3":
	 		conversionStageNumber = '3';
	 		break;
	 	case "4":
	 		conversionStageNumber = '4';
	 		break;
	 	case "5":
	 		conversionStageNumber = '5';
	 		break;
	 	case "6":
	 		conversionStageNumber = '6';
	 		break;
	 	default:
	 		conversionStageNumber = ''; 
	 		break;
	 }
	 return conversionStageNumber;
}

function pageToLPConversionStage(page){
	 if(!page){
		conversionStage='';
	 }
	 
	 var pageString = ''+page;
	 
	 switch (pageString){
	 	case "AP":
	 		conversionStage = 'approved';
	 		break;
	 	case "PI":
	 		conversionStage = 'pendingId';
	 		break;
	 	case "SI":
	 		conversionStage = 'selfId';
	 		break;
	 	case "ND":
	 		conversionStage = 'processing';
	 		break;
	 	case "MM":
	 		conversionStage = 'chooseApp';
	 		break;
	 	case "RE":
	 		conversionStage = 'retrieve';
	 		break;
	 	case "1":
	 		conversionStage = 'Step 1';
	 		break;
	 	case "2":
	 		conversionStage = 'Step 2';
	 		break;
	 	case "3":
	 		conversionStage = 'Step 3';
	 		break;
	 	case "4":
	 		conversionStage = 'Step 4';
	 		break;
	 	case "5":
	 		conversionStage = 'Step 5';
	 		break;
	 	case "6":
	 		conversionStage = 'Step 6';
	 		break;
	 	default:
	 		conversionStage = '';
	 		break;
	 }
	 
	 return conversionStage;
}

function bundleToLivePersonSectionProd(bundle){
    var bundleString = ''+bundle;
    var prodCodes='unknown';

    switch (bundleString) {
        case "1":
            prodCodes = '-cmg';   // day to day
        break;
        case "2":
            prodCodes = '-msv';   // multicurrency
        break;
        case "3":
            prodCodes = '-ssp';   // Serious Saver
        break;
        case "4":
            prodCodes = '-ost-cmg';   // day to day + online share trading
        break;
        case "5":
            prodCodes = '-ssp-cmg';   // day to day + SeriousSaver
        break;
        case "6":
            prodCodes = '-msv-cmg';   // day to day + MultiCurrency
        break;
        case "7":
            prodCodes = '-asc';   // Flexi Saver
        break;
        case "8":
            prodCodes = '-cmg-acs';   // day to day + Flexi Saver
        break;
        case "9":
            prodCodes = '-ost';   // day to day + online share trading + Flexi Saver
        break;
    }
    return prodCodes;
};

function bundleToProdCodes(bundle) {
    var bundleString = '' + bundle;
    var prodCodes = 'unknown';

    switch (bundleString) {
        case "1":
            prodCodes = 'CMG';   // day to day
            break;
        case "2":
            prodCodes = 'MSV';   // multicurrency
            break;
        case "3":
            prodCodes = 'SSP';   // Serious Saver
            break;
        case "4":
            prodCodes = 'CMG & OST';   // day to day + online share trading
            break;
        case "5":
            prodCodes = 'CMG & SSP';   // day to day + SeriousSaver
            break;
        case "6":
            prodCodes = 'CMG & MSV';   // day to day + MultiCurrency
            break;
        case "7":
            prodCodes = 'ACS';   // Flexi Saver
            break;
        case "8":
            prodCodes = 'CMG & ACS';   // day to day + Flexi Saver
            break;
        case "9":
            prodCodes = 'OST';   // day to day + online share trading + Flexi Saver
            break;
    }
    return prodCodes;
};


function livePersonTagOnSubmitClickStart(appNumber, bundle) {
	var bundleString = '' + bundle;
	
	productName = bundleToProdCodes(bundle);
	
	var OnClickVars = [        
	        { scope:'page', name:'ConversionAction', value:'Submitted', mobile:true  },
	        { scope:'page', name:'OrderNumber', value:''+appNumber, mobile:true  },
	        { scope:'page', name:'OrderTotal', value:'1', mobile:true  },
	        { scope:'page', name:'Product_Name', value:productName, mobile:true  }
   		];
   		
   	if (typeof(LPMobile) !== "undefined") {  
   		for (var i = 0; i < OnClickVars.length; i++) {  
   			if (OnClickVars[i].mobile) {  
   				LPMobile.reportEvent(OnClickVars[i].name,OnClickVars[i].value);  
   			}  
   		}  
   	}

   	else {  
   		lpTag.vars.push(OnClickVars);  
   		try{  
   			lpTag.vars.send();  
   		} catch(e) {}  
   	}  
}