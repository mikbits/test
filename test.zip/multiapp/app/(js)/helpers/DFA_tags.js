/*****************************************************************************
 * DFA Tag Handlerbar Helpers
 * Usage:
 *     {{DFATag bundle="1" productsBinding="App.step5Data.accountTypesRe" applicationIdBinding="App.applicationId" page="1" pageType="S"}}
 *     {{DFATag status="P" errorBinding=App.responseData.errorCode}}
 *     {{DFATag statusBinding="App.responseData.responseCode" errorBinding="App.responseData.errorCode"}}
 *
 * Notes:
 *     - pageType="S" means start page
 *     - pageType="E" means end page/last page/thank you page/error page
 *
 *      - page is the identifier of any page
 *
 *****************************************************************************/



Ember.Handlebars.registerBoundHelper('DFATag', function (options) {

	

    var bundle = options.hash['bundle'];
    
    if (!bundle) return;
    
    var allProdCodeArray = options.hash['products'];
    var pageIdentifier = options.hash['page'];
    var applicationId = options.hash['applicationId'];
    var status = options.hash['status'];
    var errorCode = options.hash['error'];
    var pageType = options.hash['pageType'];

   
    var axel = Math.random() + "";
    var randomNumber = axel * 10000000000000;
    var u1 = (applicationId ? applicationId : '');                                   //[Application  ID];
    var u2 = 'multiapp';                                      //[Source Code ]
    var u3 = (status ? status : '');                                          //[Status ]
    var u4 = bundleToProdCodes(bundle);                       //[Pre-Selected Products]
    var u5 = '1';                                             //[Revenue]
    var u6 = (applicationId ? applicationId : '');                                   //[Reference Code]
    var u7 = (errorCode ? errorCode : '');                                       //[Error Code];
    var u8 = (pageIdentifier ? pageIdentifier : '');                                  //[Step Number];
    var u9 = crossSaleProdCodes(bundle, allProdCodeArray);    // [Cross-sale products]
    var u10 = (pageType ? pageType : '');
    var u19 = '';
    if ($(window).width() < 480) {
        var u18 = 'Mobile';
    } else {
    	var u18 = 'Desktop';
    }// [type of page, either S which means start or E which means end]
    
    if (u9) {
    	var u19 = 0;
    } else {
    	var u19 = 1;
    }
    

    //tag = tag + dfaProducts(bundle, allProdCodeArray);
    
    var axel = Math.random() + "";
    var a = axel * 10000000000000;
    
    //tag = tag + 'u18=' + u18 + ';ord=' + randomNumber + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';
    var tag = '<iframe src="https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=multi494;u2='+u2+';u3='+u3+';u4='+u4+';u5='+u5+';u6='+u6+';u7='+u7+';u8='+u8+';u18='+u18+';u9='+u9+';u10='+u10+';u1='+u1+';ord=1;num=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';
    tag += '<iframe src="https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=multi754;u2='+u2+';u3='+u3+';u4='+u4+';u5='+u5+';u6='+u6+';u7='+u7+';u8='+u8+';u18='+u18+';u9='+u9+';u10='+u10+';u1='+u1+';ord=1;num=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';
    
    return new Handlebars.SafeString(tag);
});


function bundleToProdCodes(bundle) {
    var bundleString = '' + bundle;
    var prodCodes = 'unknown';

    switch (bundleString) {
        case "1":
            prodCodes = 'CMG';   // day to day
            break;
        case "2":
            prodCodes = 'MSV';   // multicurrency
            break;
        case "3":
            prodCodes = 'SSP';   // Serious Saver
            break;
        case "4":
            prodCodes = 'CMG|OST';   // day to day + online share trading
            break;
        case "5":
            prodCodes = 'CMG|SSP';   // day to day + SeriousSaver
            break;
        case "6":
            prodCodes = 'CMG|MSV';   // day to day + MultiCurrency
            break;
        case "7":
            prodCodes = 'ACS';   // Flexi Saver
            break;
        case "8":
            prodCodes = 'CMG|ACS';   // day to day + Flexi Saver
            break;
        case "9":
            prodCodes = 'CMG|OST|ACS';   // day to day + online share trading + Flexi Saver
            break;
    }
    return prodCodes;
};

/**
 *
 * @param bundle
 * @param allProdCodeArray
 * @returns {string} CMG|OST|MSV Returns string that is not part of the orignal bundle.
 */
function crossSaleProdCodes(bundle, allProdCodeArray) {
    var crossSaleProdCodes = '';
    if (allProdCodeArray) {
        var allCodes = [];
        allProdCodeArray.forEach(function (item) {
            allCodes.push(item);
        });
        var bundleString = '' + bundle;

        switch (bundleString) {
            case "1":
                allCodes.removeObject('CMG');
                break;
            case "2":
                allCodes.removeObject('MSV');
                break;
            case "3":
                allCodes.removeObject('SSP');
                break;
            case "4":
                allCodes.removeObject('CMG');
                allCodes.removeObject('OST');
                break;
            case "5":
                allCodes.removeObject('CMG');
                allCodes.removeObject('SSP');
                break;
            case "6":
                allCodes.removeObject('CMG');
                allCodes.removeObject('MSV');
                break;
            case "7":
                allCodes.removeObject('ACS');
                break;
            case "8":
                allCodes.removeObject('CMG');
                allCodes.removeObject('ACS');
                break;
            case "9":
                allCodes.removeObject('CMG');
                allCodes.removeObject('OST');
                allCodes.removeObject('ACS');
                break;
        }

        allCodes.forEach(function (item) {
            if (crossSaleProdCodes) {
                crossSaleProdCodes = crossSaleProdCodes + '|' + item;
            } else {
                crossSaleProdCodes = item;
            }
        });
    }
    return crossSaleProdCodes;
};

function dfaBundleToCode(bundle, allProdCodeArray) {
	var allCodes = [];
    var bundleString = '' + bundle;

    switch (bundleString) {
        case "1":
            allCodes.push('CMG');   // day to day
            break;
        case "2":
            allCodes.push('MSV');   // multicurrency
            break;
        case "3":
            allCodes.push('SSP');   // Serious Saver
            break;
        case "4":
            allCodes.push('CMG');   // day to day + online share trading
            allCodes.push('OST');   // day to day + online share trading
            break;
        case "5":
            allCodes.push('CMG');   // day to day + SeriousSaver
            allCodes.push('SSP');   // day to day + SeriousSaver
            break;
        case "6":
            allCodes.push('CMG');   // day to day + MultiCurrency
            allCodes.push('MSV');   // day to day + MultiCurrency
            break;
        case "7":
            allCodes.push('ACS');   // Flexi Saver
            break;
        case "8":
            allCodes.push('CMG');   // day to day + Flexi Saver
            allCodes.push('ACS');   // day to day + Flexi Saver
            break;
        case "9":
            allCodes.push('CMG');   // day to day + online share trading + Flexi Saver
            allCodes.push('OST');   // day to day + online share trading + Flexi Saver
            allCodes.push('ACS');   // day to day + online share trading + Flexi Saver
            break;
    }


    if (allProdCodeArray) {
        allProdCodeArray.forEach(function (item) {
            if (allCodes.indexOf(item) == -1) {
                allCodes.push(item);
            }
        });
    }
    
    return allCodes;
}

function dfaGetCodeFromBundle(bundle, allProdCodeArray) {
	var allCodes = dfaBundleToCode(bundle, allProdCodeArray);
	
	var products = [];
	
	['CMG', 'MSV', 'SSP', 'ACS', 'OST', 'NAF'].forEach(function (item) {
        if (allCodes.indexOf(item) != -1) {
            products.push(item);
        }
    });
	
	return products;
}

function dfaProducts(bundle, allProdCodeArray) {
    var allCodes = dfaBundleToCode(bundle, allProdCodeArray);

    var products = '';
    var productNumber = 11;
    ['CMG', 'MSV', 'SSP', 'ACS', 'OST', 'NAF'].forEach(function (item) {
        products = products + 'u' + productNumber + '=';
        productNumber = productNumber + 1;
        if (allCodes.indexOf(item) == -1) {
            products = products + '0;';
        } else {
            products = products + '1;';
        }
    });

    return products;
};

function callStaticFloodLight() {
    var axel = Math.random() + "";
    var num = axel * 1000000000000000000;
    var tag_url = new Image();
    tag_url.src = "https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=liabi840;ord=1;num=" + num + "?";
};


function callDynamicFloodLight(applicationId, bundle, allProdCodeArray) {

	

    var u1 = applicationId;                                   //[Application  ID];
    var u2 = 'multiapp';
    var u4 = bundleToProdCodes(bundle);                       //[Pre-Selected Products]
    var u5 = '1';                                             //[Revenue]
    var u6 = applicationId;                                   //[Reference Code]
    var u9 = crossSaleProdCodes(bundle, allProdCodeArray);    // [Cross-sale products]
    var u7 = '';



    var axel = Math.random() + "";
    var a = axel * 10000000000000;

    // u11 to u20
    
    var tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=liabi840;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u7=' + u7 + ';u9=' + u9 + ';' + dfaProducts(bundle, allProdCodeArray) + 'u1=' + u1 + ';ord=1;num=' + a + '?';
    
    var flDiv = null;
    if (document.getElementById("DCLK_FLDiv")) {
        flDiv = document.getElementById("DCLK_FLDiv");
    } else {
        flDiv = document.body.appendChild(document.createElement("div"));
        flDiv.id = "DCLK_FLDiv";
        flDiv.style.display = "none";
    }

    var DCLK_FLIframe = document.createElement("iframe");
    DCLK_FLIframe.id = "DCLK_FLIframe_" + Math.floor(Math.random() * 10000000000000);
    DCLK_FLIframe.src = tag;
    flDiv.appendChild(DCLK_FLIframe);


    $.each(u4.split('|'), function(k, v) {
        var u19 = 1;
        addLayer1(flDiv, v, u1, u2, u4, u5, u6, u9, u19);
    });

    $.each(u9.split('|'), function(k, v) {
        var u19 = 0;
        addLayer1(flDiv, v, u1, u2, u4, u5, u6, u9, u19);
    });


};

function addLayer1(flDiv, v, u1, u2, u4, u5, u6, u9, u19) {
    if (v) {

        var tag = '';
        var axel = Math.random() + "";
        var a = axel * 10000000000000;

        switch(v) {
            case 'CMG':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=dayto238;cat=hsbcd672;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'MSV':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=multi475;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'SSP':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=ssfin633;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'ACS':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=flexi524;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'OST':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=ostth749;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'NAF':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=hsbcc134;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            default:
                return false;
                break;
        }


        var DCLK_FLIframe = document.createElement("iframe");
        DCLK_FLIframe.id = "DCLK_FLIframe_" + Math.floor(Math.random() * 10000000000000);
        DCLK_FLIframe.src = tag;
        flDiv.appendChild(DCLK_FLIframe);

        return true;

    }
    return false;
}




