/*****************************************************************************
 * CONTROLLER Choose app
 *****************************************************************************/
 
 
App.ChooseAppController = Ember.ObjectController.extend({


    /**
     * Dependencies
     */


    needs:['jsonRetrieve'],


    /**
     * Methods
     */


    retrieve:function (appsum) {
        this.set('option', 1);
        this.set('applicationId', appsum.get('applicationId'));
        this.set('birthDate1', this.get('birthDate2'));
        this.get('controllers.jsonRetrieve').run();
    }


});