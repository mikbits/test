/*****************************************************************************
 * CONTROLLER Step 5
 *****************************************************************************/


App.Step5Controller = App.StepController.extend(App.DebitCards, App.MultiCurrencies, App.BundleLogic, {

	actions: {
		addD2d: function () {
	        App.setCurrentStepDirty();
	        this.set('d2d', true);
	        App.step1Data.set('withoutDebitCard',false);
	        if(App.step1Data.get('isJoint')){
	            App.step1Data.set('partnerWithoutDebitCard',false);
	        }
	    },


	    removeD2d: function () {
	        App.setCurrentStepDirty();
	        this.set('d2d', false);
	        App.step1Data.set('withoutDebitCard',true);
	        if(App.step1Data.get('isJoint')){
	            App.step1Data.set('partnerWithoutDebitCard',true);
	        }
	    },


	    addFlexiSaver: function () {
	        this.set('flexiSaver', true);
	        App.setCurrentStepDirty();
	    },


	    removeFlexiSaver: function () {
	        this.set('flexiSaver', false);
	        App.setCurrentStepDirty();
	    },


	    addFlexiSaverAndD2d: function () {
	        App.setCurrentStepDirty();
	        this.set('d2d', true);
	        this.set('flexiSaver', true);
	        App.step1Data.set('withoutDebitCard',false);
	        if(App.step1Data.get('isJoint')){
	            App.step1Data.set('partnerWithoutDebitCard',false);
	        }
	    },


	    removeFlexiSaverAndD2d: function () {
	        App.setCurrentStepDirty();
	        this.set('d2d', false);
	        this.set('flexiSaver', false);
	        App.step1Data.set('withoutDebitCard',true);
	        if(App.step1Data.get('isJoint')){
	            App.step1Data.set('partnerWithoutDebitCard',true);
	        }
	    },


	    addMultiCurrency: function () {
	        this.set('multiCurrency', true);
	        App.setCurrentStepDirty();
	    },


	    removeMultiCurrency: function () {
	        this.set('multiCurrency', false);
	        App.setCurrentStepDirty();
	    }
	},
	
    /**
     * Methods
     */


    checkboxClick:function (emField) {

        if (emField === "withoutDebitCard" || emField === 'partnerWithoutDebitCard') {
            this.toggleCard(emField);
        }

    },


    selectChange:function (e) {
        var target = $(e.target);
        var emField = target.attr('em-field');
        var value = target.val();

        if (emField === 'multiCurrencyMain') {
            this.updateCurrencies(value);
        }

    }


    


});