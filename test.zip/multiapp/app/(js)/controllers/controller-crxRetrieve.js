
App.CrxRetrieveController = Ember.ObjectController.extend(App.Nav, {

    needs: ['jsonCrxRetrieve'],

    crxRetrieve: function () {
        this.get('controllers.jsonCrxRetrieve').run();
    }

});

