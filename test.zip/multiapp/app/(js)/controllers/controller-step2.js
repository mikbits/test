/*****************************************************************************
 * CONTROLLER Step 2
 *****************************************************************************/


App.Step2Controller = App.StepController.extend(App.BundleLogic, {


	actions: {
		openModal: function (id) {
	        App.ux.openModal(id);
	    }
	},
    /**
     * Properties
     */


    geoCoder1: null,
    geoCoder2: null,
    geoCoder3: null,
    geoCoder4: null,


    /**
     * Computed properties
     */


    firstApplicant: function () {
        return App.step1Data.get('firstName') + ' ' + App.step1Data.get('lastName');
    }.property('App.step1Data.firstName', 'App.step1Data.lastName'),


    secondApplicant: function () {
        return App.step1Data.get('partnerFirstName') + ' ' + App.step1Data.get('partnerLastName');
    }.property('App.step1Data.partnerFirstName', 'App.step1Data.partnerLastName'),


    displayGeoCoder1: function () {
        return App.vedaResponse.get('ajaxStatus') && !this.get('addr1Validated');
    }.property('App.vedaResponse.ajaxStatus', 'addr1Validated'),


    displayGeoCoder2: function () {
        return App.vedaResponse.get('ajaxStatus') && !this.get('addr2Validated');
    }.property('App.vedaResponse.ajaxStatus', 'addr2Validated'),


    displayGeoCoder3: function () {
        return App.vedaResponse.get('ajaxStatus') && !this.get('addr3Validated');
    }.property('App.vedaResponse.ajaxStatus', 'addr3Validated'),


    displayGeoCoder4: function () {
        return App.vedaResponse.get('ajaxStatus') && !this.get('addr4Validated');
    }.property('App.vedaResponse.ajaxStatus', 'addr4Validated'),


    /**
     * Methods
     */


    computeYears: function (fieldY, fieldM) {
        var months = this.get(fieldM);
        var years = this.get(fieldY) || 0;
        years = App.validationController.hasOnlyDigits(years) ? parseInt(years) : 0;

        if (months && App.validationController.hasOnlyDigits(months)) {
            months = parseInt(months);
            years += Math.floor(months / 12);
            months = months % 12;
            this.set(fieldY, years);
            this.set(fieldM, months);
            $('input[em-field="' + fieldY + '"]').val(years).trigger('focusout');
            $('input[em-field="' + fieldM + '"]').val(months);
        }

        return years;
    },


    computeYearsMonths: function () {
        return this.computeYears('years', 'months');
    },


    computePartnerYearsMonths: function () {
        return this.computeYears('partnerYears', 'partnerMonths');
    },


    inputKeyUp: function (e) {
        var field = $(e.target).attr('em-field');

        if (this.get('partnerEmailConfirm') && field === 'partnerEmail') {
            $('input[em-field="partnerEmailConfirm"]').keyup();
        }

    },


    inputFocusOut: function (e) {
        var target = $(e.target);
        var emField = target.attr('em-field');
        var lastAddress = $('div#lastAddress');
        var partnerLastAddress = $('div#partnerLastAddress');

        if (emField === 'months') {

            if (target.val()) {
                var newYears = this.computeYearsMonths();

                if (newYears < App.get('previousAddressTrigger')) {
                    lastAddress.removeClass('destroyed');
                } else {
                    lastAddress.addClass('destroyed');
                    App.setCurrentStepDirty();
                }
            }

        } else if (emField === 'partnerMonths') {

            if (target.val()) {
                var partnerNewYears = this.computePartnerYearsMonths();

                if (partnerNewYears < App.get('previousAddressTrigger')) {
                    partnerLastAddress.removeClass('destroyed');

                } else {
                    partnerLastAddress.addClass('destroyed');
                    App.setCurrentStepDirty();
                }
            }

        } else if (emField === 'years') {
            var years = target.val();

            if (years) {
                var months = $('input[em-field="months"]');

                if (App.validationController.hasOnlyDigits(years)) {
                    if (!months.val()) {
                        App.step2Data.set('months', 0);
                        months.val(0).trigger('focusout');
                    }

                    if (parseInt(years) < App.get('previousAddressTrigger')) {
                        lastAddress.removeClass('destroyed');
                    } else {
                        lastAddress.addClass('destroyed');
                        App.setCurrentStepDirty();
                    }
                }
            }

        } else if (emField === 'partnerYears') {
            var partnerYears = target.val();

            if (partnerYears) {
                var partnerMonths = $('input[em-field="partnerMonths"]');

                if (App.validationController.hasOnlyDigits(partnerYears)) {

                    if (!partnerMonths.val()) {
                        App.step2Data.set('partnerMonths', 0);
                        partnerMonths.val(0).trigger('focusout');
                    }

                    if (parseInt(partnerYears) < App.get('previousAddressTrigger')) {
                        partnerLastAddress.removeClass('destroyed');

                    } else {
                        partnerLastAddress.addClass('destroyed');
                        App.setCurrentStepDirty();
                    }

                }
            }
        }
    },


    radioTrue: function (emField) {
        if (emField === 'partnerHasSameAddress') $('div#partnerAddress').addClass('destroyed');
    },


    radioFalse: function (emField) {
        if (emField === 'partnerHasSameAddress') $('div#partnerAddress').removeClass('destroyed');
    },


    addressValidated: function (response, field) {
        var addrValidated = null;

        if (response.Result) {
            var result = response.Result;
            var array = result.Street ? result.Street.split(' ') : null;
            var street = array ? array[0] : '';
            var streetType = array ? array[array.length - 1].toUpperCase() : '';

            if (array) {

                for (var i = 1; i < array.length - 1; i++) {
                    street = street + ' ' + array[i];
                }

            }

            if(streetType){
                if(!App.streetTypes.findProperty('code', streetType)){
                	streetType = "";
                }
            }
            
            if (field === 'address') {
                this.set('unitNb', result.Unit);
                this.set('streetNb', result.StreetNumber);
                this.set('street', street);
                this.set('streetType', streetType);
                this.set('suburb', result.Suburb);
                this.set('state', result.State);
                this.set('postcode', result.Postcode);

            } else {
                this.set(field + 'UnitNb', result.Unit);
                this.set(field + 'StreetNb', result.StreetNumber);
                this.set(field + 'Street', street);
                this.set(field + 'StreetType', streetType);
                this.set(field + 'Suburb', result.Suburb);
                this.set(field + 'State', result.State);
                this.set(field + 'Postcode', result.Postcode);
            }

            switch (field) {

                case 'address':
                    addrValidated = 'addr1Validated';
                    break;

                case 'previousAddress':
                    addrValidated = 'addr2Validated';
                    break;

                case 'partnerAddress':
                    addrValidated = 'addr3Validated';
                    break;

                case 'partnerPreviousAddress':
                    addrValidated = 'addr4Validated';
                    break;

            }
        }

        // Display complex address
        this.set(addrValidated, true);
    },


    switchComplexAddr: function (addr) {
        var _this = this;
        var $input;
        var field;

        switch (addr) {

            case 1:
                field = 'address';
                break;

            case 2:
                field = 'previousAddress';
                break;

            case 3:
                field = 'partnerAddress';
                break;

            case 4:
                field = 'partnerPreviousAddress';
                break;

        }

        $input = $('input[em-field="' + field + '"]');
        $input.addClass('ui-autocomplete-loading');
        //$('aside.error_' + $input.attr('id')).remove();

        if ($input.val()) {

            $.ajax({
                url: 'https://geocoderweb.veda.com.au/ValidateAddress',
                data: { address: $input.val() },
                dataType: "jsonp",

                success: function (response) {
                    $input.removeClass('ui-autocomplete-loading');
                    _this.addressValidated(response, field);
                },

                complete: function () {
                    _this.set('addr' + addr + 'Validated', true);
                }

            });

        } else {
            this.set('addr' + addr + 'Validated', true);
        }

    }


    


});