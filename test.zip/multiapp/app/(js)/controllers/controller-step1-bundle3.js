/*****************************************************************************
 * CONTROLLER Step 1 bundle 1
 *****************************************************************************/


App.Step1Bundle3Controller = App.Step1Controller.extend({


    /**
     * Computed properties
     */


    isSaverNotLinkedToHsbc:function () {
        var isLinked = this.get('isSaverLinkedToHsbc');
        return isLinked === null ? false : !isLinked;
    }.property('isSaverLinkedToHsbc')


});