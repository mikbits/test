/*****************************************************************************
 * CONTROLLER Step 6
 *****************************************************************************/


App.Step6Controller = App.StepController.extend(App.Nav, App.BundleLogic, {

	actions: {
	    refreshCaptcha: function() {
	    	this.get('controllers.jsonCaptchaRenew').run();
	    }
	},

    /**
     * Dependencies
     */


    needs: ['jsonSubmit','jsonCaptchaRenew','jsonCaptchaValidate'],

    captchaLoaded: false,
    captchaUrlSuffix: '1',

    /**
     * Computed properties
     */


    nationality2: function () {
        if (App.step3Data.get('hasMultipleNat')  && App.step3Data.get('nationality2')) {
            return App.step3Data.get('nationality2Long');
        } else {
            return '-';
        }
    }.property('App.step3Data.nationality2', 'App.step3Data.hasMultipleNat'),


    nationality3: function () {
        if (App.step3Data.get('hasMultipleNat') && App.step3Data.get('nationality3')) {
            return App.step3Data.get('nationality3Long');
        } else {
            return '-';
        }
    }.property('App.step3Data.nationality3', 'App.step3Data.hasMultipleNat'),    


    tfnExempted: function () {
        var e = App.step3Data.get('tfnExempted');
        return  e != 'No TFN exception' ? e : '-';
    }.property('App.step3Data.tfnExempted'),


    partnerTfnExempted: function () {
        var e = App.step3Data.get('partnerTfnExempted');
        return e != 'No TFN exception' ? e : '-';
    }.property('App.step3Data.partnerTfnExempted'),


    homePhone: function () {
        return this.checkNotEmpty(App.step1Data.get('homePhone'));
    }.property('App.step1Data.homePhone'),


    mobilePhone: function () {
        return this.checkNotEmpty(App.step1Data.get('mobilePhone'));
    }.property('App.step1Data.mobilePhone'),


    partnerHomePhone: function () {
        return this.checkNotEmpty(App.step2Data.get('partnerHomePhone'));
    }.property('App.step2Data.partnerHomePhone'),


    partnerMobilePhone: function () {
        return this.checkNotEmpty(App.step2Data.get('partnerMobilePhone'));
    }.property('App.step2Data.partnerMobilePhone'),


    partnerNationality2: function () {
        if (App.step3Data.get('partnerHasMultipleNat') && App.step3Data.get('partnerNationality2')) {
            return App.step3Data.get('partnerNationality2Long');
        } else {
            return '-';
        }
    }.property('App.step3Data.partnerNationality2', 'App.step3Data.partnerHasMultipleNat'),

    partnerNationality3: function () {
        if (App.step3Data.get('partnerHasMultipleNat') && App.step3Data.get('partnerNationality3')) {
            return App.step3Data.get('partnerNationality3Long');
        } else {
            return '-';
        }
    }.property('App.step3Data.partnerNationality3', 'App.step3Data.partnerHasMultipleNat'),

    years: function () {
        return this.getPrettyCounter(parseInt(App.step2Data.get('years')), 'year');
    }.property('App.step2Data.years'),


    months: function () {
        return this.getPrettyCounter(parseInt(App.step2Data.get('months')), 'month');
    }.property('App.step2Data.months'),


    partnerYears: function () {
        return this.getPrettyCounter(parseInt(App.step2Data.get('partnerYears')), 'year');
    }.property('App.step2Data.partnerYears'),


    partnerMonths: function () {
        return this.getPrettyCounter(parseInt(App.step2Data.get('partnerMonths')), 'month');
    }.property('App.step2Data.partnerMonths'),


    address: function () {
        var unitNb = App.step2Data.get('unitNb') ? (App.step2Data.get('unitNb') + '/') : '';
        var streetNb = App.step2Data.get('streetNb') ? (App.step2Data.get('streetNb') + ' ') : '';
        var street = App.step2Data.get('street');
        var streetType = App.streetTypes.getStreetType(App.step2Data.get('streetType'));
        var suburb = App.step2Data.get('suburb');
        var state = App.step2Data.get('state');
        var postcode = App.step2Data.get('postcode');

        return unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode;
    }.property('App.step2Data.unitNb', 'App.step2Data.streetNb', 'App.step2Data.street', 'App.step2Data.streetType', 'App.step2Data.suburb', 'App.step2Data.state', 'App.step2Data.postCode'),


    previousAddress: function () {
        var unitNb = App.step2Data.get('previousAddressUnitNb') ? (App.step2Data.get('previousAddressUnitNb') + '/') : '';
        var streetNb = App.step2Data.get('previousAddressStreetNb') ? (App.step2Data.get('previousAddressStreetNb') + ' ') : '';
        var street = App.step2Data.get('previousAddressStreet');
        var streetType = App.streetTypes.getStreetType(App.step2Data.get('previousAddressStreetType'));
        var suburb = App.step2Data.get('previousAddressSuburb');
        var state = App.step2Data.get('previousAddressState');
        var postcode = App.step2Data.get('previousAddressPostcode');

        return unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode;
    }.property('App.step2Data.previousAddressUnitNb', 'App.step2Data.previousAddressStreetNb', 'App.step2Data.previousAddressStreet', 'App.step2Data.previousAddressStreetType', 'App.step2Data.previousAddressSuburb', 'App.step2Data.previousAddressState', 'App.step2Data.previousAddressPostCode'),


    partnerAddress: function () {
        var unitNb = App.step2Data.get('partnerAddressUnitNb') ? (App.step2Data.get('partnerAddressUnitNb') + '/') : '';
        var streetNb = App.step2Data.get('partnerAddressStreetNb') ? (App.step2Data.get('partnerAddressStreetNb') + ' ') : '';
        var street = App.step2Data.get('partnerAddressStreet');
        var streetType = App.streetTypes.getStreetType(App.step2Data.get('partnerAddressStreetType'));
        var suburb = App.step2Data.get('partnerAddressSuburb');
        var state = App.step2Data.get('partnerAddressState');
        var postcode = App.step2Data.get('partnerAddressPostcode');
        var firstApplicant = App.step1Data.get('firstName') + ' ' + App.step1Data.get('lastName');

        return App.step2Data.get('partnerHasSameAddress') === true ? ('Same address as ' + firstApplicant) : (unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode);
    }.property('App.step2Data.partnerHasSameAddress', 'App.step2Data.partnerUnitNb', 'App.step2Data.partnerStreetNb', 'App.step2Data.partnerStreet', 'App.step2Data.partnerStreetType', 'App.step2Data.partnerSuburb', 'App.step2Data.partnerState', 'App.step2Data.partnerPostCode'),


    partnerPreviousAddress: function () {
        var unitNb = App.step2Data.get('partnerPreviousAddressUnitNb') ? (App.step2Data.get('partnerPreviousAddressUnitNb') + '/') : '';
        var streetNb = App.step2Data.get('partnerPreviousAddressStreetNb') ? (App.step2Data.get('partnerPreviousAddressStreetNb') + ' ') : '';
        var street = App.step2Data.get('partnerPreviousAddressStreet');
        var streetType = App.streetTypes.getStreetType(App.step2Data.get('partnerPreviousAddressStreetType'));
        var suburb = App.step2Data.get('partnerPreviousAddressSuburb');
        var state = App.step2Data.get('partnerPreviousAddressState');
        var postcode = App.step2Data.get('partnerPreviousAddressPostcode');

        return (unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode);
    }.property('App.step2Data.partnerHasSameAddress', 'App.step2Data.partnerUnitNb', 'App.step2Data.partnerStreetNb', 'App.step2Data.partnerStreet', 'App.step2Data.partnerStreetType', 'App.step2Data.partnerSuburb', 'App.step2Data.partnerState', 'App.step2Data.partnerPostCode'),


    licence: function () {
        return App.step4Data.get('photoId') === 'DL';
    }.property('App.step4Data.photoId'),


    licenceIsNsw: function () {
        return App.step4Data.get('licenceState') === 'NSW';
    }.property('App.step4Data.licenceState'),


    licenceIsWa: function () {
        return App.step4Data.get('licenceState') === 'WA';
    }.property('App.step4Data.licenceState'),

    ozPassport: function () {
        return App.step4Data.get('photoId') === 'AP';
    }.property('App.step4Data.photoId'),


    intPassport: function () {
        return App.step4Data.get('photoId') === 'IP';
    }.property('App.step4Data.photoId'),


    medicare: function () {
        return App.step4Data.get('photoId') === 'MC';
    }.property('App.step4Data.photoId'),


    partnerLicence: function () {
        return App.step4Data.get('partnerPhotoId') === 'DL';
    }.property('App.step4Data.partnerPhotoId'),


    partnerLicenceIsNsw: function () {
        return App.step4Data.get('partnerLicenceState') === 'NSW';
    }.property('App.step4Data.partnerLicenceState'),


    partnerLicenceIsWa: function () {
        return App.step4Data.get('partnerLicenceState') === 'WA';
    }.property('App.step4Data.partnerLicenceState'),


    partnerOzPassport: function () {
        return App.step4Data.get('partnerPhotoId') === 'AP';
    }.property('App.step4Data.partnerPhotoId'),


    partnerIntPassport: function () {
        return App.step4Data.get('partnerPhotoId') === 'IP';
    }.property('App.step4Data.partnerPhotoId'),


    partnerMedicare: function () {
        return App.step4Data.get('partnerPhotoId') === 'MC';
    }.property('App.step4Data.partnerPhotoId'),


    issuedCountry: function () {
        return App.countries.getCountryName(App.step4Data.get('intPassportCountry'));
    }.property('App.step4Data.intPassportCountry'),


    partnerIssuedCountry: function () {
        return App.countries.getCountryName(App.step4Data.get('partnerIntPassportCountry'));
    }.property('App.step4Data.partnerIntPassportCountry'),


    otherCurrencies: function () {
        var $container = $('<div>');
        var $ul = $('<ul>').addClass('inStep');
        var currencies = App.step5Data.get('otherCurrencies');

        currencies.forEach(function (item) {
            var $li = $('<li>');

            $li.html(App.currencies.getCurrencyName(item));
            $ul.append($li);
        });

        $container.append($ul);
        return currencies.length === 0 ? 'none' : $container.html();
    }.property('App.step5Data.otherCurrencies'),


    /**
     * Methods
     */


    checkNotEmpty: function (str) {
        return str ? str : '-';
    },


    getPrettyCounter: function (nb, counter) {

        switch (nb) {
            case 0:
                return '';
                break;

            case 1:
                return nb + ' ' + counter;
                break;

            default:
                return nb + ' ' + counter + 's';

        }

    },


    submitApp: function () {
    	
    	for (var stepp=1; stepp<=5; stepp++) {
        	if (!App.get('hasSavedStep'+stepp)) {
        		this.send('goStep', stepp);
        		return;
        	}
    	}

        var errors = App.inputErrors;
        errors.clear();
        $('div.focusOut').trigger('focusout');

        if (errors.total()) {
            App.ux.scrollFirstError();

        } else {
            var submitting= this.get('controllers.jsonSubmit').get('submitting');
            if(!submitting){
                this.get('controllers.jsonSubmit').set('submitting',true);
                this.get('controllers.jsonSubmit').run();
            }else{
                alert('The form has been submitted, please wait for it to complete ...');
            }
        }

    },

    captchaUrl: function() {
	    var url='img/spinner.gif';
        if(this.get('captchaLoaded')){
            url=App.config.get('captchaUrlRoot')+'?key='+this.get('captchaUrlSuffix');
        }
        return url;
    }.property('captchaUrlSuffix','captchaLoaded'),



    refreshCaptchaUrl: function(){
        this.set('captchaUrlSuffix',Math.random());
    },

    setCaptchaLoadedTrue:function(){
        this.set('captchaLoaded',true);
    },

    goStep: function (step) {
        var bundle = App.get('bundle');

        switch (step) {

            case 1:
                this.goRoute('step1Bundle' + bundle);
                break;

            case 2:
                this.goRoute('step2');
                break;

            case 3:
                this.goRoute('step3');
                break;

            case 4:
                this.goRoute('step4');
                break;

            case 5:
                this.goRoute('step5');
                break;

        }

        App.ux.scrollTop();

    }


});