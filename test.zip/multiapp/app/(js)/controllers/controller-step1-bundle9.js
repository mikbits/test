/*****************************************************************************
 * CONTROLLER Step 1 bundle 9
 *****************************************************************************/


App.Step1Bundle9Controller = App.Step1Controller.extend({
	isOstBundle:true,

	init:function(){
		App.step1Data.set('isJoint',false);
	},
    
	inputFocusOut:function (e) {
		var field = $(e.target).attr('em-field');
		if (field === 'tradingUsername') {
			var ostcheckbutton = $('div#ostcheckbuttonid');
	    	var ostname = App.step1Data.get("tradingUsername");
	    	var valiadator = App.validationController;
	    	if (!valiadator.hasSpace(ostname) && valiadator.isMin(ostname, 8) && valiadator.hasOnlyDigitsAndLetters(ostname))
				ostcheckbutton.removeClass('destroyed');
	    	else
	    		ostcheckbutton.addClass('destroyed');
		}

		if (field === 'tradingUsernamePartner') {
			var ostpartnercheckbutton = $('div#ostpartnercheckbuttonid');
	    	var ostname = App.step1Data.get("tradingUsernamePartner");
	    	var valiadator = App.validationController;
	    	if (!valiadator.hasSpace(ostname) && valiadator.isMin(ostname, 8) && valiadator.hasOnlyDigitsAndLetters(ostname))
				ostpartnercheckbutton.removeClass('destroyed');
	    	else
	    		ostpartnercheckbutton.addClass('destroyed');
		}
    }
});