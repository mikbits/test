/*****************************************************************************
 * CONTROLLER Application
 *****************************************************************************/


App.ApplicationController = Ember.Controller.extend(App.Nav, {



    /**
     * Dependencies
     */


    needs: ['jsonSave','jsonGetServerDate', 'jsonIsOstExists', 'jsonIsOstPartnerExists'],


    /**
     * Methods
     */


    goStep: function (currentStep, nextStep, submit) {

        if ((currentStep != 1 && submit != true && currentStep === App.getLastSavedStep() + 1) || App.get('isStep' + currentStep + 'Dirty') === false) {
            // If user is ediding the last step and didn't push "Save and Continue", or current step is not dirty, just re-route without validation/ajax
            this.send('goToStep', nextStep);

        } else {
            // Reset errors
            var errors = App.inputErrors;
            errors.clear();

            // Trigger all validation
            $('input, select, div.focusOut').trigger('focusout');

            if (errors.total()) {
                App.ux.scrollFirstError();

            } else {
                App.set('hasSavedStep' + currentStep, true);
                this.get('controllers.jsonSave').run();
                if(currentStep===1 && (App.get('bundle')===4 || App.get('bundle')===9)) {
                    App.setBusy();
                    App.set('isBusy', false);
                 }else{
                    App.nothingDirtyUntil(currentStep);
                    this.send('goToStep', nextStep);
               }
            }

        }

    },

    refreshServerDate: function () {
        this.get('controllers.jsonGetServerDate').run();
    },
    
    
    isOstExists: function () {
        this.get('controllers.jsonIsOstExists').run();
    },

    isOstPartnerExists: function () {
        this.get('controllers.jsonIsOstPartnerExists').run();
    }
    

});