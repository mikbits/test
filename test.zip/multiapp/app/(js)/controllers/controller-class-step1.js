/*****************************************************************************
 * CONTROLLER Mother class step 1
 *****************************************************************************/


App.Step1Controller = App.StepController.extend(App.DebitCards, App.MultiCurrencies, App.BundleLogic, {

	actions: {
		loginAndApply: function () {
	        window.open('https://www.hsbc.com.au/1/2/HUB_IDV2/FUSED_EPP?__EntryPage=hubpib.applicationcentre.landing');
	    },
	    
	    printPolicy: function () {
	        var w = window.open('', 'HSBC Privacy Policy', 'height=700,width=1000');

	        w.document.write('<html><head><title>' + $('div#privacyPolicy h3').html() + '</title>');
	        w.document.write('</head><body >');
	        w.document.write($('div#privacyPolicy').html());
	        w.document.write('</body></html>');

	        w.print();
	    }
	},

    /**
     * Computed properties
     */


    isIndividual: function () {
        var isJoint = this.get('isJoint');
        return isJoint === null ? false : !isJoint;
    }.property('isJoint'),


    isBodyDisplayed: function () {
        var isJoint = this.get('isJoint');
        var isCustomer = this.get('isCustomer');

        if (!this.hasCustomerCheck(App.get('bundle'))) {
            return isJoint !== null;
        } else {
            return isJoint ? true : isCustomer === false;
        }
    }.property('isJoint', 'isCustomer'),


    /**
     * Observers
     */


    titleHasChanged: function () {
        var title = this.get('title');

        if (title === 'Sir' || title === 'Mr') {
            App.step3Data.set('gender', 'M');

        } else if (title === 'Ldy' || title === 'Mrs' || title === 'Ms' || title === 'Mis') {
            App.step3Data.set('gender', 'F');

        } else {
            App.step3Data.set('gender', null);
        }

    }.observes('title'),


    partnerTitleHasChanged: function () {
        var partnerTitle = this.get('partnerTitle');

        if (partnerTitle === 'Sir' || partnerTitle === 'Mr') {
            App.step3Data.set('partnerGender', 'M');

        } else if (partnerTitle === 'Ldy' || partnerTitle === 'Mrs' || partnerTitle === 'Ms' || partnerTitle === 'Mis') {
            App.step3Data.set('partnerGender', 'F');

        } else {
            App.step3Data.set('partnerGender', null);
        }

    }.observes('partnerTitle'),


    /**
     * Methods
     */


    inputKeyUp: function (e) {
        var target = $(e.target);
        var field = target.attr('em-field');

        if (this.get('emailConfirm') && field === 'email') {
            $('input[em-field="emailConfirm"]').keyup();
        }

    },

    openPrivacyPolicy: function () {
        App.ux.openModal('privacyPolicy');
    },


    openWhyDebitCard: function () {
        App.ux.openModal('whyDebitCard');
    },


    radioTrue: function (emField) {

        if (emField === 'isJoint') {
            $('div#debitCard2').removeClass('destroyed');

            // If steps were saved as individual application and user suddenly switch to joint, has to validate all steps as joint
            if (!App.step1Data.get('partnerFirstName')) {
                App.set('lastSavedStepAsIndividualApp', App.getLastSavedStep());
                App.nothingSaved();
            }

            App.setSavedUntil(App.get('lastSavedStepAsJointApp'));
            //App.ux.scrollHeader();

        } else if (emField === 'isCustomer') {
            App.set('lastSavedStepAsJointApp', App.getLastSavedStep());
            App.nothingSaved();
        }

    },


    radioFalse: function (emField) {

        if (emField === 'isJoint') {
            var lastStep = App.get('lastSavedStepAsIndividualApp');

            $('div#debitCard2').addClass('destroyed');

            // Recover steps saved as individual
            if (lastStep) App.setSavedUntil(lastStep);
            if (!this.hasCustomerCheck(App.get('bundle'))) App.ux.scrollHeader();

        } else if (emField === 'isCustomer') {
            App.setSavedUntil(App.get('lastSavedStepAsJointApp'));
            //App.ux.scrollHeader();
        }

    },


    selectChange: function (e) {
        var target = $(e.target);
        var emField = target.attr('em-field');
        var value = target.val();

        if (emField === 'multiCurrencyMain') {
            this.updateCurrencies(value);
        }

    },


    saveDate: function (field, value) {
        this.set('birthDate', value);
    }


    


    

});