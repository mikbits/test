/*****************************************************************************
 * CONTROLLER UX
 *****************************************************************************/


App.Ux = Ember.Object.extend({


    /**
     * Methods
     */


    scrollHeader: function () {
        $('html, body').animate({scrollTop: 450}, App.get('scrollSpeed'));
    },


    scrollTop: function () {
        $('html, body').animate({scrollTop: 0}, 1);
    },


    scrollFirstError: function () {
        var offsetTop = $('aside').first().offset().top;
        $('html, body').animate({scrollTop: offsetTop - 80}, App.get('scrollSpeed'));
    },


    openModal: function (id) {
        $('div#' + id).modal({focus: false, closeHTML: '<a class="modalCloseImg"></a>'});
    }


});


App.ux = App.Ux.create();