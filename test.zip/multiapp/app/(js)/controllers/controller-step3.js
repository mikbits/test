/*****************************************************************************
 * CONTROLLER Step 3
 *****************************************************************************/

App.Step3Controller = App.StepController.extend({


    nationalityCountries2: [],
    nationalityCountries3: [],
    partnerNationalityCountries2: [],
    partnerNationalityCountries3: [],
    /**
     * Methods
     */

     init:function(){
        this._super();
        if (this.get("nationalityCountries2").length) this.get("nationalityCountries2").removeAt(0, this.get("nationalityCountries2").length);
        this.get("nationalityCountries2").addObjects(App.countries.get("content"));
        if (this.get("nationalityCountries3").length) this.get("nationalityCountries3").removeAt(0, this.get("nationalityCountries3").length);
        this.get("nationalityCountries3").addObjects(App.countries.get("content"));
        if (this.get("partnerNationalityCountries2").length) this.get("partnerNationalityCountries2").removeAt(0, this.get("partnerNationalityCountries2").length);
        this.get("partnerNationalityCountries2").addObjects(App.countries.get("content"));
        if (this.get("partnerNationalityCountries3").length) this.get("partnerNationalityCountries3").removeAt(0, this.get("partnerNationalityCountries3").length);
        this.get("partnerNationalityCountries3").addObjects(App.countries.get("content"));        
     },


    setNotResident: function (field, isResident) {
        var countryTax = field === 'isResident' ? 'countryTax' : 'partnerCountryTax';
        var countryTaxVal = App.step3Data.get(countryTax);

        if (countryTaxVal && countryTaxVal != 'AUS') {
            App.step3Data.set(field, null);
            $('div[em-field="' + field + '"] div.radioButton[em-bool="false"]').removeClass('checked');
            $('[em-field="' + field + '"]').trigger('focusout');
            App.ux.openModal('modalResTaxError');
        }

    },


    radioTrue: function (field) {

        if (field === 'hasMultipleNat') {
            $('div#otherNat').removeClass('destroyed');

        } else if (field === 'partnerHasMultipleNat') {
            $('div#partnerOtherNat').removeClass('destroyed');
        }

    },


    radioFalse: function (field) {
        var data = App.getCurrentStepData();
        var value = data.get(field);

        if (field === 'hasMultipleNat') {
            $('div#otherNat').addClass('destroyed');

        } else if (field === 'partnerHasMultipleNat') {
            $('div#partnerOtherNat').addClass('destroyed');

        } else if (field === 'isResident' || field === 'partnerIsResident') {
            this.setNotResident(field, value);
        }

    },
 

    nationalityChanged: function(){
        var nationality=this.get('nationality');
        var nationality2=this.get('nationality2');
        var nationality3=this.get('nationality3');
        if (this.get("nationalityCountries2").length) this.get("nationalityCountries2").removeAt(0, this.get("nationalityCountries2").length);
        this.get("nationalityCountries2").addObjects(App.countries.get("content"));
        this.get('nationalityCountries2').removeObject(this.get('nationalityCountries2').findBy('code',nationality));

        if (this.get("nationalityCountries3").length) this.get("nationalityCountries3").removeAt(0, this.get("nationalityCountries3").length);
        this.get("nationalityCountries3").addObjects(App.countries.get("content"));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality2));

        if(nationality2 === nationality) nationality2=null;
        if(nationality3 === nationality) nationality3=null;
        this.set('nationality2', nationality2);
        this.set('nationality3', nationality3);

    }.observes('nationality'),


    nationality2Changed: function(){
        var nationality=this.get('nationality');
        var nationality2=this.get('nationality2');
        var nationality3=this.get('nationality3');
        if (this.get("nationalityCountries3").length) this.get("nationalityCountries3").removeAt(0, this.get("nationalityCountries3").length);
        this.get("nationalityCountries3").addObjects(App.countries.get("content"));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality2));

        if(nationality3 === nationality || nationality3 === nationality2) nationality3=null;;
        this.set('nationality3', nationality3);
    }.observes('nationality2'), 


    nationality3Changed: function(){
        var nationality3=this.get('nationality3');
        if(nationality3 === 'seperator') nationality3=null;;
        this.set('nationality3', nationality3);
    }.observes('nationality3'), 

    partnerNationalityChanged: function(){
        var partnerNationality=this.get('partnerNationality');
        var partnerNationality2=this.get('partnerNationality2');
        var partnerNationality3=this.get('partnerNationality3');
        if (this.get("partnerNationalityCountries2").length) this.get("partnerNationalityCountries2").removeAt(0, this.get("partnerNationalityCountries2").length);
        this.get("partnerNationalityCountries2").addObjects(App.countries.get("content"));
        this.get('partnerNationalityCountries2').removeObject(this.get('partnerNationalityCountries2').findBy('code',partnerNationality));

        if (this.get("partnerNationalityCountries3").length) this.get("partnerNationalityCountries3").removeAt(0, this.get("partnerNationalityCountries3").length);
        this.get("partnerNationalityCountries3").addObjects(App.countries.get("content"));
        this.get('partnerNationalityCountries3').removeObject(this.get('partnerNationalityCountries3').findBy('code',partnerNationality));
        this.get('partnerNationalityCountries3').removeObject(this.get('partnerNationalityCountries3').findBy('code',partnerNationality2));

        if(partnerNationality2 === partnerNationality) partnerNationality2=null;
        if(partnerNationality3 === partnerNationality) partnerNationality3=null;
        this.set('partnerNationality2', partnerNationality2);
        this.set('partnerNationality3', partnerNationality3);

    }.observes('partnerNationality'),


    partnerNationality2Changed: function(){
        var partnerNationality=this.get('partnerNationality');
        var partnerNationality2=this.get('partnerNationality2');
        var partnerNationality3=this.get('partnerNationality3');
        if (this.get("partnerNationalityCountries3").length) this.get("partnerNationalityCountries3").removeAt(0, this.get("partnerNationalityCountries3").length);
        this.get("partnerNationalityCountries3").addObjects(App.countries.get("content"));
        this.get('partnerNationalityCountries3').removeObject(this.get('partnerNationalityCountries3').findBy('code',partnerNationality));
        this.get('partnerNationalityCountries3').removeObject(this.get('partnerNationalityCountries3').findBy('code',partnerNationality2));

        if(partnerNationality3 === partnerNationality || partnerNationality3 === partnerNationality2) partnerNationality3=null;;
        this.set('partnerNationality3', partnerNationality3);
    }.observes('partnerNationality2'),  
    

    partnerNationality3Changed: function(){
        var partnerNationality3=this.get('partnerNationality3');
        if(partnerNationality3 === 'seperator') partnerNationality3=null;;
        this.set('partnerNationality3', partnerNationality3);
    }.observes('partnerNationality3'),     

    selectChange: function (e) {
        var target = $(e.target);
        var field = target.attr('em-field');
        var value = target.val();

        if (field === 'countryTax' || field === 'partnerCountryTax') {
            var isResident = field === 'countryTax' ? App.step3Data.get('isResident') : App.step3Data.get('partnerIsResident');

            if (isResident === false && value != 'AUS') {
                App.step3Data.set(field, '');
                $('select[em-field="' + field + '"]').val('');
                App.ux.openModal('modalResTaxError');
            }

        } else if ((field === 'countryBirth') && (this.get('countryBirth') === 'AUS') && !this.get('nationality')) {
            this.set('nationality', 'AUS');
            $('select[em-field="nationality"]').val('AUS').focusout();

        } else if ((field === 'partnerCountryBirth') && (this.get('partnerCountryBirth') === 'AUS') && !this.get('partnerNationality')) {
            this.set('partnerNationality', 'AUS');
            $('select[em-field="partnerNationality"]').val('AUS').focusout();
        } 

    }


});