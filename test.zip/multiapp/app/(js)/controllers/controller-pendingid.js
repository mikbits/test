/*****************************************************************************
 * CONTROLLER
 *****************************************************************************/


App.PendingIdController = Ember.ObjectController.extend({


    /**
     * Computed properties
     */


    title: function () {

        if (this.get('pendingId') && this.get('partnerPendingId')) {
            return 'To complete your account opening, we need to complete an identification check for both you and ' + this.get('partnerData').get('firstName');

        } else if (this.get('pendingId') && !this.get('partnerPendingId')) {
            return 'To complete your account opening, we need to complete an identification check.';

        } else {
            return 'To complete your account opening, we need to complete an identification check only for ' + this.get('partnerData').get('firstName');
        }

    }.property('pendingId', 'partnerPendingId'),


    subtitle: function () {

        if (this.get('pendingId') && this.get('partnerPendingId')) {
            return 'Each of you needs to provide:';

        } else if (this.get('pendingId') && !this.get('partnerPendingId')) {
            return 'Please provide:';

        } else {
            return this.get('partnerData').get('firstName') + ' needs to provide:';
        }

    }.property('pendingId', 'partnerPendingId')


});