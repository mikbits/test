/*****************************************************************************
 * CONTROLLER Self id page
 *****************************************************************************/


App.SelfIdController = App.StepController.extend({

	actions: {
		submitIds: function () {
	        var errors = this.get('errorsContainer');

	        errors.clear();
	        this.validateIds();

	        $('input, select, div.focusOut').trigger('focusout');

	        if (errors.total()) {
	            App.ux.scrollFirstError();

	        } else {
	            App.set('refresh', false);
	            this.get('controllers.jsonSubmitIds').run();
	        }

	    }
	},

    /**
     * Dependencies
     */


    needs: ['jsonSubmitIds'],


    /**
     * Computed properties
     */


    displayLicence: function () {
        return !!this.get('licenceState');
    }.property('licenceState'),


    licenceIsNsw: function () {
        return this.get('licenceState') === 'NSW';
    }.property('licenceState'),


    licenceIsWa: function () {
        return this.get('licenceState') === 'WA';
    }.property('licenceState'),


    licenceImg: function () {
        return 'img/dl-' + this.get('licenceState') + '.png';
    }.property('licenceState'),


    isOzPassport: function () {
        return this.get('passportType') === 'AUS';
    }.property('passportType'),


    isIntPassport: function () {
        return this.get('passportType') === 'INT';
    }.property('passportType'),


    isMedicareExpiryDateMMYYYY: function() {
        var result=false;
        if(this.get('medicareColor')==='G'){
            result=true;
        }
        return result;
    }.property('medicareColor'),

    isMedicareColorSelected: function() {
        if(this.get('medicareColor')){
            return true;
        }else{
            return false;
        }
    }.property('medicareColor') ,
    /**
     * Methods
     */


    checkboxClick: function (field) {

        if (field === 'ozLicence' || field === 'passport') {
            this.validateIds();
        }

    },


    validateIds: function () {
        var selfIdData = App.selfIdData;
        this.removeError('selfIdLabel');

        if (!this.get('ozLicenceSelected') && !this.get('passportSelected')) {
            this.addError(false, 'selfIdLabel', 'Required', 'side');
        }
    },

    /**
     * Observers
     */

    medicareColorChangeded: function() {
        if(this.get('medicareColor')==='G'){
            if(this.get('medicareExpiryDate') && !this.get('medicareExpiryDate').match(/^[0-9][0-9]\/[0-9][0-9][0-9][0-9]/g)){
                var matches=this.get("medicareExpiryDate").match(/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/g);
                if(matches) {
                    this.set('medicareExpiryDate',matches[0]);
                }
            }
        }else{
            if(this.get('medicareExpiryDate') && !this.get('medicareExpiryDate').match(/^[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/g)){
                this.set('medicareExpiryDate','');
            }
        }
    }.observes('medicareColor')


});