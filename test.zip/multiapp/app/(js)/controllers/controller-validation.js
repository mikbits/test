/*****************************************************************************
 * CONTROLLER Validation
 *****************************************************************************/


App.ValidationController = Ember.Object.extend({

    /**
     * properties
     */
    serverDate: null,


    /**
     * Validation methods
     */


    isMin: function (value, min) {
        var string = value || '';
        return string.length >= min;
    },

    
    isMax:function (value, max) {
        var string = value || '';
        return string.length <= max;
    },
    
    
    isInformed: function (value) {
        var string = value || '';
        return string.length >= 1;
    },


    isName: function (value) {
        return /^[a-zA-Z\s'\-]*$/.test(value);
    },


    isEmail: function (value) {
    	return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,6})+$/.test(value);
    },


    isHomePhone: function (value) {
        return /^((02)|(03)|(07)|(08))\-\d\d\d\d\-\d\d\d\d$/.test(value);
    },


    isMobilePhone: function (value) {
        return /^((04)|(05))\d\d\-\d\d\d\-\d\d\d$/.test(value);
    },


    hasSpace: function (value) {
        return /\s/g.test(value);
    },


    hasDigit: function (value) {
        return /\d/g.test(value);
    },


    hasOnlyDigits: function (value) {
        return /^[\d\s]*$/.test(value);
    },


    hasOnlyDigitsStrict: function (value) {
        return /^[\d]*$/.test(value);
    },


    hasOnlyLetters: function (value) {
        return /^[a-zA-Z\s]*$/.test(value);
    },


    hasOnlyDigitsAndLetters: function (value) {
        return /^[a-zA-Z0-9\s]*$/.test(value);
    },


    isDate: function (value) {
        var userInputDate=moment(value, 'DD/MM/YYYY');
        var result = false;
        if(userInputDate && userInputDate.isValid()){
            result = true;
        }
        return result;
    },
    
    isDateMMYYYY: function (value) {
        var userInputDate=moment(value, 'MM/YYYY');
        var result = false;
        if(userInputDate && userInputDate.isValid()){
            result = true;
        }
        return result;
    },

    ageLessThan100: function (value) {
        var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
        var userInputDate=moment(value, 'DD/MM/YYYY');
        var result=false;
        if(userInputDate){
            var age = now.diff(userInputDate, 'years');
            if(age <100){
                result= true;
            }
        }
        return result;
    },

    is18: function (value) {
        var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
        var userInputDate=moment(value, 'DD/MM/YYYY');
        var result=false;
        if(userInputDate){
            var age = now.diff(userInputDate, 'years');
            if(age >=18){
                result= true;
            }
        }
        return result;
    },

    lengthEither: function(value, lengthVals){
        var lengthAry = lengthVals.split('_');
        for(var i = 0; i < lengthAry.length; i++){
            if(value.length === parseInt(lengthAry[i])){
                return true;
            }
        }
        return false;
    },



    notExpired: function (value) {
    	var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
    	var userInputDate=moment(value, 'DD/MM/YYYY');
    	var result=false;
    	if(userInputDate){
    		if(userInputDate.diff(now, 'days')>=0){
    			result= true;
    		}
    	}
    	return result;
    },

    notExpiredMMYYYY: function (value) {
    	var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
    	var userInputDate=moment(value, 'MM/YYYY');
    	var result=false;
    	if(userInputDate){
    		if(userInputDate.diff(now, 'months') > 0){
    			result= true;
    		}
    	}
    	return result;
    },

    isStreetNb: function (value) {
        return /^[a-zA-Z0-9\s\-]*$/.test(value);
    },

    pobox: function (value) {
        return !(value.replace(/\W/g, '').toLowerCase().indexOf('pobox') > -1);
    }


});


App.validationController = App.ValidationController.create();