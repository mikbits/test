/*****************************************************************************
 * CONTROLLER Step 4
 *****************************************************************************/


App.Step4Controller = App.StepController.extend({


    /**
     * Computed properties
     */


    licenceIsNsw: function () {
        return this.get('licenceState') === 'NSW';
    }.property('licenceState'),


    licenceIsWa: function () {
        return this.get('licenceState') === 'WA';
    }.property('licenceState'),


    displayLicence: function () {
        return !!this.get('licenceState');
    }.property('licenceState'),


    licenceImg: function () {
        return 'img/dl-' + this.get('licenceState') + '.png';
    }.property('licenceState'),


    partnerLicenceIsNsw: function () {
        return this.get('partnerLicenceState') === 'NSW';
    }.property('partnerLicenceState'),


    partnerLicenceIsWa: function () {
        return this.get('partnerLicenceState') === 'WA';
    }.property('partnerLicenceState'),


    displayPartnerLicence: function () {
        return !!this.get('partnerLicenceState');
    }.property('partnerLicenceState'),


    partnerLicenceImg: function () {
        return 'img/dl-' + this.get('partnerLicenceState') + '.png';
    }.property('partnerLicenceState'),


    /**
     * Events
     */


    selectChange: function (e) {
        var target = $(e.target);
        var field = target.attr('em-field');
        var value = target.val();

        if (field === 'photoId' || field === 'partnerPhotoId') {
            var $idLicence = $('div#idLicence');
            var $idMedicare = $('div#idMedicare');
            var $idOzPassport = $('div#idOzPassport');
            var $idIntPassport = $('div#idIntPassport');

            if (field === 'partnerPhotoId') {
                $idLicence = $('div#partnerIdLicence');
                $idMedicare = $('div#partnerIdMedicare');
                $idOzPassport = $('div#partnerIdOzPassport');
                $idIntPassport = $('div#partnerIdIntPassport');
            }

            $idLicence.addClass('destroyed');
            $idMedicare.addClass('destroyed');
            $idOzPassport.addClass('destroyed');
            $idIntPassport.addClass('destroyed');

            switch (value) {

                case 'DL':
                    $idLicence.removeClass('destroyed');
                    break;

                case 'MC':
                    $idMedicare.removeClass('destroyed');
                    break;

                case 'AP':
                    $idOzPassport.removeClass('destroyed');
                    break;

                case 'IP':
                    $idIntPassport.removeClass('destroyed');
                    break;

            }
        }

    }


});