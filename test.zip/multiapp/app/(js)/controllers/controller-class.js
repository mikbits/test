/*****************************************************************************
 * CONTROLLER Mother class
 *****************************************************************************/


App.StepController = Ember.ObjectController.extend({


    /**
     * Properties
     */


    errorsContainer: App.inputErrors,


    /**
     * Methods needed by event proxies (views input, checkbox, radio, select)
     */


    inputKeyUp: function (e) {
    },
    inputFocusOut: function (e) {
    },
    checkboxClick: function (emField) {
    },
    radioTrue: function (emField) {
    },
    radioFalse: function (emField) {
    },
    selectChange: function (emField) {
    },
    saveDate: function (field, value) {
    },


    /**
     * Methods
     */


    validate: function (e) {
        var target = $(e.target);
        var emberId = e.target.id;
        var isBypassed = target.parents('div.blockToggle').hasClass('destroyed');
        var value = target.val();
        var validate = App.validationController;
        var emValid = target.attr('em-valid');
        var ops = emValid ? emValid.split(' ') : [];
        var asideClass = target.attr('em-aside');
        var length = ops.length;

        // Assume no error (add error later if found)
        this.removeError(emberId);

        for (var i = 0; i < length; i++) {
            var op = ops[i];

            if (op === 'req' || op === 'sreq') {
                var reqMsg = (op === 'req') ? 'Required' : 'Req.';

                if (!validate.isInformed(value) || (target.prop('tagName') === 'SELECT' && value === 'seperator')) {
                    this.addError(isBypassed, emberId, reqMsg, asideClass);
                    break;
                }

            }

            if (op === 'geo') {
                this.addError(isBypassed, emberId, 'Required, please find your address', asideClass);
                break;
            }

            if (op === 'check') {
                var value = target.val();
                if (value != true) {
                    this.addError(isBypassed, emberId, 'Required', asideClass);
                    break;
                }

            }

            if (op === 'radio') {
                var idQuestion = target.children('div.formQuestion').attr('id');
                var radioField = target.attr('em-field');

                this.removeError(idQuestion);

                if (App.getCurrentStepData().get(radioField) === null) {
                    this.addError(isBypassed, idQuestion, 'Required', asideClass);
                    break;
                }

            }

            if (op === 'oneChoiceReq') {
                var throwError = true;
                var idLabel = target.children('label:first-child').attr('id');

                this.removeError(idLabel);

                target.find('div.checkboxButton').each(function () {

                    if ($(this).hasClass('checked')) {
                        throwError = false;
                    }

                });

                if (throwError) {
                    this.addError(isBypassed, idLabel, 'Please select at least one option', asideClass);
                    break;
                }

            }

            if (op.substring(0, 10) === 'maxChoices') {
                var maxChoices = op.split('_')[1];
                var idLabelMax = target.children('label:first-child').attr('id');

                this.removeError(idLabelMax);

                if (target.find('div.checkboxButton.checked').length > maxChoices) {
                    this.addError(isBypassed, idLabelMax, 'Maximum 3 options', asideClass);
                    break;
                }

            }

            if (op.substring(0, 12) === 'reqPhoneWith') {
                var splitStr = op.split('_');
                var emberId2 = $('input[em-field="' + splitStr[1] + '"]').attr('id');
                var value2 = $('input#' + emberId2).val();

                if (!validate.isInformed(value)) {

                    if (!validate.isInformed(value2)) {
                        var targetDisplay = $('input[em-field="' + splitStr[2] + '"]').attr('id');
                        this.addError(isBypassed, emberId, 'Please enter at least 1 valid phone number', asideClass, emberId2, targetDisplay);
                        break;
                    }

                } else {

                    if (!validate.isInformed(value2)) {
                        $('#' + emberId2).removeClass('error');
                    }

                }
            }

            if (op.substring(0, 4) === 'diff') {
                var fieldComp = op.split('_')[1];
                var $fieldComp = $('select[em-field="' + fieldComp + '"]');
                var fieldCompId = $fieldComp.attr('id');
                var fieldCompVal = $fieldComp.val();

                if (fieldCompVal && (fieldCompVal != 'seperator') && (fieldCompVal === value)) {
                    this.addError(isBypassed, emberId, '2nd and 3rd nationalities can\'t be the same', asideClass);
                    break;

                } else {
                	var errHtml = $('aside.error_' + fieldCompId).find('span').html();
                	if (errHtml != 'Required' && errHtml != 'Req.') {
                		this.removeError(fieldCompId);
                	}
                    
                }

            }

            if (op === 'name' && !validate.isName(value)) {
                this.addError(isBypassed, emberId, 'Only letters, \' and -', asideClass);
                break;
            }

            if (op === 'namespace' && !validate.isName(value)) {
                this.addError(isBypassed, emberId, 'Only letters, spaces, \' and -', asideClass);
                break;
            }

            if (op === 'email' && !validate.isEmail(value)) {
                this.addError(isBypassed, emberId, 'Please enter a valid email address', asideClass);
                break;
            }

            if (op === 'confirm' && ($('input[em-field="email"]').val().toLowerCase() != value.toLowerCase())) {
                this.addError(isBypassed, emberId, 'The email address does not match, please re-enter', asideClass);
                break;
            }

            if (op === 'confirmPartnerEmail' && ($('input[em-field="partnerEmail"]').val().toLowerCase() != value.toLowerCase())) {
                this.addError(isBypassed, emberId, 'The email address does not match, please re-enter', asideClass);
                break;
            }

            if ((op === 'homePhone') && value && (value != '__-____-____') && !validate.isHomePhone(value)) {
                this.addError(isBypassed, emberId, 'Please enter a valid home phone number', asideClass);
                break;
            }

            if ((op === 'mobilePhone') && value && (value != '____-___-___') && !validate.isMobilePhone(value)) {
                this.addError(isBypassed, emberId, 'Please enter a valid mobile phone number', asideClass);
                break;
            }

            if ((op === 'allPhone') && value && (value != '__-____-____') && !validate.isAllPhone(value)) {
                this.addError(isBypassed, emberId, 'Please enter a valid phone number', asideClass);
                break;
            }

            if (op === 'onlyDigits' && !validate.hasOnlyDigits(value)) {
                this.addError(isBypassed, emberId, 'Only digits please', asideClass);
                break;
            }

            if (op === 'onlyLetters' && !validate.hasOnlyLetters(value)) {
                this.addError(isBypassed, emberId, 'Only letters please', asideClass);
                break;
            }

            if (op === 'onlyDigitsAndLetters' && !validate.hasOnlyDigitsAndLetters(value)) {
                this.addError(isBypassed, emberId, 'Only digits and letters please', asideClass);
                break;
            }

            if (op === 'sonlyDigitsAndLetters' && !validate.hasOnlyDigitsAndLetters(value)) {
                this.addError(isBypassed, emberId, 'Invalid char.', asideClass);
                break;
            }

            if (op === 'pobox' && !validate.pobox(value)) {
                this.addError(isBypassed, emberId, 'P.O. Box addresses are not allowed. <br /> <span style="margin-left: 20px;">Please use a different address.</span>', asideClass);
                break;
            }

            if (op === 'streetNb' && !validate.isStreetNb(value)) {
                this.addError(isBypassed, emberId, 'Invalid char.', asideClass);
                break;
            }

            if (op === 'date' && !validate.isDate(value)) {
                this.addError(isBypassed, emberId, 'Please enter a valid date', asideClass);
                break;
            }

            if (op === 'is18' && !validate.is18(value)) {
                this.addError(isBypassed, emberId, 'You must be at least 18 years old', asideClass);
                break;
            }

            if (op === 'ageLessThan100' && !validate.ageLessThan100(value)) {
                this.addError(isBypassed, emberId, 'Please enter a valid date of birth', asideClass);
                break;
            }

            if (op === 'notExpired' && !validate.notExpired(value)) {
                this.addError(isBypassed, emberId, 'The date you entered has expired', asideClass);
                break;
            }

            if (op === 'agreed' && !this.get(emberId)) {
                this.addError(isBypassed, emberId, 'Required', asideClass);
                break;
            }

            if (op === 'noSpace' && validate.hasSpace(value)) {
                this.addError(isBypassed, emberId, 'No space please', asideClass);
                break;
            }

            if (op === 'noDigit' && validate.hasDigit(value)) {
                this.addError(isBypassed, emberId, 'No digit please', asideClass);
                break;
            }

            if (op.substring(0, 3) === 'min' && !validate.isMin(value, op.split('_')[1])) {

                if (value) {
                    this.addError(isBypassed, emberId, 'Too short', asideClass);
                    break;
                }

            }
            
            if (op.substring(0, 3) === 'max'&& !validate.isMax(value, op.split('_')[1])){
            	
           	 if (value) {
                    this.addError(isBypassed, emberId, 'Too long', asideClass);
                    break;
                }
           }             

        }
    },


    displayCommonError: function (emberId1, emberId2, msg, targetDisplay) {
        $('#' + targetDisplay).after('<aside class="mix error_' + emberId1 + ' error_' + emberId2 + '"><div class="bigMustache">}</div><div class="errorIcon mix"></div><span id="mixed">' + msg + '</span></aside>');
        $('#' + emberId1 + ', #' + emberId2).addClass('error');
    },


    displayError: function (emberId, asideClass, msg) {
        var target = $('#' + emberId);
        var parent = target.parent();
        var errorHtml = '<aside class="error_' + emberId + ' ' + asideClass + '"><div class="errorIcon"></div><span>' + msg + '</span></aside>';

        if (parent.hasClass('formWrapper')) {
            parent.after(errorHtml);

        } else {
            target.addClass('error').after(errorHtml);
        }

    },


    addError: function (isBypassed, emberId1, msg, asideClass, emberId2, targetDisplay) {
        if (!isBypassed) {
            var aclass = asideClass || 'side';
            this.get('errorsContainer').addError(emberId1, msg);

            if (emberId2) {
                this.displayCommonError(emberId1, emberId2, msg, targetDisplay);

            } else {
                this.displayError(emberId1, aclass, msg);
            }

        }
    },


    removeError: function (emberId) {
        this.get('errorsContainer').removeError(emberId);
        $('#' + emberId).removeClass('error');
        $('aside.error_' + emberId).remove();
    },
    
    
    
    displayInfo: function (emberId, asideClass, msg) {
        var target = $('#' + emberId);
        var parent = target.parent();
        var errorHtml = '<aside class="error_' + emberId + ' ' + asideClass + '"><div class="okIcon"></div><span>' + msg + '</span></aside>';
        target.addClass('error').after(errorHtml);
    },


    addInfo: function (isBypassed, emberId1, msg, asideClass) {
        if (!isBypassed) {
            var aclass = asideClass || 'side';
            this.get('errorsContainer').addError(emberId1, msg);
            this.displayInfo(emberId1, aclass, msg);
        }
    }
    

});