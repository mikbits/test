/*****************************************************************************
 * CONTROLLER
 *****************************************************************************/


App.ApprovedController = Ember.ObjectController.extend(App.BundleLogic, {


    /**
     * Computed properties
     */


    currencies:function () {
        var str = this.get('multiCurrencyMain');

        this.get('otherCurrencies').forEach(function (item) {
            if(item){
                str += ', ';
                str += item;
            }
        });

        return str;
    }.property('multicurrencyMain', 'otherCurrencies')


});