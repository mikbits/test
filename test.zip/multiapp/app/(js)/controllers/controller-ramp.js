/*****************************************************************************
 * CONTROLLER Ramp
 *****************************************************************************/


App.RampController = App.StepController.extend(App.Nav, {

	actions: {
		completeForm: function () {
	        var errors = this.get('errorsContainer');

	        errors.clear();
	        $('input, select').trigger('focusout');

	        if (errors.total()) {
	            App.ux.scrollFirstError();

	        } else {
	            App.set('refresh',false);
	            this.get('controllers.jsonSubmitRamp').run();
	            this.goRoute('step1Bundle' + this.get('bundle'));
	        }

	    }
	},

    /**
     * Dependencies
     */


    needs: ['jsonSubmitRamp'],


    /**
     * Methods
     */


    


});