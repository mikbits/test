/*****************************************************************************
 * VIEW Select
 *****************************************************************************/

App.Select = Ember.View.extend({


    /**
     * Properties
     */


    tagName:'select',
    value: null,


    /**
     * Bindings
     */


    attributeBindings:['em-field', 'em-aside', 'em-valid', 'em-holder'],

    /**
     * Events
     */


    change:function (e) {

        var target = $(e.target);
        var emValid = target.attr('em-valid');
        this.set('value',target.val());

        // Validate
        if (emValid) this.get('parentView').get('controller').validate(e);

        // Update watermark CSS
        if (this.get('value')) {
            target.removeClass('watermark');
        } else if (target.attr('em-holder')) {
            target.addClass('watermark');
        }

        //Steps Special behaviours
        this.get('parentView').get('controller').selectChange(e);

        // Step is dirty
        App.setCurrentStepDirty();
    },


    focusOut:function (e) {
        var target = $(this);
        var emValid = target.attr('em-valid');

        if (emValid) this.get('parentView').get('controller').validate(e);
    },

    valueChanged: function(){
        var emValid = this.get('em-valid');
        var target=$(this.get('tagName')+'[em-field="' + this.get('em-field') + '"]');

        if(this.get('value')!=target.val()){
            target.val(this.get('value'));
            target.trigger('change');
        }
    }.observes('value'),


    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        var _this = this.$();

        // Update selected option from Model
        _this.val(this.get('value'));

        // Apply watermark CSS
        if (!_this.val()) _this.addClass('watermark');

        _this.append("<option class='watermark' value=''>Please select</option>");
    }


});


