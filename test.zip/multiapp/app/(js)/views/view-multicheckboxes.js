/*****************************************************************************
 * VIEW Multi checkboxes
 *****************************************************************************/


App.MultiCheckboxes = Ember.View.extend({


    /**
     * Bindings
     */


    attributeBindings:['em-valid', 'em-aside', 'em-multi', 'em-field'],


    /**
     * Events
     */


    click:function (e) {
        var data = App.getCurrentStepData();
        var field = this.get('em-field');
        var code = $(e.target).attr('em-code');
        var array = [];
        var $cbList = $('div[em-field="' + field + '"]');

        var className = $(e.target).attr("class");
        if (className === 'checkbox' ||
            className === 'checkboxButton' || 
            className === 'checkboxButton checked'){
            $cbList.find('div[em-code="'+code+'"].checkboxButton').toggleClass('checked');
        }

        $cbList.find('div.checkboxButton').each(function() {
            var $this = $(this);

            if($this.hasClass('checked')) {
                array.push($this.attr('em-code'));
            }

        });

        if(this.get('em-valid')) {
            this.$().trigger('focusout');
        }

        data.set(field, array);
        App.setCurrentStepDirty();

    },


    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        var field = this.get('em-field');
        var array = App.getCurrentStepData().get(field);

        array.forEach(function (item) {
            $('div[em-field="' + field + '"]').find('div[em-code="' + item + '"].checkboxButton').addClass('checked');
        });

    }


});