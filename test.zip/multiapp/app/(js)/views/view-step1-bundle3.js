/*****************************************************************************
 * VIEW Step 1 bundle 3
 *****************************************************************************/


App.Step1Bundle3View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle3'


});