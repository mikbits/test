/*****************************************************************************
 * VIEW Input
 *****************************************************************************/


App.Input = Ember.TextField.extend(App.Watermark, App.InputKeyDown, {


    /**
     * Properties
     */


    attributeBindings: [
        'em-holder',
        'em-field',
        'em-valid',
        'em-aside',
        'em-type',
        'em-dateshift',
        'em-mask'
    ],

    timer: null,


    /**
     * Methods
     */

    checkTimer: function (e) {
        var t = this.get('timer');
        var _this = this;

        if (t) {
            clearTimeout(t);
        }

        this.set('timer', setTimeout(function () {
            _this.set('timer', null);
            _this.get('targetObject').validate(e);
        }, App.get('inputTimer')));
    },


    /**
     * Events
     */


    keyUp: function (e) {
        var target = $(e.target);
        var field = target.attr('em-field');
        var valid = target.attr('em-valid');
        var type = target.attr('em-type');

        // Watermark
        if (target.val()) {
            this.removeWatermark(field);

        } else if (target.attr('em-holder')) {
            this.displayWatermark(target.attr('em-field'), target.prop('tagName').toLowerCase(), target.attr('em-holder'));
        }

        // Validate
        if (valid && e.which != 9) {
            this.checkTimer(e);
        }

        // Step is dirty
        App.setCurrentStepDirty();

        // Special steps behaviours
        this.get('targetObject').inputKeyUp(e);
    },


    focusIn: function (e) {
        var field = this.get('em-field');
        var watermark = this.get('em-holder');

        if (watermark) {
            this.removeWatermark(field);
        }

    },


    focusOut: function (e) {
        var target = $(e.target);
        var value = target.val();
        var field = this.get('em-field');
        var type = this.get('em-type');
        var valid = this.get('em-valid');
        var mask = this.get('em-mask') ? this.get('em-mask') : '';

        // Handle mask
        if (mask.replace(/9/g, '_') === value) {
            target.val('');
        }

        // Watermark
        if (target.val()) {
            this.removeWatermark(field);

        } else if (target.attr('em-holder')) {
            this.displayWatermark(target.attr('em-field'), target.prop('tagName').toLowerCase(), target.attr('em-holder'));
        }

        // Validate
        if (valid) this.get('targetObject').validate(e);

        // Special steps behaviours
        this.get('targetObject').inputFocusOut(e);
    },


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {
        var $this = this.$();
        var _this = this;
        var id = $this.attr('id');
        var field = this.get('em-field');
        var type = this.get('em-type');
        var maskF = this.get('em-mask');
        var value = this.get('value');

        // Display watermark
        if (!$this.val() && $this.attr('em-holder')) {
            this.displayWatermark($this.attr('em-field'), $this.prop('tagName').toLowerCase(), $this.attr('em-holder'));
        }

        // Mask
        if (maskF) {
            $this.mask(maskF);
        }

        if (type === 'cal') {
            var sd = this.get('em-dateshift') ? this.get('em-dateshift') : null;

            var now = moment();
            if(App.validationController.get('serverDate')){
                now=moment(App.validationController.get('serverDate'),'DD/MM/YYYY');
            }
            var yearRange=now.clone().subtract('years',100).year() + ':' + now.clone().add('years',15).year();

            $this.datepicker({
                changeYear: true,
                yearRange: yearRange,
                dateFormat: 'dd/mm/yy',
                defaultDate: sd,
                showOn: 'button',
                buttonImage: 'img/calendar.png',
                buttonImageOnly: true,
                buttonText: '',
                nextText: '',
                prevText: '',

                onSelect: function () {
                    var val = $this.val();
                    $this.focusout();
                    _this.get('targetObject').saveDate(field, val);
                }

            });
        }
    },


    willDestroyElement: function () {
        clearTimeout(this.get('timer'));
    }


});