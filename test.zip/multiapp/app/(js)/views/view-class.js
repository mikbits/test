/*****************************************************************************
 * VIEW Step class
 *****************************************************************************/


App.StepView = Ember.View.extend({


    /**
     * Events
     */


    click: function (e) {
        this.touchClick(e);
    },


    touchEnd: function (e) {
        this.touchClick(e);
    },


    focusOut: function (e) {
        var target = $(e.target);

        // Validate div.focusOut
        if (target.hasClass('focusOut')) {
            this.get('controller').validate(e);
        }

    },



    /**
     * Methods
     */


    touchClick: function (e) {
        var target = $(e.target);

        if (target.hasClass('watermark')) {
            var field = target.attr('em-field');
            $('input[em-field=' + field + ']').select();
        }

    },


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {

        // Some CSS adjustments
        if (!App.step1Data.isJoint) {
            $('div.col1 h2, div.col2 h2').css('width', '900px');
        }

//        // When closing window
//        window.onbeforeunload = function () {
//            return 'You are about to loose the information that you have entered on this page.';
//        };

    }


});