/*****************************************************************************
 * VIEW Choose application
 *****************************************************************************/
 
 
App.ChooseAppView = Ember.View.extend({


    /**
     * Properties
     */


    templateName:'chooseApp'


});