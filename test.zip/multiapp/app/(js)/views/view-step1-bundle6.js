/*****************************************************************************
 * VIEW Step 1 bundle 6
 *****************************************************************************/


App.Step1Bundle6View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle6'


});