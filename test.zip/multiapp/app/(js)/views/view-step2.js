/*****************************************************************************
 * VIEW Step 2
 *****************************************************************************/


App.Step2View = App.StepView.extend({


    /**
     * Properties
     */


    templateName: 'step2',


    /**
     * Methods
     */


    touchClick: function (e) {
        var action = $(e.target).attr('em-action');

        if (action === 'openMsg1') {
            App.ux.openModal('modalOutsideAustralia');

        } else if (action === 'openMsg2') {
            App.ux.openModal('modalWereOutsideAustralia');

        } else if (action === 'openMsg3') {
            App.ux.openModal('modalPartnerOutsideAustralia');

        } else if (action === 'openMsg4') {
            App.ux.openModal('modalPartnerWereOutsideAustralia');

        } else if (action === 'openMsg5') {
            App.ux.openModal('modalPermanentAddressDiffers');

        } else if (action === 'openCustomerDetailsForm') {
            App.ux.openModal('modalPermanentAddressDiffers');

        } else if (action === 'switchComplexAddr1') {
            this.get('controller').switchComplexAddr(1);

        } else if (action === 'switchComplexAddr2') {
            this.get('controller').switchComplexAddr(2);

        } else if (action === 'switchComplexAddr3') {
            this.get('controller').switchComplexAddr(3);

        } else if (action === 'switchComplexAddr4') {
            this.get('controller').switchComplexAddr(4);

        } else {
            this._super(e);
        }

    },


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {
        var years = App.step2Data.get('years');
        var partnerYears = App.step2Data.get('partnerYears');

        if (App.validationController.hasOnlyDigitsStrict(years) && parseInt(years) < 3) {
            $('div#lastAddress').removeClass('destroyed');
        }

        if (App.step2Data.get('partnerHasSameAddress') === false) {
            $('div#partnerAddress').removeClass('destroyed');
        }

        if (App.validationController.hasOnlyDigitsStrict(partnerYears) && parseInt(partnerYears) < 3) {
            $('div#partnerLastAddress').removeClass('destroyed');
        }

        this._super();
    }


});