/*****************************************************************************
 * VIEW Step 1 bundle 1
 *****************************************************************************/


App.Step1Bundle1View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle1'


});