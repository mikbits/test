/*****************************************************************************
 * VIEW Retrieve
 *****************************************************************************/


App.RetrieveView = App.StepView.extend({


    /**
     * Properties
     */


    templateName:'retrieve',


    /**
     * Events
     */


    focusIn:function (e) {
        var target = $(e.target);

        if (target.hasClass('option1')) {
            this.get('controller').setOption1();

        } else if (target.hasClass('option2')) {
            this.get('controller').setOption2();
        }

    },


    /**
     * Methods
     */


    touchClick:function (e) {
        var emAction = $(e.target).attr('em-action');
        var controller = this.get('controller');

        if (emAction === 'retrieve') {
            controller.retrieve();
        }

        this._super(e);

    },


    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        $('input').val('');
    }


});