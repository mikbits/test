/*****************************************************************************
 * VIEW Step 5
 *****************************************************************************/


App.Step5View = App.StepView.extend({


    /**
     * Properties
     */


    templateName:'step5',

    /**
     * Methods
     */


    touchClick: function (e) {
        var action = $(e.target).attr('em-action');
        if (action === 'openMulticurrencyInformationMsgForm') {
            App.ux.openModal('modalMulticurrencyInformationOne');

        } else if (action === 'openDayToDayInformationMsgForm') {
            App.ux.openModal('modalDayToDayInformationOne');

        } else if (action === 'openFlexiSaverInformationMsgForm') {
            App.ux.openModal('modalFlexiSaverInformationOne');

        } else if (action === 'openDayToDayFlexiSaverInformationMsgForm') {
            App.ux.openModal('modalDayToDayFlexiSaverInformationOne');

        } else if (action === 'openWhyDebitCardStep5Form') {
            App.ux.openModal('modalWhyDebitCardStep5Information');

        } else {
            this._super(e);
        }

    },

    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        var mainCurrency = App.step1Data.get('multiCurrencyMain');

        if (App.step5Data.get('multiCurrency') && mainCurrency) $('div[em-code="' + mainCurrency + '"].currency').addClass('destroyed');
        if (App.step1Data.get('withoutDebitCard')) $('div#withoutDebitCard').parent().addClass('off');
        if (App.step1Data.get('partnerWithoutDebitCard')) $('div#partnerWithoutDebitCard').parent().addClass('off');

        this._super();
    }


});

function openPersonalFinancialServicesChargesYourGuide() {
	var url = "https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/fees-charges.pdf";
	window.open(url, '_blank', 'status=yes,location=no,menubar=no,resizable=yes,scrollbars=yes,toolbar=no,width=635,height=545,screenX=0,left=0,screenY=0,top=0');
}