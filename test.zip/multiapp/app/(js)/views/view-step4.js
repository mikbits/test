/*****************************************************************************
 * VIEW Step 4
 *****************************************************************************/


App.Step4View = App.StepView.extend({


    /**
     * Properties
     */


    templateName: 'step4',


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {

        switch (App.step4Data.get('photoId')) {

            case 'DL':
                $('div#idLicence').removeClass('destroyed');
                break;

            case 'MC':
                $('div#idMedicare').removeClass('destroyed');
                break;

            case 'AP':
                $('div#idOzPassport').removeClass('destroyed');
                break;

            case 'IP':
                $('div#idIntPassport').removeClass('destroyed');
                break;

        }

        switch (App.step4Data.get('partnerPhotoId')) {

            case 'DL':
                $('div#partnerIdLicence').removeClass('destroyed');
                break;

            case 'MC':
                $('div#partnerIdMedicare').removeClass('destroyed');
                break;

            case 'AP':
                $('div#partnerIdOzPassport').removeClass('destroyed');
                break;

            case 'IP':
                $('div#partnerIdIntPassport').removeClass('destroyed');
                break;

        }

        this._super();
    }


});