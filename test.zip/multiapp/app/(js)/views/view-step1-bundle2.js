/*****************************************************************************
 * VIEW Step 1 bundle 2
 *****************************************************************************/


App.Step1Bundle2View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle2'


});