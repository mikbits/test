/*****************************************************************************
 * VIEW Application
 *****************************************************************************/


App.ApplicationView = Ember.View.extend({


    /**
     * Properties
     */


    templateName: 'application',


    /**
     * Events
     */


    click: function (e) {
        this.touchClick(e);
    },


    touchEnd: function (e) {
        this.touchClick(e);
    },


    /**
     * Methods
     */


    footerAction: function (url) {
        window.open(url, '_blank', 'status=yes,location=no,menubar=no,resizable=yes,scrollbars=yes,toolbar=no,width=635,height=545,screenX=0,left=0,screenY=0,top=0');
        return false;
    },


    touchClick: function (e) {
        var action = $(e.target).attr('em-action');
        var currentStep = App.getCurrentStep();
        var controller = this.get('controller');

        if (action === 'goStep1' && currentStep !== 1) {
            controller.goStep(currentStep, 1);

        } else if (action === 'goStep2' && currentStep !== 2 && App.get('hasSavedStep1')) {
            controller.goStep(currentStep, 2);

        } else if (action === 'goStep3' && currentStep !== 3 && App.get('hasSavedStep2')) {
            controller.goStep(currentStep, 3);

        } else if (action === 'goStep4' && currentStep !== 4 && App.get('hasSavedStep3')) {
            controller.goStep(currentStep, 4);

        } else if (action === 'goStep5' && currentStep !== 5 && App.get('hasSavedStep4')) {
            controller.goStep(currentStep, 5);

        } else if (action === 'goStep6' && App.get('hasSavedStep5')) {
            controller.goStep(currentStep, 6);

        } else if (action === 'saveBack') {
            controller.goStep(currentStep, currentStep - 1);

        } else if (action === 'saveContinue') {
            controller.goStep(currentStep, currentStep + 1, true);

        } else if (action === 'saveReview') {
            controller.goStep(currentStep, 6);

        } else if (action === 'isOstExists') {
            controller.isOstExists();

        } else if (action === 'isOstPartnerExists') {
            controller.isOstPartnerExists();

        } else if (action === 'print') {
            print();

        } else if (action === 'openPrivacy') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/privacy-and-security');

        } else if (action === 'openPolicy') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/hyperlink-policy');

        } else if (action === 'openTerms') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/terms-of-use');

        } else if (action === 'openAdvice') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/general-advice-warning');

        } else if (action === 'openRetrieveInfo') {
            App.ux.openModal('retrieveInfo');

        } else if (action === 'openFeesAndChargesGuide') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/fees-charges.pdf');

        } else if (action === 'openFinancialServicesGuide') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/pfs-fsg.pdf');

        } else if (action === 'openProductDisclosureStatement') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/savings-pds.pdf');

        } else if (action === 'openPrivacyAcknowledgementAndConsent') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/ss-privacy-consent.pdf');

        } else if (action === 'openOstFsg') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/fsg');

        } else if (action === 'openOstTermsConditions') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/terms');

        } else if (action === 'openPartnerSponsorshipAgreement') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/psa');

        } else if (action === 'openOstPrivacyPolicy') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/info/privacypolicy.html');

        } else if (action === 'openCNYLimitations') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/renminbi-supp-pds.pdf');


        } else {
            this._super(e);
        }

    },

    didInsertElement: function () {
        var controller = this.get('controller');
        controller.refreshServerDate();
    }

});