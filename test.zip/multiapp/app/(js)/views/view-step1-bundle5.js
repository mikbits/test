/*****************************************************************************
 * VIEW Step 1 bundle 5
 *****************************************************************************/


App.Step1Bundle5View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle5'


});