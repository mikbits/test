/*****************************************************************************
 * VIEW Step 1 bundle 7
 *****************************************************************************/


App.Step1Bundle7View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle7'


});