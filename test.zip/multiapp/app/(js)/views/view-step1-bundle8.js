/*****************************************************************************
 * VIEW Step 1 bundle 8
 *****************************************************************************/


App.Step1Bundle8View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle8'


});