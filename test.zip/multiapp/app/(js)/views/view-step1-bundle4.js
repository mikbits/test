/*****************************************************************************
 * VIEW Step 1 bundle 4
 *****************************************************************************/


App.Step1Bundle4View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle4'


});