/*****************************************************************************
 * VIEW Step 1 bundle 9
 *****************************************************************************/


App.Step1Bundle9View = App.Step1View.extend({


    /**
     * Properties
     */


    templateName:'step1Bundle9'


});