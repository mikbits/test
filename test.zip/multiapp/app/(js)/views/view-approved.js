/*****************************************************************************
 * VIEW Approved page
 *****************************************************************************/


App.ApprovedView = Ember.View.extend({


    /**
     * Properties
     */


    templateName: 'approved'


});