/*****************************************************************************
 * VIEW Step 3
 *****************************************************************************/


App.Step3View = App.StepView.extend({


    /**
     * Properties
     */


    templateName:'step3',

    init: function(){
    	this._super();

        if(this.get('controller.nationality')){
            this.get('controller.nationalityCountries2').removeObject(App.countries.findBy('code'),this.get('controller.nationality'));
            this.get('controller.nationalityCountries3').removeObject(App.countries.findBy('code'),this.get('controller.nationality'));

        }
        if(this.get('controller.nationality2')){
            this.get('controller.nationalityCountries3').removeObject(App.countries.findBy('code'),this.get('controller.nationality2'));
        }
    },


    /**
     * Life cycle hooks
     */


    didInsertElement:function () {

        if (App.step3Data.get('hasMultipleNat') === true) {
            $('div#otherNat').removeClass('destroyed');
        }

        if (App.step3Data.get('partnerHasMultipleNat') === true) {
            $('div#partnerOtherNat').removeClass('destroyed');
        }

        this._super();
    }


});