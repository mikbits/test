/*****************************************************************************
 * ARRAY CONTROLLER Activities
 *****************************************************************************/


App.AppStatus = Ember.ArrayController.extend(App.Checkboxes, {


    /**
     * Properties
     */


    content:[
        {code:'I', name:'incomplete'},
        {code:'P', name:'pending ID'},
        {code:'C', name:'contact required'},
        {code:'D', name:'service delivery'},
        {code:'F', name:'completed'}
    ]


});


App.appStatus = App.AppStatus.create();