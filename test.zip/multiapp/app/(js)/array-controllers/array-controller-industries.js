/*****************************************************************************
 * ARRAY CONTROLLER Industries
 *****************************************************************************/


App.Industries = Ember.ArrayController.extend(App.Options, {



    /**
     * Properties
     */


    content:[
         	{code:'01010', name:'Agriculture'},
        	{code:'07540', name:'Air Transport'},
        	{code:'09614', name:'Banking'},
        	{code:'03218', name:'Beverages And Malt'},
        	{code:'03216', name:'Bread, Cakes & Buscuits'},
        	{code:'06472', name:'Builders Hardware Dealer'},
        	{code:'05411', name:'Building Construction'},
        	{code:'01018', name:'Cereal, Sheep, Cattle, Pigs'},
        	{code:'06484', name:'Clothing, Fabrics, Furn'},
        	{code:'12924', name:'Clubs'},
        	{code:'08590', name:'Communication'},
        	{code:'05423', name:'Concreting, Bricklaying'},
        	{code:'02140', name:'Construction Materials'},
        	{code:'06481', name:'Department & General Stores'},
        	{code:'11820', name:'Education, Museum, Library'},
        	{code:'12913', name:'Entertainment'},
        	{code:'12910', name:'Entertainment / Recreation'},
        	{code:'06475', name:'Farm Properties & Prod'},
        	{code:'02111', name:'Ferrous Metal Ores'},
        	{code:'09610', name:'Finance And Investment'},
        	{code:'01043', name:'Fishing'},
        	{code:'06488', name:'Food Stores'},
        	{code:'03210', name:'Food, Beverages & Tobacco'},
        	{code:'06476', name:'Food, Drink & Tobacco'},
        	{code:'01030', name:'Forestry And Logging'},
        	{code:'01013', name:'Fruit'},
        	{code:'03213', name:'Fruit & Vegetable Prod'},
        	{code:'05410', name:'General Construction'},
        	{code:'06471', name:'General Wholesalers'},
        	{code:'11810', name:'Health'},
        	{code:'11814', name:'Hospitals/Nursing Homes'},
        	{code:'06478', name:'Household Goods'},
        	{code:'09623', name:'Insurance'},
        	{code:'09620', name:'Insurance & Services'},
        	{code:'09616', name:'Investment'},
        	{code:'10712', name:'Justice'},
        	{code:'03345', name:'Leather & Leather Prod'},
        	{code:'09637', name:'Legal/Accounting Services'},
        	{code:'11825', name:'Library,Museums & Art Galleries'},
        	{code:'06473', name:'Machinery / Equipment Wholesaler'},
        	{code:'03211', name:'Meat Products'},
        	{code:'02110', name:'Metalic Minerals'},
        	{code:'06487', name:'Milk And Bread Vendors'},
        	{code:'02161', name:'Mineral Exploration'},
        	{code:'06474', name:'Mineral, Metal, Chemical'},
        	{code:'02162', name:'Mining & Expl. Services'},
        	{code:'03340', name:'Misc Manufacturing'},
        	{code:'06486', name:'Motor Vehicle Dealers'},
        	{code:'09615', name:'Non-Bank Finance'},
        	{code:'05412', name:'Non-Building Construction'},
        	{code:'13990', name:'Non-Classifiable Unit'},
        	{code:'02112', name:'Non-Ferrous Metal Ores'},
        	{code:'02130', name:'Oil And Gas'},
        	{code:'01019', name:'Other Agriculture'},
        	{code:'09638', name:'Other Business Services'},
        	{code:'11849', name:'Other Community Services'},
        	{code:'03217', name:'Other Food Products'},
        	{code:'11815', name:'Other Health'},
        	{code:'03348', name:'Other Manufacturing'},
        	{code:'02150', name:'Other Non-Metalic Minerals'},
        	{code:'12936', name:'Other Personal Services'},
        	{code:'06489', name:'Other Retailers'},
        	{code:'07574', name:'Other Services To Transport'},
        	{code:'05424', name:'Other Special Trades'},
        	{code:'06479', name:'Other Specialist Wholesaler'},
        	{code:'07550', name:'Other Transport'},
        	{code:'26000', name:'Personal Account'},
        	{code:'12930', name:'Personal Services'},
        	{code:'09639', name:'Plant Hire And Leasing'},
        	{code:'03347', name:'Plastic & Related Products'},
        	{code:'11824', name:'Post School & Other Education'},
        	{code:'12940', name:'Private Households Staff'},
        	{code:'09630', name:'Property/Business Serv'},
        	{code:'10710', name:'Public Administration'},
        	{code:'09631', name:'Real Estate Agents'},
        	{code:'09632', name:'Real Estate Opr/Developer'},
        	{code:'12923', name:'Restaurants & Hotels'},
        	{code:'12290', name:'Restaurants, Hotels, Clubs'},
        	{code:'06480', name:'Retail Trade'},
        	{code:'07511', name:'Road Freight Transport'},
        	{code:'07510', name:'Road Transport'},
        	{code:'03346', name:'Rubber Products'},
        	{code:'11823', name:'School Education'},
        	{code:'01020', name:'Services To Agriculture'},
        	{code:'07573', name:'Services To Air Transport'},
        	{code:'09617', name:'Services To Fin/Invest'},
        	{code:'09624', name:'Services To Insurance'},
        	{code:'02160', name:'Services To Mining Nec'},
        	{code:'07570', name:'Services To Transport'},
        	{code:'05420', name:'Special Trade Construction'},
        	{code:'12914', name:'Sport And Recreation'},
        	{code:'06477', name:'Textile & Clothing'},
        	{code:'11816', name:'Veterinary Services'},
        	{code:'07530', name:'Water Transport'},
        	{code:'04370', name:'Water, Sewerage, Drainage'},
        	{code:'11830', name:'Welfare, Religious Ins'},
        	{code:'06470', name:'Wholesale Trade'}
    ]


});


App.industries = App.Industries.create();