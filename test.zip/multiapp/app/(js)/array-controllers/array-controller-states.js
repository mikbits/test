/*****************************************************************************
 * ARRAY CONTROLLER States
 *****************************************************************************/


App.States = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:'ACT', name:'Australian Capital Territory'},
        {code:'NSW', name:'New South Wales'},
        {code:'NT', name:'Northern Territory'},
        {code:'QLD', name:'Queensland'},
        {code:'SA', name:'South Australia'},
        {code:'TAS', name:'Tasmania'},
        {code:'VIC', name:'Victoria'},
        {code:'WA', name:'Western Australia'}
    ]


});


App.states = App.States.create();