/*****************************************************************************
 * ARRAY CONTROLLER Incomes
 *****************************************************************************/


App.Incomes = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:'SLRY', name:'Salary'},
        {code:'CTLK', name:'Centrelink/DVA payments'},
        {code:'INVM', name:'Investment income'},
        {code:'ALLW', name:'Student allowances'},
        {code:'SUPR', name:'Superannuation/Pension payments'}
    ]

});


App.incomes = App.Incomes.create();
