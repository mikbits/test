/*****************************************************************************
 * ARRAY CONTROLLER Titles
 *****************************************************************************/


App.Titles = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:'Mr', name:'Mr'},
        {code:'Mis', name:'Miss'},
        {code:'Mrs', name:'Mrs'},
        {code:'Ms', name:'Ms'},
        {code:'Ldy', name:'Ldy'},
        {code:'Dr', name:'Dr'},
        {code:'Pas', name:'Pas'},
        {code:'Prf', name:'Prf'},
        {code:'Rev', name:'Rev'},
        {code:'Sir', name:'Sir'}
    ]


});


App.titles = App.Titles.create();