/*****************************************************************************
 * ARRAY CONTROLLER Activities
 *****************************************************************************/
 
 
App.Activities = Ember.ArrayController.extend(App.Checkboxes, {


    /**
     * Properties
     */


    content:[
        {code:'ODW', name:'Online deposits or withdrawals'},
        {code:'CDW', name:'Cash deposits or withdrawals'},
        {code:'DAP', name:'Daily purchases'},
        {code:'OFT', name:'Overseas transfers'}
    ]


});


App.activities = App.Activities.create();