/*****************************************************************************
 * ARRAY CONTROLLER Jobs
 *****************************************************************************/


App.Jobs = Ember.ArrayController.extend(App.Options, {



    /**
     * Properties
     */


    content:[
          	{code:'23',name:'Account Clerk'},
        	{code:'17',name:'Accountant'},
        	{code:'68',name:'Agent (Covers Estate Agents, Others)'},
        	{code:'25',name:'Aircrew(To Include Steward/Stewardess)'},
        	{code:'26',name:'Ambassador/Diplomat'},
        	{code:'18',name:'Architect'},
        	{code:'13',name:'Armed Forces'},
        	{code:'27',name:'Artisan/Craftsman'},
        	{code:'28',name:'Artist'},
        	{code:'29',name:'Auctioneer'},
        	{code:'30',name:'Author'},
        	{code:'69',name:'Baker/Cook'},
        	{code:'31',name:'Banker'},
        	{code:'32',name:'Beauty Consultant/Hair Stylist'},
        	{code:'70',name:'Broker/Remister'},
        	{code:'71',name:'Builder/Contractor/Carpenter'},
        	{code:'72',name:'Business Owner'},
        	{code:'24',name:'Butcher'},
        	{code:'19',name:'Chemist/Pharmacist'},
        	{code:'34',name:'Child Care Worker'},
        	{code:'33',name:'Civil Servant (Executive)'},
        	{code:'20',name:'Civil Servant (Senior Executive)'},
        	{code:'03',name:'Clerical/Cashier/Receptionist/Tel Operator'},
        	{code:'81',name:'Company Director'},
        	{code:'73',name:'Daily Wage Earner'},
        	{code:'35',name:'Data Processing-Analyst/Programmer'},
        	{code:'87',name:'Dentist'},
        	{code:'36',name:'Designer'},
        	{code:'88',name:'Dignatries'},
        	{code:'08',name:'Doctor (Medical/Veterinary Surgeon)'},
        	{code:'74',name:'Driver'},
        	{code:'37',name:'Electrican'},
        	{code:'90',name:'Engineer'},
        	{code:'75',name:'Entertainers'},
        	{code:'21',name:'Executive (Senior) In Major Groups'},
        	{code:'02',name:'Executive/Manager'},
        	{code:'06',name:'Farmer'},
        	{code:'39',name:'Film Producer/Scriptwriter'},
        	{code:'40',name:'Fireman'},
        	{code:'77',name:'Guard/Watchman'},
        	{code:'78',name:'Hawker'},
        	{code:'80',name:'Home Duties'},
        	{code:'38',name:'Hospitality (Bar/Pub/Restaurant)'},
        	{code:'41',name:'Lab Technician'},
        	{code:'91',name:'Lawyer/Barrister/Solicitor/Judge'},
        	{code:'92',name:'Lecturer'},
        	{code:'42',name:'Librarian'},
        	{code:'93',name:'Management Consultant'},
        	{code:'05',name:'Manual Worker (Maid/Factory Worker/Oth)'},
        	{code:'43',name:'Mechanic'},
        	{code:'82',name:'Military Personnel (Below The Rank Of Captain)'},
        	{code:'44',name:'Military Personnel (Captain And Above)'},
        	{code:'94',name:'Minister/Member Of Parliament'},
        	{code:'50',name:'Minor - Under 16 Years Old'},
        	{code:'83',name:'Model'},
        	{code:'58',name:'Nanny'},
        	{code:'09',name:'Not Working - Housewife'},
        	{code:'62',name:'Not Working - New Migrant'},
        	{code:'10',name:'Not Working - Retired'},
        	{code:'07',name:'Not Working - Student'},
        	{code:'63',name:'Not Working - Travel Visa'},
        	{code:'45',name:'Nurse'},
        	{code:'16',name:'Other'},
        	{code:'46',name:'Photographer'},
        	{code:'47',name:'Physiotherapist'},
        	{code:'48',name:'Pilot/Navigator (Commercial Aircraft)'},
        	{code:'49',name:'Pilot/Navigator (Naval)'},
        	{code:'14',name:'Police'},
        	{code:'84',name:'Porter/Bellhop/Lift Attendant'},
        	{code:'64',name:'Post Graduate'},
        	{code:'51',name:'Printer'},
        	{code:'01',name:'Professional/Senior Administrative)'},
        	{code:'22',name:'Professor'},
        	{code:'64',name:'Property Developer'},
        	{code:'52',name:'Religious'},
        	{code:'53',name:'Reporter/Journalist'},
        	{code:'65',name:'Retail Sales Assistant'},
        	{code:'85',name:'Sailor/Merchant Navy'},
        	{code:'86',name:'Sales Professional'},
        	{code:'54',name:'Secretary/Stenographer'},
        	{code:'11',name:'Self-Employed'},
        	{code:'04',name:'Skilled Manual'},
        	{code:'55',name:'Social Worker'},
        	{code:'66',name:'Storeperson'},
        	{code:'56',name:'Supervisor'},
        	{code:'95',name:'Surveyor'},
        	{code:'57',name:'Tailor'},
        	{code:'12',name:'Teacher'},
        	{code:'59',name:'Technician'},
        	{code:'60',name:'Undertaker/Embalmer'},
        	{code:'15',name:'Unemployed'},
        	{code:'89',name:'Waiter'}
    ]


});


App.jobs = App.Jobs.create();