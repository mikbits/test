/*****************************************************************************
 * ARRAY CONTROLLER Bundles
 *****************************************************************************/


App.Bundles = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:1, name:'Day to Day account'},
        {code:2, name:'Multi Currency account'},
        {code:3, name:'Serious Saver account'},
        {code:7, name:'Flexisaver account'},
        {code:4, name:'Online Share Trading & Day to Day linked accounts'},
        {code:5, name:'Serious Saver & Day to Day linked accounts'},
        {code:6, name:'Multi Currency & Day to Day accounts'},
        {code:8, name:'Flexi Saver & Day to Day accounts'},
        {code:9, name:'Wealth Package'}
    ]
});


App.bundles = App.Bundles.create();