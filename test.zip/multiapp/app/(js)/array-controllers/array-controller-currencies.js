/*****************************************************************************
 * ARRAY CONTROLLER Currencies
 *****************************************************************************/


App.Currencies = Ember.ArrayController.extend(App.Options, App.Checkboxes, {


    /**
     * Properties
     */


    content:[
        {code:'AUD', name:'Australian Dollar'},
        {code:'HKD', name:'Hong Kong Dollar'},
        {code:'CNY', name:'Chinese Renminbi'},
        {code:'SGD', name:'Singapore Dollar'},
        {code:'JPY', name:'Japanese Yen'},
        {code:'USD', name:'United States Dollar'},
        {code:'CAD', name:'Canadian Dollar'},
        {code:'EUR', name:'Euro'},
        {code:'GBP', name:'Great Britain Pound Sterling'},
        {code:'NZD', name:'New Zealand Dollar'}
    ],


    /**
     * Methods
     */


    getCurrencyName:function (code) {
        var type = this.findProperty('code', code);

        if (type) {
            return type.name;

        } else {
            return '';
        }

    }


});


App.currencies = App.Currencies.create();