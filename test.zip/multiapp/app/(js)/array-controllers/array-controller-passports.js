/*****************************************************************************
 * ARRAY CONTROLLER Passport types
 *****************************************************************************/


App.Passports = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:'AUS', name:'Australian Passport'},
        {code:'INT', name:'International Passport'}
    ]


});


App.passports = App.Passports.create();