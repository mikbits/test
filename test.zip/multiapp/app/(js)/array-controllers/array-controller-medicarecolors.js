/*****************************************************************************
 * ARRAY CONTROLLER Medicare Card Colors
 *****************************************************************************/


App.MedicareColors = Ember.ArrayController.extend(App.Options, {



    /**
     * Properties
     */


    content:[
          	{code:'B',name:'Blue'},
        	{code:'G',name:'Green'},
        	{code:'Y',name:'Yellow'}
    ]
});


App.medicareColors = App.MedicareColors.create();
