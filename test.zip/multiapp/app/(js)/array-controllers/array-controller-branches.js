/*****************************************************************************
 * ARRAY CONTROLLER Branches
 *****************************************************************************/


App.Branches = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content: [
        {code: "B091", name: "Contact Centre"},
        {code: "B001", name: "Collins St, VIC"},
        {code: "B002", name: "Swanston St, VIC"},
        {code: "B003", name: "Box Hill, VIC"},
        {code: "B005", name: "Glen Waverley, VIC"},
        {code: "B006", name: "South Melbourne, VIC"},
        {code: "B007", name: "Chadstone, VIC"},
        {code: "B008", name: "Camberwell, VIC"},
        {code: "B009", name: "Doncaster, VIC"},
        {code: "B011", name: "Exchange, NSW"},
        {code: "B012", name: "Haymarket, NSW"},
        {code: "B015", name: "Hurstville, NSW"},
        {code: "B016", name: "Chatswood, NSW"},
        {code: "B017", name: "Parramatta, NSW"},
        {code: "B018", name: "Burwood, NSW"},
        {code: "B019", name: "Castle Hill, NSW"},
        {code: "B021", name: "Perth, WA"},
        {code: "B022", name: "Booragoon, WA"},
        {code: "B023", name: "Joondalup, WA"},
        {code: "B025", name: "Subiaco, WA"},
        {code: "B031", name: "Brisbane, QLD"},
        {code: "B032", name: "Sunnybank, QLD"},
        {code: "B033", name: "Gold Coast, QLD"},
        {code: "B039", name: "Adelaide, SA"},
        {code: "B075", name: "Hornsby, NSW"},
        {code: "B076", name: "Macquarie, NSW"},
        {code: "B077", name: "Maroubra, NSW"},
        {code: "B078", name: "Bondi Junction, NSW"},
        {code: "B079", name: "King St, NSW"},
        {code: "B080", name: "Town Hall, NSW"},
        {code: "B082", name: "Ashfield, NSW"},
        {code: "B083", name: "North Sydney, NSW"},
        {code: "B085", name: "Canberra, ACT"}
    ]


});


App.branches = App.Branches.create();