/*****************************************************************************
 * ARRAY CONTROLLER Purposes
 *****************************************************************************/


App.Purposes = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:'Salary and living expenses', name:'Salary and living expenses'},
        {code:'Savings', name:'Savings'},
        {code:'Investment', name:'Investment'},
        {code:'Loan repayment', name:'Loan repayment'},
        {code:'International payments', name:'International payments'},
        {code:'Educational funds', name:'Educational funds'}
    ]


});


App.purposes = App.Purposes.create();