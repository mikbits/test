/*****************************************************************************
 * ARRAY CONTROLLER Genders
 *****************************************************************************/


App.Genders = Ember.ArrayController.extend(App.Options, {


    /**
     * Properties
     */


    content:[
        {code:'M', name:'Male'},
        {code:'F', name:'Female'}
    ]


});


App.genders = App.Genders.create();