/*****************************************************************************
 * JSON ACTION Cross Retrieve
 *****************************************************************************/


App.JsonCrxRetrieveController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'crxRetrieve'
        });

        App.setBusy();
        this.postRequest(this);
    },


    successBack: function (response) {

        if (this.isSuccess(response)) {

        	this.loadSteps(response);
        	this.send('goToStep', App.getLastSavedStep() + 1);

        } else {
            this.handleException(response);
        }

        App.setReady();
    }


});
