/*****************************************************************************
 * JSON ACTION Submit IDs
 *****************************************************************************/


App.JsonSubmitIdsController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'submitIds',
            evidData: App.selfIdData.getObject()
        });

        App.setBusy();
        App.set('isBusy', false); // Just for pretty UI (page is still showing when waiting for answer)
        this.postRequest(this);
    },


    successBack: function (response) {
        this.handleException(response);
        App.setReady();
    }


});