/*****************************************************************************
 * JSON ACTION Refresh
 *****************************************************************************/


App.JsonIsOstExistsController = App.JsonActionController.extend({
	

    /**
     * Methods
     */


    run:function () {
    	var ostname = App.step1Data.get("tradingUsername");
        this.set('args', {
            cmd:'isOstExists',
            username: ostname
        });
        this.postRequest(this);
    },


    successBack:function (response) {
        var target=$("input[em-field=tradingUsername]");
        var emberId1=target.attr('id');
        var isBypassed = target.parents('div.blockToggle').hasClass('destroyed');
        var step1bundle = 'step1Bundle' + App.bundle;

        this.get('controllers.'+step1bundle).removeError(emberId1);
        if (this.isSuccess(response)) {
        	this.get('controllers.'+step1bundle).addInfo(isBypassed, emberId1, '<font color=green>User name is available.</font>');
        	target.removeClass('error');
    	} else {
        	this.get('controllers.'+step1bundle).addError(isBypassed, emberId1, 'The user name is not available, please enter a new one.');
        }
    } 
});