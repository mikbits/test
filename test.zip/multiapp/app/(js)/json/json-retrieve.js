/*****************************************************************************
 * JSON ACTION Retrieve
 *****************************************************************************/


App.JsonRetrieveController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'retrieve',

            option1: App.retrieveData.get('option') === 1 ? {
                birthDate: App.retrieveData.get('birthDate1'),
                applicationId: App.retrieveData.get('applicationId')
            } : null,

            option2: App.retrieveData.get('option') === 2 ? {
                birthDate: App.retrieveData.get('birthDate2'),
                email: App.retrieveData.get('email'),
                maidenName: App.retrieveData.get('maidenName')
            } : null

        });

        App.setBusy();
        App.set('isBusy', false); // Just for pretty UI (the retrieve page is still showing when loading)
        this.postRequest(this);
    },


    successBack: function (response) {

        if (this.isSuccess(response)) {
            if (response.bundle<10) {
                this.loadSteps(response);
                this.send('goToStep', App.getLastSavedStep() + 1);
            } else {
                // change to creditapp cross retrieve url later
                window.location.href = '/multiapp/creditapp.html#/crxRetrieve';
            }

        } else {
            if (response.bundle>10){
               // change to creditapp cross retrieve url later
               window.location.href = '/multiapp/creditapp.html#/crxRetrieve';
           }
           else{
                this.handleException(response);
            }
        }

        App.setReady();
    }


});