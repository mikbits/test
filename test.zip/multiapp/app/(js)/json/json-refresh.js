/*****************************************************************************
 * JSON ACTION Refresh
 *****************************************************************************/


App.JsonRefreshController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run:function () {

        this.set('args', {
            cmd:'refresh'
        });

        App.setBusy();
        this.postRequest(this);
    },


    successBack:function (response) {

        if (this.isSuccess(response)) {
            this.loadSteps(response);
            App.set('refresh', false);

            // On refresh, the router needs to be triggered again to run all didInsertElement in the view hierarchy
            this.goRoute('retrieve');
            this.send('goToStep', App.getCurrentStep(), true);

        } else {
            this.handleException(response);
        }

        App.setReady();
    }


});