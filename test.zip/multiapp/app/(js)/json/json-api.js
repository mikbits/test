/*****************************************************************************
 * JSON API
 *****************************************************************************/


App.JsonApiController = Ember.Controller.extend({


    /**
     * Methods
     */


    postRequest: function (jsonAction) {

        $.ajax({
            url: App.config.get('jsonApiUrl'),
            type: 'post',
            context: this,
            contentType: 'application/json', // Type of data sent to server
            data: jsonAction.getString(), // data sent to server, must be string
            dataType: 'json', // Type of response received from server
            timeout: App.get('jsonTimeOut'),

            success: function (response) {
                jsonAction.successBack(response);
            },

            error: function (jqXHR, textStatus, errorThrown) {
                if (errorThrown) jsonAction.failBack();
            }

        });

    }


});