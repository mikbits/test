/*****************************************************************************
 * JSON Submit
 *****************************************************************************/


App.JsonSubmitController = App.JsonActionController.extend({


    /**
     * Methods
     */
    submitting: null,

    run: function () {

        this.set('args', {
            cmd: 'submit',
            step6: App.step6Data.getObject()
        });

        App.setBusy();
        App.set('isBusy', false); // Just for pretty UI (step6 is still showing when waiting for answer)
        this.postRequest(this);
    },


    successBack: function (response) {
        // clear submitting flag
        this.set('submitting', false);

        // handle DFA Tag
        var status = response.responseStatus;
        
        if( 'error' === response.responseStatus && 'FE0001' === response.errorCode){
            App.setReady();
            var _this = this;
            $('div#validationError').modal({
                focus: false, 
                closeHTML: '<a class="modalCloseImg"></a>',
                onClose: function (dialog) {
                    $.modal.close(); 
                    _this.validateStep(1, 6);
                }
            });
        } else {
        
	        if (['selfID', 'pendingId', 'actionstep', 'processing','denial', 'idCheckReq', 'incomeCheckReq','onlineCalUs','approved','denied'].indexOf(status)>-1) {
	        	livePersonTagOnSubmitClickStart(App.applicationId, App.bundle);

	            webTrendTagResultPageStart(App.accountTypes, App.bundle);

	            callDynamicFloodLight(App.applicationId, App.bundle, App.accountTypes);
	        }
	
	        if (response.responseStatus == 'error' || response.responseStatus == 'expired') {
	            response.responseStatus = 'processing';
	        }
	
	        this.handleException(response);
	        App.setReady();
        }
    }

});