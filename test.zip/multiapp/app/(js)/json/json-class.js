/*****************************************************************************
 * JSON ACTION Class
 *****************************************************************************/


App.JsonActionController = App.JsonApiController.extend(App.Nav, {

    /**
     * Properties
     */

    needs:['step1Bundle4','step1Bundle9','step1Bundle10'],

    args: {},


    /**
     * Methods to be implemented by instances
     */


    run: function () {
    },
    successBack: function (response) {
    },


    /**
     * Methods to read Ajax response
     */


    isSuccess: function (response) {
        return response.responseStatus === 'success';
    },

    isEmailFailed: function(response) {
        return response.responseStatus === 'emailFailed';
    },


    getApplicationId: function (response) {
        return response.applicationId;
    },


    getBundle: function (response) {
        return response.bundle;
    },


    getCommand: function (response) {
        return response.cmd;
    },


    getStep: function (response, step) {
        switch (step) {

            case 1:
                return response.step1;
                break;

            case 2:
                return response.step2;
                break;

            case 3:
                return response.step3;
                break;

            case 4:
                return response.step4;
                break;

            case 5:
                return response.step5;
                break;

            default:
                return null;

        }
    },


    getResponsePageData: function (response) {
        return response.approvalData;
    },

    getResponseIdData: function (response) {
        return response.selfIdData;
    },


    getApplicationsData: function (response) {
        return response.applications;
    },


    /**
     * Other methods
     */


    failBack: function () {
        App.setReady();
        this.goRoute('errorAjax');
    },


    handleException: function (response) {
        App.responseData.set('applicationId', this.getApplicationId(response));
        App.responseData.set('errorCode',response.errorCode);

        var status = response.responseStatus;

        switch (status) {

            case 'notFound':
                App.retrieveData.set('notFound', true);
                break;

            case 'expired':
                this.goRouteAndReset('timeout');
                break;

            case 'sessionNotFound':

                if (App.get('isStep1') === false) {
                    this.goRouteAndReset('retrieve');
                }

                break;

            case 'error':
            	App.set('applicantionId',response.applicationId);
                App.set('applicantData',response.applicantData);

                this.goRouteAndReset('error');
                break;

            case 'processing':
                App.set('applicationId',response.applicationId);
                App.set('bundle',response.bundle);
                App.set('accountTypes',response.accountTypes);
                this.goRouteAndReset('processing');
                App.responseData.setProperties(response.approvalData);
                break;

            case 'approved':
                App.set('applicationId',response.applicationId);
                App.set('bundle',response.bundle);
                App.set('accountTypes',response.accountTypes);
                this.goRouteAndReset('approved');
                App.responseData.setProperties(response.approvalData);
                break;

            case 'pendingId':
                App.set('applicationId',response.applicationId);
                App.set('bundle',response.bundle);
                App.set('accountTypes',response.accountTypes);
                this.goRouteAndReset('pendingId');
                App.responseData.setProperties(response);
                var applicantData=App.ApplicantData.create();
                applicantData.setProperties(response.applicantData);
                App.responseData.set('applicantData',applicantData);
                var partnerData=App.ApplicantData.create();
                partnerData.setProperties(response.partnerData);
                App.responseData.set('partnerData',partnerData);
                break;

            case 'selfId':
                App.set('applicationId',response.applicationId);
                App.set('bundle',response.bundle);
                App.set('accountTypes',response.accountTypes);
                var selfIdData = response.selfIdData;
                var applicantData = response.applicantData;

                this.goRouteAndReset('selfId');
                App.selfIdData.setProperties(selfIdData);
                App.selfIdData.setProperties(applicantData);
                break;

            case 'multi':
                this.goRoute('chooseApp');
                App.appSums = App.AppSums.create();
                var array = this.getApplicationsData(response);

                array.forEach(function (item) {
                    App.appSums.addObject(item);
                });

                break;

            case 'notMatch':
                App.set('applicationId',response.applicationId);
                App.step6Data.set('captchErrorMessage','Your input does not match, please try again.');
                break;

            case 'tradingUserNameInvalid':
            	this.send('goToStep', 1);
                var target=$("input[em-field=tradingUsername]");
                var emberId1=target.attr('id');
                var msg="The user name is not available, please enter a new one.";
                var asideClass=target.attr('em-aside');
                var isBypassed = target.parents('div.blockToggle').hasClass('destroyed');
                this.get('controllers.step1Bundle'+App.get('bundle')).addError(isBypassed, emberId1, msg, asideClass);
                App.set('hasSavedStep1', false);
                App.setReady();
                App.ux.scrollFirstError();
                break;

            case 'tradingUserNamePartnerInvalid':
                this.send('goToStep', 1);
                var target=$("input[em-field=tradingUsernamePartner]");
                var emberId1=target.attr('id');
                var msg="The user name is not available, please enter a new one.";
                var asideClass=target.attr('em-aside');
                var isBypassed = target.parents('div.blockToggle').hasClass('destroyed');
                this.get('controllers.step1Bundle'+App.get('bundle')).addError(isBypassed, emberId1, msg, asideClass);
                App.set('hasSavedStep1', false);
                App.setReady();
                App.ux.scrollFirstError();
                break;
        }

    },


    getString: function () {
        return JSON.stringify(this.get('args'));
    },


    loadSteps: function (response) {
        for (var i = 1; i <= 5; i++) {
            var stepData = this.getStep(response, i);

            if (stepData) {
                App.set('hasSavedStep' + i, true);
                App.set('isStep' + i + 'Dirty', false);

                switch (i) {
                    case 1:
                        App.step1Data.setProperties(stepData);
                        break;

                    case 2:
                        var step2 = App.step2Data;

                        step2.setProperties(stepData);

                        if (step2.get('street')) {
                            step2.set('addr1Validated', true);
                        }

                        if (step2.get('previousAddressStreet')) {
                            step2.set('addr2Validated', true);
                        }

                        if (step2.get('partnerAddressStreet')) {
                            step2.set('addr3Validated', true);
                        }

                        if (step2.get('partnerPreviousAddressStreet')) {
                            step2.set('addr4Validated', true);
                        }

                        break;

                    case 3:
                        App.step3Data.setProperties(stepData);
                        break;

                    case 4:
                        App.step4Data.setProperties(stepData);
                        break;

                    case 5:
                        App.step5Data.setProperties(stepData);
                        App.step5Data.setAccBooleans(stepData.accountTypes);
                        break;

                }
            }
        }

        App.set('applicationId', this.getApplicationId(response));
        App.set('bundle', this.getBundle(response));
    }


});