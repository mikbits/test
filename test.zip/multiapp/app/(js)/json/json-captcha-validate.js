/*****************************************************************************
 * JSON ACTION Retrieve
 *****************************************************************************/


App.JsonCaptchaValidateController = App.JsonActionController.extend({


    /**
     * Methods
     */
    run: function () {

        this.set('args', {
            cmd: 'captchaValidate',
            type: App.config.get('captchaType'),
            userInput:App.step6Data.get('userInput')
        });

        this.postRequest(this);
    },

    isNotMatch: function (response) {
        return response.responseStatus === 'notMatch';
    },

    successBack: function (response) {

        if (this.isSuccess(response)) {
        	App.step6Data.set('captchErrorMessage','Great! Your input matches the Captcha image.');
        } else if(this.isNotMatch(response)){
            App.step6Data.set('captchErrorMessage','Your input does not match, please try again.');
        } else {
        	App.step6Data.set('captchErrorMessage','Technical error.');
        }
    }

});