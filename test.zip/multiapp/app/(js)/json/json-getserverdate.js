/*****************************************************************************
 * JSON ACTION Refresh
 *****************************************************************************/


App.JsonGetServerDateController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run:function () {

        this.set('args', {
            cmd:'getServerDate'
        });

        this.postRequest(this);
    },


    successBack:function (response) {

        if (this.isSuccess(response)) {
            App.validationController.set('serverDate', response.serverDate);
        } else {
            this.handleException(response);
        }
    }


});