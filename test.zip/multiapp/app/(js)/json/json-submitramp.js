/*****************************************************************************
 * JSON ACTION Submit RAMP step 0
 *****************************************************************************/


App.JsonSubmitRampController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'submitRamp',
            hubId: App.rampData.get('hubId'),
            branch: App.rampData.get('branch'),
            bundle: App.rampData.get('bundle')
        });

        this.postRequest(this);
    },


    successBack: function (response) {
        this.handleException(response);
    }


});