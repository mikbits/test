/*****************************************************************************
 * JSON Save
 *****************************************************************************/


App.JsonSaveController = App.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'save',
            bundle: App.get('bundle'),
            step1: App.get('hasSavedStep1') ? App.step1Data.getObject() : null,
            step2: App.get('hasSavedStep2') ? App.step2Data.getObject() : null,
            step3: App.get('hasSavedStep3') ? App.step3Data.getObject() : null,
            step4: App.get('hasSavedStep4') ? App.step4Data.getObject() : null,
            step5: App.get('hasSavedStep5') ? App.step5Data.getObject() : null
        });

        this.postRequest(this);
    },


    successBack: function (response) {

        App.setReady();
        var status = response.responseStatus;
        var currentStep=App.getCurrentStep();
        if(currentStep===1 && (App.get('bundle')===4 || App.get('bundle')===9)) {
            App.nothingDirtyUntil(currentStep);
            this.send('goToStep', 2);
        }

        switch (status) {
            case 'success':
                App.set('applicationId',this.getApplicationId(response));
                App.set('bundle',response.bundle);
                App.set('accountTypes',response.accountTypes);
                break;

            case 'emailFailed':
                App.set('applicationId',this.getApplicationId(response));
                App.ux.openModal('emailFailedInfo');
                break;

            case 'existing':
                App.set('applicationId',this.getApplicationId(response));
                App.set('bundle',response.bundle);
                App.set('accountTypes',response.accountTypes);
                this.loadSteps(response);
                App.ux.openModal('existingAppInfo');
                break;
            case 'error':
            	if('FE0001' === response.errorCode){
            		var _this = this;
            		var lastSavedStep= App.getLastSavedStep();
            		$('div#validationError').modal({
            			focus: false, 
            			closeHTML: '<a class="modalCloseImg"></a>',
            			onClose: function (dialog) {
            				$.modal.close(); 
            				_this.validateStep(1, lastSavedStep);
            			}
            		});
            	}else{
                    this.handleException(response);            		
            	}
                break;
            default:
                this.handleException(response);
                break;
        }

    }

});