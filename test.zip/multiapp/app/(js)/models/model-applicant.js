/*****************************************************************************
 * MODEL Response
 *****************************************************************************/


App.ApplicantData = App.Model.extend({


    /**
     * Properties
     */

    title: null,
    firstName: null,
    lastName: null,
    email: null


});

