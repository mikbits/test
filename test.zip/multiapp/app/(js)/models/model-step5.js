/*****************************************************************************
 * MODEL Step 5
 *****************************************************************************/


App.Step5Data = App.Model.extend(App.BundleLogic, {


    /**
     * Properties
     */


    // First applicant
    activities: [],
    mainReason: null,
    bsb: null,
    accNb: null,
    bank: null,

    // Cross sale, accounts
    d2d: null,
    flexiSaver: null,
    multiCurrency: null,
    multiCurrencyMainBinding: 'App.step1Data.multiCurrencyMain',
    otherCurrenciesBinding: 'App.step1Data.otherCurrencies',
    withoutDebitCardBinding: 'App.step1Data.withoutDebitCard',
    partnerWithoutDebitCardBinding: 'App.step1Data.partnerWithoutDebitCard',


    /**
     * Computed properties for back-end
     */


    bsbRe: function () {
        return App.step1Data.get('isSaverLinkedToHsbc') === true ? null : this.get('bsb');
    }.property('bsb', 'App.step1Data.isSaverLinkedToHsbc'),


    accNbRe: function () {
        return App.step1Data.get('isSaverLinkedToHsbc') === true ? null : this.get('accNb');
    }.property('accNb', 'App.step1Data.isSaverLinkedToHsbc'),


    bankRe: function () {
        return App.step1Data.get('isSaverLinkedToHsbc') === true ? null : this.get('bank');
    }.property('bank', 'App.step1Data.isSaverLinkedToHsbc'),


    accountTypesRe: function () {
        var bundle = App.get('bundle');
        var array = [];

        if (this.hasSeriousSaver(bundle)) {
            array.push('SSP');
            if(App.step1Data.get('isSaverLinkedToHsbc')){
                array.push('CMG');
            }
        }

        if (this.hasMultiCurrency(bundle) || this.get('multiCurrency')) {
            array.push('MSV');
        }

        if (this.hasOnlineTrading(bundle)) {
            array.push('OST');
        }

        if (this.hasFlexiSaver(bundle) || this.get('flexiSaver')) {
            array.push('ACS');
        }

        if (this.hasDtd(bundle) || this.get('d2d')) {
            array.push('CMG');
        }

        return array;
    }.property('d2d', 'seriousSaver', 'multiCurrency', 'flexiSaver', 'App.bundle','App.step1Data.isSaverLinkedToHsbc'),


    /**
     * Other computed properties
     */


    multiCurrencyMainLong: function () {
        return App.currencies.getCurrencyName(this.get('multiCurrencyMain'));
    }.property('multiCurrencyMain'),


    /**
     * Methods
     */


    findAcc: function (array, acc) {
        var found = false;

        array.forEach(function (el) {

            if (el === acc) {
                found = true;
            }

        });

        return found;
    },


    setAccBooleans: function (array) {
        if(array) {
            if (this.findAcc(array, 'CMG')) {
                this.set('d2d', true);
            }

            if (this.findAcc(array, 'MSV')) {
                this.set('multiCurrency', true);
            }

            if (this.findAcc(array, 'ACS')) {
                this.set('flexiSaver', true);
            }
        }

    },


    getObject: function () {

        return {
            activities: this.get('activities'),
            mainReason: this.get('mainReason'),
            bsb: this.get('bsbRe'),
            accNb: this.get('accNbRe'),
            bank: this.get('bankRe'),
            accountTypes: this.get('accountTypesRe')
        };

    }


});


App.step5Data = App.Step5Data.create();