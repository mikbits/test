/*****************************************************************************
 * MODEL Step 4
 *****************************************************************************/


App.Step4Data = App.Model.extend({


    /**
     * Properties
     */


    // First applicant
    industry: null,
    employer: null,
    occupation: null,
    job: null,
    incomeSource: null,
    photoId: null,
    licenceState: null,
    licenceExpiryDate: null,
    licenceNumber: null,
    licenceCardNumber: null,
    ozPassportCountry: 'AUS', // Default value
    ozPassportCountryBirthBinding: 'App.step3Data.countryBirth',
    ozPassportPlaceBirth: null,
    ozPassportNameBirth: null,
    ozPassportNumber: null,
    intPassportCountry: null,
    intPassportNumber: null,

    // Second applicant
    partnerIndustry: null,
    partnerEmployer: null,
    partnerOccupation: null,
    partnerJob: null,
    partnerIncomeSource: null,
    partnerPhotoId: null,
    partnerLicenceState: null,
    partnerLicenceExpiryDate: null,
    partnerLicenceNumber: null,
    partnerLicenceCardNumber: null,
    partnerOzPassportCountry: 'AUS', // Default value
    partnerOzPassportCountryBirthBinding: 'App.step3Data.partnerCountryBirth',
    partnerOzPassportPlaceBirth: null,
    partnerOzPassportNameBirth: null,
    partnerOzPassportNumber: null,
    partnerIntPassportCountry: null,
    partnerIntPassportNumber: null,


    /**
     *  Computed properties for back-end
     */


    licenceStateRe: function () {
        return this.get('photoId') != App.ids.getLicenceCode() ? null : this.get('licenceState');
    }.property('licenceState', 'photoId'),


    licenceExpiryDateRe: function () {
        return this.get('photoId') != App.ids.getLicenceCode() ? null : this.get('licenceExpiryDate');
    }.property('licenceExpiryDate', 'photoId'),


    licenceNumberRe: function () {
        return this.get('photoId') != App.ids.getLicenceCode() ? null : this.get('licenceNumber');
    }.property('licenceNumber', 'photoId'),


    licenceCardNumberRe: function () {
        return this.get('photoId') != App.ids.getLicenceCode() ? null : this.get('licenceCardNumber');
    }.property('licenceCardNumber', 'photoId'),


    ozPassportCountryBirthRe: function () {
        return this.get('photoId') != App.ids.getOzPassportCode() ? null : this.get('ozPassportCountryBirth');
    }.property('ozPassportCountryBirth', 'photoId'),


    ozPassportPlaceBirthRe: function () {
        return this.get('photoId') != App.ids.getOzPassportCode() ? null : this.get('ozPassportPlaceBirth');
    }.property('ozPassportPlaceBirth', 'photoId'),


    ozPassportNameBirthRe: function () {
        return this.get('photoId') != App.ids.getOzPassportCode() ? null : this.get('ozPassportNameBirth');
    }.property('ozPassportNameBirth', 'photoId'),


    ozPassportNumberRe: function () {
        return this.get('photoId') != App.ids.getOzPassportCode() ? null : this.get('ozPassportNumber');
    }.property('ozPassportNumber', 'photoId'),


    intPassportCountryRe: function () {
        return this.get('photoId') != App.ids.getIntPassportCode() ? null : this.get('intPassportCountry');
    }.property('intPassportCountry', 'photoId'),


    intPassportNumberRe: function () {
        return this.get('photoId') != App.ids.getIntPassportCode() ? null : this.get('intPassportNumber');
    }.property('intPassportNumber', 'photoId'),

    industryName: function(){
        var result=this.get('industry');
        if(this.get('industry')){
            if(App.industries.findProperty('code',this.get('industry'))){
               result=App.industries.findProperty('code',this.get('industry')).name;
            }
        }
        return result;
    }.property('industry'),

    partnerIndustryName: function () {
        var partnerIndustry=(!App.step1Data.get('isJoint') ? null : this.get('partnerIndustry'));
        var result=this.get('partnerIndustry');
        if(partnerIndustry){
            if(App.industries.findProperty('code',this.get('partnerIndustry'))){
               result=App.industries.findProperty('code',this.get('partnerIndustry')).name;
            }
        }
        return result;
    }.property('partnerIndustry', 'App.step1Data.isJoint'),

    partnerIndustryRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerIndustry');
    }.property('partnerIndustry', 'App.step1Data.isJoint'),

    partnerEmployerRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerEmployer');
    }.property('partnerEmployer', 'App.step1Data.isJoint'),

    occupationName: function(){
        var result=this.get('occupation');
        if(this.get('occupation')){
            if(App.jobs.findProperty('code',this.get('occupation'))){
               result=App.jobs.findProperty('code',this.get('occupation')).name;
            }
        }
        return result;
    }.property('occupation'),

    incomeSourceName: function(){
        var result=this.get('incomeSource');
        if(this.get('incomeSource')){
            if(App.incomes.findProperty('code',this.get('incomeSource'))){
               result=App.incomes.findProperty('code',this.get('incomeSource')).name;
            }
        }
        return result;
    }.property('incomeSource'),

    partnerOccupationName: function () {
        var partnerOccupation=(!App.step1Data.get('isJoint') ? null : this.get('partnerOccupation'));
        var result=this.get('partnerOccupation');
        if(partnerOccupation){
            if(App.jobs.findProperty('code',this.get('partnerOccupation'))){
               result=App.jobs.findProperty('code',this.get('partnerOccupation')).name;
            }
        }
        return result;
    }.property('partnerOccupation', 'App.step1Data.isJoint'),

    partnerIncomeSourceName: function () {
        var partnerIncomeSource=(!App.step1Data.get('isJoint') ? null : this.get('partnerIncomeSource'));
        var result=this.get('partnerIncomeSource');
        if(partnerIncomeSource){
            if(App.incomes.findProperty('code',this.get('partnerIncomeSource'))){
               result=App.incomes.findProperty('code',this.get('partnerIncomeSource')).name;
            }
        }
        return result;
    }.property('partnerIncomeSource', 'App.step1Data.isJoint'),

    partnerOccupationRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerOccupation');
    }.property('partnerOccupation', 'App.step1Data.isJoint'),


    partnerJobRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerJob');
    }.property('partnerJob', 'App.step1Data.isJoint'),


    partnerIncomeSourceRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerIncomeSource');
    }.property('partnerIncomeSource', 'App.step1Data.isJoint'),


    partnerPhotoIdRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerPhotoId');
    }.property('partnerPhotoId', 'App.step1Data.isJoint'),


    partnerLicenceStateRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getLicenceCode()) ? null : this.get('partnerLicenceState');
    }.property('partnerLicenceState', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerLicenceExpiryDateRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getLicenceCode()) ? null : this.get('partnerLicenceExpiryDate');
    }.property('partnerLicenceExpiryDate', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerLicenceNumberRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getLicenceCode()) ? null : this.get('partnerLicenceNumber');
    }.property('partnerLicenceNumber', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerLicenceCardNumberRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getLicenceCode()) ? null : this.get('partnerLicenceCardNumber');
    }.property('partnerLicenceCardNumber', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerOzPassportCountryBirthRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getOzPassportCode()) ? null : this.get('partnerOzPassportCountryBirth');
    }.property('partnerOzPassportCountryBirth', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerOzPassportPlaceBirthRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getOzPassportCode()) ? null : this.get('partnerOzPassportPlaceBirth');
    }.property('partnerOzPassportPlaceBirth', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerOzPassportNameBirthRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getOzPassportCode()) ? null : this.get('partnerOzPassportNameBirth');
    }.property('partnerOzPassportNameBirth', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerOzPassportNumberRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getOzPassportCode()) ? null : this.get('partnerOzPassportNumber');
    }.property('partnerOzPassportNumber', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerIntPassportCountryRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getIntPassportCode()) ? null : this.get('partnerIntPassportCountry');
    }.property('partnerIntPassportCountry', 'partnerPhotoId', 'App.step1Data.isJoint'),


    partnerIntPassportNumberRe: function () {
        return !App.step1Data.get('isJoint') || (this.get('partnerPhotoId') != App.ids.getIntPassportCode()) ? null : this.get('partnerIntPassportNumber');
    }.property('partnerIntPassportNumber', 'partnerPhotoId', 'App.step1Data.isJoint'),


    /**
     * Other computed properties
     */


    intPassportCountryLong: function () {
        return App.countries.getCountryName(this.get('intPassportCountry'));
    }.property('intPassportCountry'),


    partnerIntPassportCountryLong: function () {
        return App.countries.getCountryName(this.get('partnerIntPassportCountry'));
    }.property('partnerIntPassportCountry'),


    ozPassportCountryBirthLong: function () {
        return App.countries.getCountryName(this.get('ozPassportCountryBirth'));
    }.property('ozPassportCountryBirth'),


    partnerOzPassportCountryBirthLong: function () {
        return App.countries.getCountryName(this.get('partnerOzPassportCountryBirth'));
    }.property('partnerOzPassportCountryBirth'),


    /**
     * Methods
     */


    getObject: function () {

        return {
            industry: this.get('industry'),
            employer: this.get('employer'),
            occupation: this.get('occupation'),
            job: this.get('job'),
            incomeSource: this.get('incomeSource'),
            photoId: this.get('photoId'),
            licenceState: this.get('licenceStateRe'),
            licenceExpiryDate: this.get('licenceExpiryDateRe'),
            licenceNumber: this.get('licenceNumberRe'),
            licenceCardNumber: this.get('licenceCardNumberRe'),
            ozPassportCountry: this.get('ozPassportCountry'),
            ozPassportCountryBirth: this.get('ozPassportCountryBirthRe'),
            ozPassportPlaceBirth: this.get('ozPassportPlaceBirthRe'),
            ozPassportNameBirth: this.get('ozPassportNameBirthRe'),
            ozPassportNumber: this.get('ozPassportNumberRe'),
            intPassportCountry: this.get('intPassportCountryRe'),
            intPassportNumber: this.get('intPassportNumberRe'),
            partnerIndustry: this.get('partnerIndustryRe'),
            partnerEmployer: this.get('partnerEmployerRe'),
            partnerOccupation: this.get('partnerOccupationRe'),
            partnerJob: this.get('partnerJobRe'),
            partnerIncomeSource: this.get('partnerIncomeSourceRe'),
            partnerPhotoId: this.get('partnerPhotoIdRe'),
            partnerLicenceState: this.get('partnerLicenceStateRe'),
            partnerLicenceExpiryDate: this.get('partnerLicenceExpiryDateRe'),
            partnerLicenceNumber: this.get('partnerLicenceNumberRe'),
            partnerLicenceCardNumber: this.get('partnerLicenceCardNumberRe'),
            partnerOzPassportCountry: this.get('partnerOzPassportCountry'),
            partnerOzPassportCountryBirth: this.get('partnerOzPassportCountryBirthRe'),
            partnerOzPassportPlaceBirth: this.get('partnerOzPassportPlaceBirthRe'),
            partnerOzPassportNameBirth: this.get('partnerOzPassportNameBirthRe'),
            partnerOzPassportNumber: this.get('partnerOzPassportNumberRe'),
            partnerIntPassportCountry: this.get('partnerIntPassportCountryRe'),
            partnerIntPassportNumber: this.get('partnerIntPassportNumberRe')
        };

    }


});


App.step4Data = App.Step4Data.create();