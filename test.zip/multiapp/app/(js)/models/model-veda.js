/*****************************************************************************
 * MODEL Veda response
 *****************************************************************************/


App.VedaResponse = Ember.Object.extend({


    /**
     * Properties
     */


    ajaxStatus:false,
    response:null


});


App.vedaResponse = App.VedaResponse.create();