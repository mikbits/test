/*****************************************************************************
 * MODEL Retrieval
 *****************************************************************************/


App.RetrieveData = Ember.Object.extend({


    /**
     * Properties
     */


    option: null,
    notFound: false,

    // Option 1
    birthDate1: null,
    applicationId: null,

    // Option 2
    birthDate2: null,
    email: null,
    maidenName: null


});


App.retrieveData = App.RetrieveData.create();