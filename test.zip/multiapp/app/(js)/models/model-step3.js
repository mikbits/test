/*****************************************************************************
 * MODEL Step 3
 *****************************************************************************/


App.Step3Data = App.Model.extend({


    /**
     * Properties
     */

    // First applicant
    gender:null,
    isResident:null,
    nationality:null,
    hasMultipleNat:null,
    nationality2:null,
    nationality3:null,
    countryBirth:null,
    countryTax:null,
    tfn:null,
    tfnExempted:null,
    usPersonForTax: null,

    // Second applicant
    partnerGender:null,
    partnerIsResident:null,
    partnerNationality:null,
    partnerHasMultipleNat:null,
    partnerNationality2:null,
    partnerNationality3:null,
    partnerCountryBirth:null,
    partnerCountryTax:null,
    partnerTfn:null,
    partnerTfnExempted:null,
    partnerUsPersonForTax: null,


    /**
     * Computed properties for back-end
     */


    nationality2Re:function () {
        return this.get('hasMultipleNat') ? this.get('nationality2') : null;
    }.property('nationality2', 'hasMultipleNat'),


    nationality3Re: function () {
        var value = this.get('nationality3');
        return (this.get('hasMultipleNat') && (value != 'seperator')) ? value : null;
    }.property('nationality3', 'hasMultipleNat'),


    partnerGenderRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerGender');
    }.property('partnerGender', 'App.step1Data.isJoint'),

    genderName: function(){
        var result=this.get('gender');
        if(this.get('gender')){
            if(App.genders.findProperty('code',this.get('gender'))){
               result=App.genders.findProperty('code',this.get('gender')).name;
            }
        }
        return result;
    }.property('gender'),

    partnerGenderName: function(){
        var result=this.get('partnerGender');
        if(this.get('partnerGender')){
            if(App.genders.findProperty('code',this.get('partnerGender'))){
                result=App.genders.findProperty('code',this.get('partnerGender')).name;
            }
        }
        return result;
    }.property('partnerGender'),


    partnerIsResidentRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerIsResident');
    }.property('partnerIsResident', 'App.step1Data.isJoint'),


    partnerNationalityRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerNationality');
    }.property('partnerNationality', 'App.step1Data.isJoint'),


    partnerHasMultipleNatRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerHasMultipleNat');
    }.property('partnerHasMultipleNat', 'App.step1Data.isJoint'),


    partnerNationality2Re:function () {
        return (!App.step1Data.get('isJoint') || !this.get('partnerHasMultipleNat')) ? null : this.get('partnerNationality2');
    }.property('partnerNationality2', 'partnerHasMultipleNat', 'App.step1Data.isJoint'),


    partnerNationality3Re: function () {
        var value = this.get('partnerNationality3');
        return (!App.step1Data.get('isJoint') || !this.get('partnerHasMultipleNat') || value === 'seperator') ? null : value;
    }.property('partnerNationality3', 'partnerHasMultipleNat', 'App.step1Data.isJoint'),


    partnerCountryBirthRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerCountryBirth');
    }.property('partnerCountryBirth', 'App.step1Data.isJoint'),


    partnerCountryTaxRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerCountryTax');
    }.property('partnerCountryTax', 'App.step1Data.isJoint'),


    partnerTfnRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerTfn');
    }.property('partnerTfn', 'App.step1Data.isJoint'),


    partnerTfnExemptedRe:function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerTfnExempted');
    }.property('partnerGender', 'App.step1Data.isJoint'),


    /**
     * Other computed properties
     */


    nationalityLong:function () {
        return App.countries.getCountryName(this.get('nationality'));
    }.property('nationality'),


    countryBirthLong:function () {
        return App.countries.getCountryName(this.get('countryBirth'));
    }.property('countryBirth'),


    countryTaxLong:function () {
        return App.countries.getCountryName(this.get('countryTax'));
    }.property('countryTax'),


    nationality2Long:function () {
        return App.countries.getCountryName(this.get('nationality2'));
    }.property('nationality2'),

    nationality3Long:function () {
        return App.countries.getCountryName(this.get('nationality3'));
    }.property('nationality3'),

    partnerNationalityLong:function () {
        return App.countries.getCountryName(this.get('partnerNationality'));
    }.property('partnerNationality'),


    partnerCountryBirthLong:function () {
        return App.countries.getCountryName(this.get('partnerCountryBirth'));
    }.property('partnerCountryBirth'),


    partnerCountryTaxLong:function () {
        return App.countries.getCountryName(this.get('partnerCountryTax'));
    }.property('partnerCountryTax'),


    partnerNationality2Long:function () {
        return App.countries.getCountryName(this.get('partnerNationality2'));
    }.property('partnerNationality2'),

    partnerNationality3Long:function () {
        return App.countries.getCountryName(this.get('partnerNationality3'));
    }.property('partnerNationality3'),
    /**
     * Methods
     */


    getObject:function () {

    	//since the model object does is not picking the data already selected before display. So, firing an onchange event would update the model layer with the already selected drop down option.
        if (null === this.get('tfnExempted'))
        	$('select[em-field="tfnExempted"]').change();
        if (null === this.get('partnerTfnExempted'))
        	$('select[em-field="partnerTfnExempted"]').change();
    	
        return  {
            gender:this.get('gender'),
            isResident:this.get('isResident'),
            nationality:this.get('nationality'),
            hasMultipleNat:this.get('hasMultipleNat'),
            nationality2:this.get('nationality2Re'),
            nationality3:this.get('nationality3Re'),
            countryBirth:this.get('countryBirth'),
            countryTax:this.get('countryTax'),
            tfn:this.get('tfn'),
            tfnExempted:this.get('tfnExempted'),
            usPersonForTax:this.get('usPersonForTax'),
            partnerGender:this.get('partnerGenderRe'),
            partnerIsResident:this.get('partnerIsResidentRe'),
            partnerNationality:this.get('partnerNationalityRe'),
            partnerHasMultipleNat:this.get('partnerHasMultipleNatRe'),
            partnerNationality2:this.get('partnerNationality2Re'),
            partnerNationality3:this.get('partnerNationality3Re'),
            partnerCountryBirth:this.get('partnerCountryBirthRe'),
            partnerCountryTax:this.get('partnerCountryTaxRe'),
            partnerTfn:this.get('partnerTfnRe'),
            partnerTfnExempted:this.get('partnerTfnExemptedRe'),
            partnerUsPersonForTax:this.get('partnerUsPersonForTax')
        };

    }


});


App.step3Data = App.Step3Data.create();