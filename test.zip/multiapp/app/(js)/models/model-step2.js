/*****************************************************************************
 * MODEL Step 2
 *****************************************************************************/


App.Step2Data = App.Model.extend({


    /**
     * Properties
     */


    // Geocoder
    addr1Validated: false,
    addr2Validated: false,
    addr3Validated: false,
    addr4Validated: false,

    // First Applicant
    unitNb: null,
    streetNb: null,
    street: null,
    streetType: null, // Default value
    suburb: null,
    state: null,
    postcode: null,
    country: 'AUS', // Default value
    years: null,
    months: null,
    previousAddressUnitNb: null,
    previousAddressStreetNb: null,
    previousAddressStreet: null,
    previousAddressStreetType: null, // Default value
    previousAddressSuburb: null,
    previousAddressState: null,
    previousAddressPostcode: null,
    previousAddressCountry: 'AUS', // Default value

    // Second applicant
    partnerCustomerNumber: null,
    partnerFirstNameBinding: 'App.step1Data.partnerFirstName',
    partnerMiddleNameBinding: 'App.step1Data.partnerMiddleName',
    partnerLastNameBinding: 'App.step1Data.partnerLastName',
    partnerTitleBinding: 'App.step1Data.partnerTitle',
    partnerEmail: null,
    partnerEmailConfirm: null,
    partnerHomePhone: null,
    partnerMobilePhone: null,
    partnerBirthDate: null,
    partnerHasSameAddress: null,
    partnerAddressUnitNb: null,
    partnerAddressStreetNb: null,
    partnerAddressStreet: null,
    partnerAddressStreetType: null, // Default value
    partnerAddressSuburb: null,
    partnerAddressState: null,
    partnerAddressPostcode: null,
    partnerAddressCountry: 'AUS', // Default value
    partnerYears: null,
    partnerMonths: null,
    partnerPreviousAddressUnitNb: null,
    partnerPreviousAddressStreetNb: null,
    partnerPreviousAddressStreet: null,
    partnerPreviousAddressStreetType: null, // Default value
    partnerPreviousAddressSuburb: null,
    partnerPreviousAddressState: null,
    partnerPreviousAddressPostcode: null,
    partnerPreviousAddressCountry: 'AUS', // Default value


    /**
     * Computed properties for back-end
     */


    previousAddressUnitNbRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressUnitNb') : null;
    }.property('previousAddressUnitNb', 'years'),


    previousAddressStreetNbRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressStreetNb') : null;
    }.property('previousAddressStreetNb', 'years'),


    previousAddressStreetRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressStreet') : null;
    }.property('previousAddressStreet', 'years'),


    previousAddressStreetTypeRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressStreetType') : null;
    }.property('previousAddressStreetType', 'years'),


    previousAddressSuburbRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressSuburb') : null;
    }.property('previousAddressSuburb', 'years'),


    previousAddressStateRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressState') : null;
    }.property('previousAddressState', 'years'),


    previousAddressPostcodeRe: function () {
        return this.getYearsInt() < App.get('previousAddressTrigger') ? this.get('previousAddressPostcode') : null;
    }.property('previousAddressPostcode', 'years'),


    partnerEmailRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerEmail');
    }.property('partnerEmail', 'App.step1Data.isJoint'),


    partnerEmailConfirmRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerEmailConfirm');
    }.property('partnerEmailConfirm', 'App.step1Data.isJoint'),


    partnerHomePhoneRe: function () {
        var value = this.get('partnerHomePhone') ? this.get('partnerHomePhone') : '';
        return !App.step1Data.get('isJoint') ? null : value.replace(/\-/g, '');
    }.property('partnerHomePhone', 'App.step1Data.isJoint'),


    partnerMobilePhoneRe: function () {
        var value = this.get('partnerMobilePhone') ? this.get('partnerMobilePhone') : '';
        return !App.step1Data.get('isJoint') ? null : value.replace(/\-/g, '');
    }.property('partnerMobilePhone', 'App.step1Data.isJoint'),


    partnerBirthDateRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerBirthDate');
    }.property('partnerBirthDate', 'App.step1Data.isJoint'),


    partnerHasSameAddressRe: function () {
        return !App.step1Data.get('isJoint') ? null : this.get('partnerHasSameAddress');
    }.property('partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressUnitNbRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('unitNb');

        } else {
            return this.get('partnerAddressUnitNb');
        }

    }.property('partnerAddressUnitNb', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressStreetNbRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('streetNb');

        } else {
            return this.get('partnerAddressStreetNb');
        }

    }.property('partnerAddressStreetNb', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressStreetRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('street');

        } else {
            return this.get('partnerAddressStreet');
        }

    }.property('partnerAddressStreet', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressStreetTypeRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('streetType');

        } else {
            return this.get('partnerAddressStreetType');
        }

    }.property('partnerAddressStreetType', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressSuburbRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('suburb');

        } else {
            return this.get('partnerAddressSuburb');
        }

    }.property('partnerAddressSuburb', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressStateRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('state');

        } else {
            return this.get('partnerAddressState');
        }

    }.property('partnerAddressState', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerAddressPostcodeRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('postcode');

        } else {
            return this.get('partnerAddressPostcode');
        }

    }.property('partnerAddressPostcode', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerYearsRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return this.get('years');

        } else {
            return this.get('partnerYears');
        }

    }.property('partnerYears', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerMonthsRe: function () {

        if (!App.step1Data.get('isJoint')) {
            return null;

        } else if (this.get('partnerHasSameAddress')) {
            return parseInt(this.get('months'));

        } else {
            return parseInt(this.get('partnerMonths'));
        }

    }.property('partnerMonths', 'partnerHasSameAddress', 'App.step1Data.isJoint'),


    partnerPreviousAddressUnitNbRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressUnitNb');
        }

    }.property('partnerPreviousAddressUnitNb', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    partnerPreviousAddressStreetNbRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressStreetNb');
        }

    }.property('partnerPreviousAddressStreetNb', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    partnerPreviousAddressStreetRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressStreet');
        }

    }.property('partnerPreviousAddressStreet', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    partnerPreviousAddressStreetTypeRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressStreetType');
        }

    }.property('partnerPreviousAddressStreetType', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    partnerPreviousAddressSuburbRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressSuburb');
        }

    }.property('partnerPreviousAddressSuburb', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    partnerPreviousAddressStateRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressState');
        }

    }.property('partnerPreviousAddressState', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    partnerPreviousAddressPostcodeRe: function () {

        if (!App.step1Data.get('isJoint') || this.get('partnerHasSameAddress') || (this.getYearsInt(true) >= App.get('previousAddressTrigger'))) {
            return null;

        } else {
            return this.get('partnerPreviousAddressPostcode');
        }

    }.property('partnerPreviousAddressPostcode', 'partnerHasSameAddress', 'partnerYears', 'App.step1Data.isJoint'),


    /**
     * Methods
     */


    getYearsInt: function (partnerBool) {
        var field = partnerBool ? this.get('partnerYears') : this.get('years');
        return parseInt(field || 0);
    },


    getObject: function () {

        return {
            unitNb: this.get('unitNb'),
            streetNb: this.get('streetNb'),
            street: this.get('street'),
            streetType: this.get('streetType'),
            suburb: this.get('suburb'),
            state: this.get('state'),
            postcode: this.get('postcode'),
            country: this.get('country'),
            years: this.get('years'),
            months: this.get('months'),

            previousAddressUnitNb: this.get('previousAddressUnitNbRe'),
            previousAddressStreetNb: this.get('previousAddressStreetNbRe'),
            previousAddressStreet: this.get('previousAddressStreetRe'),
            previousAddressStreetType: this.get('previousAddressStreetTypeRe'),
            previousAddressSuburb: this.get('previousAddressSuburbRe'),
            previousAddressState: this.get('previousAddressStateRe'),
            previousAddressPostcode: this.get('previousAddressPostcodeRe'),
            previousAddressCountry: this.get('previousAddressCountry'),
            
            partnerCustomerNumber: this.get('partnerCustomerNumber'),
            partnerEmail: this.get('partnerEmailRe'),
            partnerEmailConfirm: this.get('partnerEmailConfirmRe'),
            partnerHomePhone: this.get('partnerHomePhoneRe'),
            partnerMobilePhone: this.get('partnerMobilePhoneRe'),
            partnerBirthDate: this.get('partnerBirthDateRe'),
            partnerHasSameAddress: this.get('partnerHasSameAddressRe'),
            partnerAddressUnitNb: this.get('partnerAddressUnitNbRe'),
            partnerAddressStreetNb: this.get('partnerAddressStreetNbRe'),
            partnerAddressStreet: this.get('partnerAddressStreetRe'),
            partnerAddressStreetType: this.get('partnerAddressStreetTypeRe'),
            partnerAddressSuburb: this.get('partnerAddressSuburbRe'),
            partnerAddressState: this.get('partnerAddressStateRe'),
            partnerAddressPostcode: this.get('partnerAddressPostcodeRe'),
            partnerAddressCountry: this.get('partnerAddressCountry'),
            partnerYears: this.get('partnerYearsRe'),
            partnerMonths: this.get('partnerMonthsRe'),
            partnerPreviousAddressUnitNb: this.get('partnerPreviousAddressUnitNbRe'),
            partnerPreviousAddressStreetNb: this.get('partnerPreviousAddressStreetNbRe'),
            partnerPreviousAddressStreet: this.get('partnerPreviousAddressStreetRe'),
            partnerPreviousAddressStreetType: this.get('partnerPreviousAddressStreetTypeRe'),
            partnerPreviousAddressSuburb: this.get('partnerPreviousAddressSuburbRe'),
            partnerPreviousAddressState: this.get('partnerPreviousAddressStateRe'),
            partnerPreviousAddressPostcode: this.get('partnerPreviousAddressPostcodeRe'),
            partnerPreviousAddressCountry: this.get('partnerPreviousAddressCountry')
        };

    }


});


App.step2Data = App.Step2Data.create();

