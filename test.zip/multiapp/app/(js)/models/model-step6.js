/*****************************************************************************
 * MODEL Step 6
 *****************************************************************************/


App.Step6Data = App.Model.extend({


    /**
     * Properties
     */


    provided:false, // Default value
    accepted:false, // Default value
    agreed:false, // Default
    agreeBellDirectTerms: false,
    userInput:null,
    captchErrorMessage:null,


    getObject:function () {

        return {
            provided:this.get('provided'),
            accepted:this.get('accepted'),
            agreed:this.get('agreed'),
            agreeBellDirectTerms: this.get('agreeBellDirectTerms'),
            userInput:this.get('userInput')
        };

    }



});


App.step6Data = App.Step6Data.create();