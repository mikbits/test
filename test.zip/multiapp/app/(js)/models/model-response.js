/*****************************************************************************
 * MODEL Response
 *****************************************************************************/


App.ResponseData = App.Model.extend({


    /**
     * Properties
     */

    title: null,
    firstName: null,
    lastName: null,
    email: null,
    partnerFirstName: null,
    partnerLastName: null,
    applicationId: null,

    applicantData:null,
    partnerData:null,

    /**
     * Pending ID
     */


    pendingId: null,
    partnerPendingId: null,


    /**
     * Approved
     */


    isJoint: null,
    bundle: null,
    d2dBsb: null,
    d2dAccountNb: null,
    mcBsb: null,
    mcAccountNb: null,
    ssBsb: null,
    ssAccountNb: null,
    fsBsb: null,
    fsAccountNb: null,
    ostBsb: null,
    ostAccountNb: null,
    bankingNb: null,
    partnerBankingNb: null,
    multicurrencyMain: null,
    otherCurrencies: [],
    ostStatus:null,
    ostUser: null,
    withoutDebitCard: false,


    /**
     * Self ID
     */


    selfIdData: null,

    isOstSuccess: function () {
        var result=false;
        if(this.get('ostStatus')==='Y'){
            result=true;
        }
        return result;
    }.property('ostStatus'),

    isOstError: function () {
        var result=false;
        if(this.get('ostStatus')==='E'){
            result=true;
        }
        return result;
    }.property('ostStatus'),

    isOstFailed: function () {
        var result=false;
        if(this.get('ostStatus')==='N'){
            result=true;
        }
        return result;
    }.property('ostStatus'),

    divideArrowClass: function(){
        var counter=0;
        if(this.get('d2dAccountNb')){
            counter=counter+1;
        }
        if(this.get('mcAccountNb')){
            counter=counter+1;
        }
        if(this.get('ssAccountNb')){
            counter=counter+1;
        }
        if(this.get('fsAccountNb')){
            counter=counter+1;
        }
        if(this.get('ostUser')){
            counter=counter+1;
        }
        return 'divide-arrow-multi'+counter;
    }.property('d2dAccountNb','mcAccountNb','ssAccountNb','fsAccountNb','ostUser')


});


App.responseData = App.ResponseData.create();