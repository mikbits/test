/*****************************************************************************
 * MODEL Step 1
 *****************************************************************************/


App.Step1Data = App.Model.extend({


    /**
     * Properties
     */


    // First applicant
    firstName: null,
    middleName: null,
    lastName: null,
    isCustomer: null,
    customerNumber: null,
    title: null,
    isJoint: null,
    withoutDebitCard: false,
    birthDate: null,
    email: null,
    homePhone: null,
    mobilePhone: null,
    emailConfirm: null,
    maidenName: null,
    agreesPolicy: false,

    // Multi currency
    multiCurrencyMain: null,
    otherCurrencies: [],

    // Serious saver
    isSaverLinkedToHsbc: null, // Default value

    // Online Share Trading
    tradingUsername: null,
    tradingUsernamePartner: null,

    // Second applicant
    partnerFirstName: null,
    partnerMiddleName: null,
    partnerLastName: null,
    partnerTitle: null,
    partnerWithoutDebitCard: false,

    /**
     * Computed properties for back end
     */

    isNotExistingCustomer: Ember.computed.equal('isCustomer', false),
    isNotExistingCustomerOrJoint: Ember.computed.or('isNotExistingCustomer', 'isJoint'),

    isCNYSelected: function(){
        var result=false;
        if(this.get('multiCurrencyMain') ==='CNY'){
            result=true;
        }else{
            if(this.get('otherCurrencies')){
                if($.inArray('CNY',this.get('otherCurrencies'))>-1){
                    result=true;
                }
            }
        }
        return result;
    }.property('multiCurrencyMain','otherCurrencies'),

    homePhoneRe: function () {
        var value = this.get('homePhone') ? this.get('homePhone') : '';
        return value.replace(/\-/g, '');
    }.property('homePhone'),


    mobilePhoneRe: function () {
        var value = this.get('mobilePhone') ? this.get('mobilePhone') : '';
        return value.replace(/\-/g, '');
    }.property('mobilePhone'),


    withoutDebitCardRe: function () {
        var withoutDebitCard=this.get('withoutDebitCard');
        if($.inArray('CMG',App.step5Data.get('accountTypesRe'))<0){
            withoutDebitCard = true;
        }
        return withoutDebitCard;
    }.property('withoutDebitCard', 'App.step5Data.accountTypesRe'),


    partnerTitleRe: function () {
        return !this.get('isJoint') ? null : this.get('partnerTitle');
    }.property('partnerTitle', 'isJoint'),


    partnerFirstNameRe: function () {
        return !this.get('isJoint') ? null : this.get('partnerFirstName');
    }.property('partnerFirstName', 'isJoint'),


    partnerMiddleNameRe: function () {
        return !this.get('isJoint') ? null : this.get('partnerMiddleName');
    }.property('partnerMiddleName', 'isJoint'),


    partnerLastNameRe: function () {
        return !this.get('isJoint') ? null : this.get('partnerLastName');
    }.property('partnerLastName', 'isJoint'),


    partnerWithoutDebitCardRe: function () {
        var partnerWithoutDebitCard=null;
        if(this.get('isJoint')){
            var partnerWithoutDebitCard=this.get('partnerWithoutDebitCard');
            if($.inArray('CMG',App.step5Data.get('accountTypesRe'))<0){
                partnerWithoutDebitCard = null;
            }
        }
        return partnerWithoutDebitCard;
    }.property('partnerWithoutDebitCard', 'isJoint', 'App.step5Data.accountTypesRe'),


    multiCurrencyMainRe: function () {
        return App.step5Data.get('multiCurrency') === false ? null : this.get('multiCurrencyMain');
    }.property('multiCurrencyMain', 'App.step5Data.multiCurrency'),


    otherCurrenciesRe: function () {
        return App.step5Data.get('multiCurrency') === false ? [] : this.get('otherCurrencies');
    }.property('otherCurrencies', 'App.step5Data.multiCurrency'),


    /**
     * Other computed properties
     */


    embossing: function () {
        return this.getEmbossing(this.get('firstName'), this.get('middleName'), this.get('lastName'));
    }.property('firstName', 'middleName', 'lastName'),


    partnerEmbossing: function () {
        return this.getEmbossing(this.get('partnerFirstName'), this.get('partnerMiddleName'), this.get('partnerLastName'));
    }.property('partnerFirstName', 'partnerMiddleName', 'partnerLastName'),


    /**
     * Methods
     */


    getEmbossing: function (fn, mn, ln) {
        var f = fn ? fn : '';
        var f0 = fn ? fn[0] : '';
        var m = mn ? mn : '';
        var m0 = mn ? mn[0] : '';
        var l = ln ? ln : '';
        var e0 = f + ' ' + m + ' ' + l;
        var e1 = f + ' ' + m0 + ' ' + l;
        var e2 = f + ' ' + l;
        var e3 = f0 + ' ' + l;
        var e4 = f0 + ' ' + l.substr(0, 17);

        if ((e0.length < 20) && m) {
            return e0;

        } else if (((e1.length < 20) && m)) {
            return e1;

        } else if (((e2.length < 20) && !m)) {
            return e2;

        } else if (e3.length < 20) {
            return e3;

        } else {
            return e4;
        }

    },


    getObject: function () {

        return {
            isCustomer: this.get('isCustomer'),
            customerNumber: this.get('customerNumber'),
            title: this.get('title'),
            firstName: this.get('firstName'),
            middleName: this.get('middleName'),
            lastName: this.get('lastName'),
            email: this.get('email'),
            emailConfirm: this.get('emailConfirm'),
            homePhone: this.get('homePhoneRe'),
            mobilePhone: this.get('mobilePhoneRe'),
            birthDate: this.get('birthDate'),
            maidenName: this.get('maidenName'),
            agreesPolicy: this.get('agreesPolicy'),
            withoutDebitCard: this.get('withoutDebitCardRe'),
            isJoint: this.get('isJoint'),
            partnerTitle: this.get('partnerTitleRe'),
            partnerFirstName: this.get('partnerFirstNameRe'),
            partnerMiddleName: this.get('partnerMiddleNameRe'),
            partnerLastName: this.get('partnerLastNameRe'),
            partnerWithoutDebitCard: this.get('partnerWithoutDebitCardRe'),
            multiCurrencyMain: this.get('multiCurrencyMainRe'),
            otherCurrencies: this.get('otherCurrenciesRe'),
            isSaverLinkedToHsbc: this.get('isSaverLinkedToHsbc'),
            tradingUsername: this.get('tradingUsername'),
            tradingUsernamePartner: this.get('tradingUsernamePartner')
        };

    },

    bundleChanged: function() {
        if(App.get('bundle')===2 || App.get('bundle')===7 || (App.get('bundle')===3 && !this.get('isSaverLinkedToHsbc'))){
            App.step1Data.set('withoutDebitCard',true);
            App.step1Data.set('partnerWithoutDebitCard',true);
        }
    }.observes('App.bundle')

});


App.step1Data = App.Step1Data.create();