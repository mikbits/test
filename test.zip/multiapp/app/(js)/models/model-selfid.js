/*****************************************************************************
 * MODEL Self ID
 *****************************************************************************/


App.SelfIdData = Ember.Object.extend({


    /**
     * Properties
     */

    applicantType: null,

    // First applicant
    title: null,
    firstName: null,
    lastName: null,
    licenceNeeded: null,
    medicareNeeded: null,
    passportNeeded: null,
    licenceProvided: null,
    passportProvided: null,

    ozLicenceSelected: null, // Checkbox boolean
    passportSelected: null, // Checkbox boolean
    medicareSelected: null, // Checkbox boolean
    licenceState: null,
    licenceExpiryDate: null,
    licenceNumber: null,
    licenceCardNumber: null,
    passportType:null,
    ozPassportCountryBirth: null,
    ozPassportPlaceBirth: null,
    ozPassportNameBirth: null,
    ozPassportNumber: null,
    intPassportCountry: null,
    intPassportNumber: null,

    medicareColor: null,
    medicareExpiryDate: null,
    medicareMiddleName: null,
    intPassportNumberChanged:function(){
        if(this.get('intPassportNumber')){
            this.set('passportType','INT')
        }
    }.observes('intPassportNumber'),

    passportProvidedChanged: function(){
        this.set('passportSelected',true)
    }.observes('passportProvided'),

    ozPassportNumberChanged:function(){
        if(this.get('ozPassportNumber')){
            this.set('passportType','AUS')
        }
    }.observes('ozPassportNumber'),


    licenceProvidedChanged: function(){
        this.set('ozLicenceSelected',true)
    }.observes('licenceProvided'),



    /**
     * Computed properties
     */

    isVicLicence: function(){
        return this.get('ozLicenceSelected') && this.get('licenceState') === 'VIC';

    }.property('ozLicenceSelected','licenceState'),

    licenceStateRe: function () {
        return this.get('licenceNeeded') ? this.get('licenceState') : null;
    }.property('licenceState', 'licenceNeeded'),


    licenceExpiryDateRe: function () {
        return this.get('licenceNeeded') ? this.get('licenceExpiryDate') : null;
    }.property('licenceExpiryDate', 'licenceNeeded'),


    licenceNumberRe: function () {
        return this.get('licenceNeeded') ? this.get('licenceNumber') : null;
    }.property('licenceNumber', 'licenceNeeded'),


    licenceCardNumberRe: function () {
        return this.get('licenceNeeded') ? this.get('licenceCardNumber') : null;
    }.property('licenceCardNumber', 'licenceNeeded'),


    ozPassportCountryBirthRe: function () {
        return this.get('passportNeeded') && (! this.get('intPassportCountry') === 'AUS') ? this.get('ozPassportCountryBirth') : null;
    }.property('ozPassportCountryBirth', 'passportNeeded'),


    ozPassportPlaceBirthRe: function () {
        return this.get('passportNeeded') && (! this.get('intPassportCountry') === 'AUS')  ? this.get('ozPassportPlaceBirth') : null;
    }.property('ozPassportPlaceBirth', 'passportNeeded'),


    ozPassportNameBirthRe: function () {
        return this.get('passportNeeded') && (! this.get('intPassportCountry') === 'AUS')  ? this.get('ozPassportNameBirth') : null;
    }.property('ozPassportNameBirth', 'passportNeeded'),


    ozPassportNumberRe: function () {
        return this.get('passportNeeded') && (! this.get('intPassportCountry') === 'AUS')  ? this.get('ozPassportNumber') : null;
    }.property('ozPassportNumber', 'passportNeeded'),


    intPassportCountryRe: function () {
        return this.get('passportNeeded') && (this.get('intPassportCountry') === 'AUS')  ? this.get('intPassportCountry') : null;
    }.property('intPassportCountry', 'passportNeeded'),


    intPassportNumberRe: function () {
        return this.get('passportNeeded') && (this.get('intPassportCountry') === 'AUS')  ? this.get('intPassportNumber') : null;
    }.property('intPassportNumber', 'passportNeeded'),

    medicareNumberRe: function () {
        return this.get('medicareSelected') ? this.get('medicareNumber') : null;
    }.property('medicareSelected', 'medicareNumber'),

    medicareRefNumberRe: function () {
        return this.get('medicareSelected') ? this.get('medicareRefNumber') : null;
    }.property('medicareRefNumber', 'medicareSelected'),


    /**
     * Methods
     */


    getObject: function () {

        return {
            applicantType: this.get('applicantType'),
            licenceState: this.get('licenceStateRe'),
            licenceExpiryDate: this.get('licenceExpiryDateRe'),
            licenceNumber: this.get('licenceNumberRe'),
            licenceCardNumber: this.get('licenceCardNumberRe'),
            medicareNumber: this.get('medicareNumberRe'),
            medicareRefNumber: this.get('medicareRefNumberRe'),
            medicareColor: this.get('medicareColor'),
            medicareMiddleName: this.get('medicareMiddleName'),
            medicareExpiryDate: this.get('medicareExpiryDate'),
            ozPassportCountryBirth: this.get('ozPassportCountryBirthRe'),
            ozPassportPlaceBirth: this.get('ozPassportPlaceBirthRe'),
            ozPassportNameBirth: this.get('ozPassportNameBirthRe'),
            ozPassportNumber: this.get('ozPassportNumberRe'),
            intPassportCountry: this.get('intPassportCountryRe'),
            intPassportNumber: this.get('intPassportNumberRe')
        };

    }

});


App.selfIdData = App.SelfIdData.create();