/*****************************************************************************
 * MODEL Ramp
 *****************************************************************************/
 
 
App.RampData = App.Model.extend({


    /**
     * Properties
     */


    hubId: null,
    branch: null,
    bundle: null


});


App.rampData = App.RampData.create();