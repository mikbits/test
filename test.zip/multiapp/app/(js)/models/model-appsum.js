/*****************************************************************************
 * MODEL Application summary
 *****************************************************************************/


App.AppSumData = Ember.Object.extend(App.BundleLogic, {


    /**
     * Properties
     */


    applicationId: null,
    lastUpdateDate: null,
    status: null,
    bundle: null,


    /**
     * Computed properties
     */


    accounts: function () {
        var acc = '';
        var bundle=this.get('bundle');
        if (this.hasDtd(bundle)) {
            acc += 'Day to Day<br>';
        }

        if (this.hasMultiCurrency(bundle)) {
            acc += 'Multi Currency<br>';
        }

        if (this.hasSeriousSaver(bundle)) {
            acc += 'Serious Saver<br>';
        }

        if (this.hasFlexiSaver(bundle)) {
            acc += 'Flexisaver<br>';
        }

        if (this.hasOnlineTrading(bundle)) {
            acc += 'Online Share Trading<br>';
        }
		// Post implementation fix		
		if(acc == ''){
			acc += this.productName;
        	acc += '<br/>';
		}
		
        return acc;
    }.property('bundle')


});