AppC.JsonDtdSaveController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'crdCrossSellSave',
            dtdCrossSellStep: AppC.dtdAccountData.getObject()
        });

        this.postRequest(this);
    },


    successBack: function (response) {

        AppC.setReady();
        var status = response.responseStatus;

        switch (status) {

            case 'success':
                AppC.set('isDtdDirty', false);
                AppC.set('applicationId',this.getApplicationId(response));
                break;

            case 'emailFailed':
                AppC.set('applicationId',this.getApplicationId(response));
                AppC.ux.openModal('emailFailedInfo');
                break;

            default:
                this.handleException(response);
                break;

        }

    }

});
