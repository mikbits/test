

AppC.JsonDtdSubmitController = AppC.JsonActionController.extend({


    /**
     * Methods
     */

    submitting: false,

    run: function () {

        this.set('args', {
            cmd: 'crdCrossSellSubmit',
            dtdCrossSellStep: AppC.dtdAccountData.getSubmitObj()
        });

        AppC.setBusy();
        AppC.set('isBusy', false); // Just for pretty UI (step6 is still showing when waiting for answer)
        this.postRequest(this);
    },


    successBack: function (response) {
        // clear submitting flag
        this.set('submitting',false);
		
		if(['selfID', 'pendingId', 'actionstep', 'processing','denial', 'idCheckReq', 'incomeCheckReq','onlineCalUs','approved','noInstDescision','incomeAddrCheckReq','denied'].indexOf(response.responseStatus)>-1){ 
            webTrendTagResultPageStart($.makeArray('CMG'));
            callDynamicFloodLight(AppC.applicationId, $.makeArray(AppC.logo), $.makeArray('CMG'));
        } 
            
        if (this.isSuccess(response) || response.responseStatus == 'approved') {

            AppC.dtdAccountData.set('applicantData', response.approvalData);

            AppC.set('applicationId',response.applicationId);
            this.goRoute('dtdAccount.approved');
            AppC.responseData.setProperties(response.approvalData);


            //return;
        } else {
        	
        	if (response.responseStatus == 'error' || response.responseStatus == 'expired' || response.responseStatus == 'selfId' || response.responseStatus == 'pendingId') {
                response.responseStatus = 'dtdProcessing';
            }
        	
            this.handleException(response);
        }

        AppC.setReady();
    }


});
