/*****************************************************************************
 * JSON ACTION GetServerDate
 *****************************************************************************/


AppC.JsonGetServerDateController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run:function () {

        this.set('args', {
            cmd:'getServerDate'
        });

        this.postRequest(this);
    },


    successBack:function (response) {

        if (this.isSuccess(response)) {
            AppC.validationController.set('serverDate', response.serverDate);
        } else {
            this.handleException(response);
        }
    }


});
