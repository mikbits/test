/*****************************************************************************
 * JSON ACTION Class
 *****************************************************************************/


AppC.JsonActionController = AppC.JsonApiController.extend(AppC.Nav, {

    /**
     * Properties
     */

    args: {},


    /**
     * Methods to be implemented by instances
     */


    run: function () {
    },
    successBack: function (response) {
    },


    /**
     * Methods to read Ajax response
     */


    isSuccess: function (response) {
        return response.responseStatus === 'success';
    },

    isEmailFailed: function(response) {
        return response.responseStatus === 'emailFailed';
    },

    isCreditCard: function (response) {
        return response.cardType === 'card';
    },

    getErrorCode: function (response) {
        return response.errorCode;
    },

    getApplicationId: function (response) {
        return response.applicationId;
    },


    getBundle: function (response) {
        return response.bundle;
    },


    getCommand: function (response) {
        return response.cmd;
    },


    getStep: function (response, step) {
        switch (step) {

            case 1:
                return response.step1;
                break;

            case 2:
                return response.step2;
                break;

            case 3:
                return response.step3;
                break;

            case 4:
                return response.step4;
                break;

            case 5:
                return response.step5;
                break;

            default:
                return null;

        }
    },

    initialResponseData: function (response) {
        AppC.responseData.setProperties(response.applicantData);
        AppC.responseData.set('applicantData', response.applicantData);
        AppC.responseData.set('productData', response.productData);
		AppC.responseData.set('purchaseData', response.purchaseData);
		AppC.responseData.set('redirectURL', response.redirectURL);
    },

    getResponsePageData: function (response) {
        return response.approvalData;
    },

    getResponseIdData: function (response) {
        return response.selfIdData;
    },

    getApplicationsData: function (response) {
        return response.applications;
    },

    /**
     * Other methods
     */


    failBack: function () {
        AppC.setReady();
        this.goRoute('errorAjax');
    },


    handleException: function (response) {
        AppC.responseData.set('applicationId', this.getApplicationId(response));
        AppC.responseData.set('errorCode',response.errorCode);

        var isApproved = Em.get(response, 'contractAccepted');
        if (isApproved) {
        	AppC.set('contractAccepted', isApproved);
        }
        

        var status = String(response.responseStatus);
        var index;

        if((index = status.indexOf('RA')) != -1){
            AppC.set('isInRa', true);
            status = status.slice(0, index);

        } else if (index = status.indexOf('Direct') != -1){
            AppC.set('isInRa', false);
            status = status.slice(0, index);
        }

        switch (status) {

            case 'notFound':
                AppC.retrieveData.set('notFound', true);
                break;

            case 'expired':
                this.goRouteAndReset('timeout');
                break;

            case 'sessionNotFound':

                if (AppC.get('isStep1') === false) {
                    this.goRouteAndReset('retrieve');
                }

                break;

            case 'error':
                this.goRouteAndReset('error');
                AppC.set('applicationId', response.applicationId);
                this.initialResponseData(response);
                break;
                
            case 'onlineCalUsQ':
            case 'processing':
                this.goRouteAndReset('processing');
                AppC.set('applicationId',response.applicationId);
                AppC.set('bundle',response.bundle);
                AppC.set('accountTypes',response.accountTypes);
                this.initialResponseData(response);
                AppC.set('outcomeStatus', status);
                break;
                
			case 'dtdProcessing':
                this.goRoute('processing');
                AppC.set('applicationId',response.applicationId);
                AppC.set('bundle',response.bundle);
                AppC.set('accountTypes',response.accountTypes);
                this.initialResponseData(response);
                break;
                
            case 'approved':
                this.goRoute('approved');
                AppC.set('applicationId', response.applicationId);
                this.initialResponseData(response);
                break;

            case 'noInstDescision':
                this.goRouteAndReset('processing');
                AppC.set('applicationId',response.applicationId);
                AppC.set('outcomeStatus', status);
                this.initialResponseData(response);
                break;

            
            
            case 'denied':

                this.goRouteAndReset('denial');
                AppC.set('applicationId',response.applicationId);
                this.initialResponseData(response);
                break;

            case 'idCheckReq':
                this.goRouteAndReset(status);
                AppC.set('applicationId',response.applicationId);
                this.initialResponseData(response);
                break;
            
            case 'incomeCheckReq':
            case 'idIncomeCheckReq':
            case 'incomeAddrCheckReq':
                this.goRouteAndReset('actionstep');
                AppC.set('applicationId',response.applicationId);
                AppC.set('outcomeStatus', status);
                this.initialResponseData(response);
                break;


            case 'pendingId':
                this.goRouteAndReset('pendingId');
                AppC.set('applicationId',response.applicationId);
                break;

            case 'selfId':
                AppC.set('applicationId',response.applicationId);
                var selfIdData = response.selfIdData;
                var applicantData = response.applicantData;

                this.goRoute('selfId');
                AppC.selfIdData.setProperties(selfIdData);
                AppC.selfIdData.setProperties(applicantData);
                break;


            case 'multi':
                this.goRoute('chooseApp');
                AppC.appSums = AppC.AppSums.create();
                var array = this.getApplicationsData(response);

                array.forEach(function (item) {
                    AppC.appSums.addObject(item);
                });

                break;

            case 'notMatch':
                AppC.set('applicationId',response.applicationId);
                AppC.step6Data.set('captchErrorMessage','Your input does not match, please try again.');
                AppC.submitToken.refreshSubmitToken();
                break;

            case 'tradingUserNameInvalid':
                var target=$("input[em-field=tradingUsername]");
                var emberId1=target.attr('id');
                var msg="user name not available";
                var asideClass=target.attr('em-aside');
                var isBypassed = target.parents('div.blockToggle').hasClass('destroyed');
                this.get('controllers.step1Bundle4').addError(isBypassed, emberId1, msg, asideClass);
                AppC.set('hasSavedStep1', false);
                AppC.setReady();
                AppC.ux.scrollFirstError();
                break;

            case 'onlineCalUs':
                this.goRouteAndReset('onlineCalUs');
                AppC.set('applicationId',response.applicationId);
                this.initialResponseData(response);
                AppC.set('outcomeStatus', status);
                break;

            case 'maintenance':
                this.goRouteAndReset('maintenance');
                AppC.set('applicationId',response.applicationId);
                AppC.responseData.set('maintenanceFinishHoursMinutes', response.maintenanceFinishHoursMinutes);
                break;

        }

    },


    getString: function () {
        return JSON.stringify(this.get('args'));
    },


    loadSteps: function (response) {


    	var isApproved = Em.get(response, 'contractAccepted');
        if (isApproved) {
        	AppC.set('contractAccepted', isApproved);
        }


    	var currentStep = response.currentStep;
        for (var i = 1; i <= 5; i++) {

            var stepData = this.getStep(response, i);

            if (stepData) {
            	if(i<=currentStep){
	                AppC.set("hasSavedStep" + i, true);
	                AppC.set("isStep" + i + "Dirty", false);
            	}
                switch (i) {
                    case 1:
                        AppC.step1Data.setProperties(stepData);
                        if (stepData.cardColour) {
                            AppC.step1Data.set('isBlack', false);
                            AppC.step1Data.set('isBlue', false);
                            AppC.step1Data.set('isPink', false);
                            AppC.step1Data.set('isGreen', false);
                            switch (stepData.cardColour) {
                                case '0001':
                                AppC.step1Data.set('isBlack', true);
                                break;
                                case '0002':
                                AppC.step1Data.set('isGreen', true);
                                break;
                                case '0003':
                                AppC.step1Data.set('isBlue', true);
                                break;
                                case '0004':
                                AppC.step1Data.set('isPink', true);
                                break;
                            }
                        }
                        break;

                    case 2:
                        AppC.step2Data.setProperties(stepData);
						if(currentStep<2){
							if(AppC.step2Data.combCreditLmt==0){
								AppC.step2Data.combCreditLmt=null;
							}
							if(AppC.step2Data.numOfCards==0){
								AppC.step2Data.numOfCards=null;
							}
							if(AppC.step2Data.totalBalOwing==0){
								AppC.step2Data.totalBalOwing=null;
							}
							if(AppC.step2Data.balanceTransfer==false){
								AppC.step2Data.balanceTransfer=null;
							}
						}
                        break;

                    case 3:
                        AppC.step3Data.setProperties(stepData);
						if(currentStep<3){
							if(AppC.step3Data.numOfDependants==0){
								AppC.step3Data.numOfDependants=null;
							}
							//alert(AppC.step3Data.isResident);
							if(AppC.step3Data.isResident==false){
								AppC.step3Data.isResident=null;
							}
						}
                        break;

                    case 4:
                        var step4 = AppC.step4Data;
                        step4.setProperties(stepData);

                        if (step4.get('street')){
                            step4.set('addr1Validated', true);
                        }

                        if (step4.get('employerAddressStreet')){
                        	if(step4.get('employmentStatus')=='S'){
                        		step4.set('addr3Validated', true);
                        		step4.set('selfEmployerAddressUnitNb',step4.get('employerAddressUnitNb'));
                        		step4.set('selfEmployerAddressStreetNb',step4.get('employerAddressStreetNb'));
                        		step4.set('selfEmployerAddressStreet',step4.get('employerAddressStreet'));
                        		step4.set('selfEmployerAddressStreetType',step4.get('employerAddressStreetType'));
                        		step4.set('selfEmployerAddressSuburb',step4.get('employerAddressSuburb'));
                        		step4.set('selfEmployerAddressState',step4.get('employerAddressState'));
                        		step4.set('selfEmployerAddressPostcode',step4.get('employerAddressPostcode'));
                        	}else{
                        		step4.set('addr2Validated', true);
                        	}
                        }

                        if (step4.get('previousAddressStreet')){
                            step4.set('addr5Validated', true);
                        }

                        break;

                    case 5:
                        var step5 = AppC.step5Data;
                        step5.setProperties(stepData);

                        if (step5.get('partnerAddressStreet')){
                            step5.set('addr4Validated', true);
                        }

						if(currentStep<5){
							if(AppC.step5Data.salaryWtTax==0){
								AppC.step5Data.salaryWtTax=null;
							}
							if(AppC.step5Data.incomeWtTax==0){
								AppC.step5Data.incomeWtTax=null;
							}
							if(AppC.step5Data.partnerIncomeWtTax==0){
								AppC.step5Data.partnerIncomeWtTax=null;
							}
							if(AppC.step5Data.incomeGross==0){
								AppC.step5Data.incomeGross=null;
							}
							if(AppC.step5Data.isLimited==false){
								AppC.step5Data.isLimited=null;
							}
							if(AppC.step5Data.limitDesired==0){
								AppC.step5Data.limitDesired=null;
							}
							if(AppC.step5Data.isJoint==false){
								AppC.step5Data.isJoint=null;
							}
							if(AppC.step5Data.partnerCustRewardInd==false){
								AppC.step5Data.partnerCustRewardInd=null;
							}
							if(AppC.step5Data.partnerHasSameAddress==true){
								AppC.step5Data.partnerHasSameAddress=null;
							}
						}

                        break;

                }
            }
        }
        AppC.set('merchantGroupId',response.merchantGroupId);
        AppC.set('merchantStoreId',response.merchantStoreId);
		AppC.set('applicationId', this.getApplicationId(response));
        AppC.set('bundle', this.getBundle(response));
        // rerender for response 'existing' when cmd 'save'
        // comment out because it causes problem when user retrieve
        // AppC.toggleProperty('renderSwitch');
    },

    loadHubData: function(resp, hubData) {
 		

    	var _data = Em.Object.create(hubData);

    	HSBC.SITE.cam = _data.get('userDetails.camLevel');

    	var address = "%@ %@ %@ %@".fmt(
            _data.get('userDetails.homeAddress2') || '',
            _data.get('userDetails.homeAddress3') || '',
            _data.get('userDetails.homeAddress4') || '',
            //_data.get('userDetails.homeAddress5') || '',
            _data.get('userDetails.postalPostcode') || ''
        );

        address = $.trim(address);

        var mobile = "0%@".fmt(_data.get('userDetails.mobilePhone').slice(-9));
        mobile = "%@-%@-%@".fmt(mobile.substr(0,4), mobile.substr(4,3), mobile.substr(7,3));

        var homePhone = "0%@".fmt(_data.get('userDetails.homePhone').slice(-9));
        homePhone = "%@-%@-%@".fmt(homePhone.substr(0,2), homePhone.substr(2,4), homePhone.substr(6,4));

        var title = _data.get('userDetails.title');

        $.extend(true, resp, {
            step1: {
                email: _data.get('userDetails.email'),
                title: title,
                firstName: _data.get('userDetails.firstName'),
                middleName: _data.get('userDetails.middleName'),
                lastName: _data.get('userDetails.lastName'),
                emailConfirm: _data.get('userDetails.email'),
                birthDate: _data.get('userDetails.dateOfBirth'),
                mobilePhone: mobile,
                homePhone: homePhone,
            },
            step3: {
                gender: _data.get('userDetails.gender')
            },
            step4: {
                employerName: _data.get('userDetails.employer'),
                job: _data.get('userDetails.jobTitle'),
                occupation: _data.get('userDetails.occupation'),
                geoCoder1: address
            }
        });



        var photoId = null;

        if (_data.get('userDetails.idType') == 'D') {
            photoId = 'DL';
            $.extend(true, resp, {
                step3: {
                    photoId: photoId,
                    licenceNumber: _data.get('userDetails.idNumber')
                }
            });
        } else if (_data.get('userDetails.idType') == 'P') {

            $.extend(true, resp, {
                step3: {
                	photoId: null,
                    ozPassportNumber: _data.get('userDetails.idNumber'),
                    intPassportNumber: _data.get('userDetails.idNumber')
                }
            });
        }

        if (_data.get('userDetails.customerNumber')) {
            $.extend(true, resp, {
                step2: {
                	isSso: true,
                    isCustomer: true,
                    existingCustomerNo: _data.get('userDetails.customerNumber')
                }
            });
        }

        AppC.dtdAccountData.setProperties({
            tfn: _data.get('userDetails.customerNumber'),
            hasMultipleNat: _data.get('userDetails.multipleNationality'),
            nationality2: _data.get('userDetails.nationality2'),
            nationality3: _data.get('userDetails.nationality3')
        });

        // Using VEDA to repopulate address if address wasn't available.
        if (false && AppC.get('vedaResponse.ajaxStatus') && Em.isEmpty(Em.get(resp, 'step3.state'))) {

            

            return AppC.vedaSend({
                address: address
            }, 'ValidateAddress').then(function(response) {
                if (response.Result) {
                    var result = response.Result;
                    var array = result.Street ? result.Street.split(' ') : null;
                    var street = array ? array[0] : '';
                    var streetType = array ? array[array.length - 1].toUpperCase() : '';

                    if (array) {
                        for (var i = 1; i < array.length - 1; i++) {
                            street = street + ' ' + array[i];
                        }
                    }

                    if (streetType) {
                        if (!AppC.streetTypes.findProperty('code', streetType)) {
                            streetType = "";
                        }
                    }

                    $.extend(true, resp, {
                        step4: {
                            unitNb: result.Unit,
                            streetNb: result.StreetNumber,
                            street: street,
                            streetType: streetType,
                            suburb: result.Suburb,
                            state: result.State,
                            postcode: result.Postcode
                        }
                    });

                    return resp;
                }
            });
        } else {
            return new Ember.RSVP.Promise(function(resolve, reject) {
                resolve(resp);
            });
        }
    }


});
