/*****************************************************************************
 * JSON ACTION Submit IDs
 *****************************************************************************/


AppC.JsonSubmitIdsController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'crdSubmitIds',
            selfIdData: AppC.selfIdData.getselfIdData(),
            applicantData: AppC.selfIdData.getapplicantData(),
            applicantType: AppC.selfIdData.getapplicantType()
        });

        AppC.setBusy();
        AppC.set('isBusy', false); // Just for pretty UI (page is still showing when waiting for answer)
        this.postRequest(this);
    },


    successBack: function (response) {
        this.handleException(response);
        AppC.setReady();
    }


});
