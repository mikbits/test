/*****************************************************************************
 * JSON ACTION Entry
 *****************************************************************************/


AppC.JsonEntryController = AppC.JsonActionController.extend(AppC.Nav, {


    /**
     * Methods
     */


    run:function () {

        this.set('args', {
            cmd:'entry'
        });

        AppC.setBusy();
        this.postRequest(this);
    },


    successBack:function (response) {
        var _this = this;

        if (this.isSuccess(response)) {

            AppC.set('productCode', response.productCode);
            AppC.set('organizationCode', response.organizationCode);
            AppC.set('productName', response.productName);
            AppC.set('merchantGroupId', response.merchantGroupId);
            AppC.set('logo', response.logo);
            //AppC.set('contractAccepted', response.contractAccepted);

            AppC.set('loanRate', response.loanRate);
            AppC.set('loanAmt', response.loanAmt);
            AppC.set('loanPurpose', response.loanPurpose);
            AppC.set('loanOtherPurpose', response.loanOtherPurpose);
            AppC.set('loanTerm', response.loanTerm);
            AppC.set('repaymentAdjust', response.repaymentAdjust);

            AppC.set('incomeRe', response.incomeRe);
            AppC.set('minCredit', response.minCredit);
            AppC.set('maxCredit', response.maxCredit);
            AppC.set('annualFee', response.annualFee);
            AppC.set('marketCell', response.marketCell);

            AppC.set('isSso', response.isSso);
            
            AppC.set('marketCode', response.marketCode);

            AppC.set('merchantName', response.merchantName);
            if(response.interestFreeTerms){
            	AppC.set('interestFreeTerms', parseInt(response.interestFreeTerms));
            }
            if(response.deferredTerms){
            	AppC.set('deferredTerms',parseInt(response.deferredTerms));
            }

            if (response.merchantList) {
                AppC.retail.set("content", response.merchantList);
                AppC.retail.set("sentByEntry", true);
            }

            if (response.branchList) {
                AppC.branches.set("content", response.branchList);
                AppC.branches.set("sentByEntry", true);
            }

            if (response.isSso) {

                _this.post({
                    cmd: 'retrieveUserDetails'
                }).then(function(response) {
                    AppC.set('hubData', response);
                    _this.loadHubData(response, AppC.get('hubData')).then(function(response) {
                        _this.loadSteps(response);
                        AppC.set('refresh', false);
                    });
                    return response;
                });

            }

            this.initStep1();

        } else {
            this.handleException(response);
        }

        AppC.setReady();

    }


});

