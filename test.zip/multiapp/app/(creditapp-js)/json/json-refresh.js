/*****************************************************************************
 * JSON ACTION Refresh
 *****************************************************************************/


AppC.JsonRefreshController = AppC.JsonActionController.extend({

    needs: ['jsonEntry'],

    /**
     * Methods
     */


    run:function () {

        this.set('args', {
            cmd:'refresh'
        });

        AppC.setBusy();
        this.postRequest(this);
    },


    successBack:function (response) {
        var _this = this;
        if (this.isSuccess(response)) {

            var isInternetBanking = AppC.get('isSso');
            if (isInternetBanking) {
                this.loadHubData(response, AppC.get('hubData')).then(function(response) {
                    _this.loadSteps(response);
                    AppC.set('refresh', false);
                    AppC.toggleProperty('renderSwitch');
                }, function(e) {
                    _this.loadSteps(response);
                    AppC.set('refresh', false);
                    AppC.toggleProperty('renderSwitch');
                });

            } else {
                this.loadSteps(response);
                AppC.set('refresh', false);
                AppC.toggleProperty('renderSwitch');
            }

        } else {
            this.handleException(response);
        }

        // if already initialized, no need to send
        if (!AppC.productName) {
            this.get('controllers.jsonEntry').run();
        } else {
            AppC.setReady();
        }

    }


});
