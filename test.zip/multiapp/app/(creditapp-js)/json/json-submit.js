/*****************************************************************************
 * JSON Submit
 *****************************************************************************/


AppC.JsonSubmitController = AppC.JsonActionController.extend({

    /**
     * Methods
     */

    submitting: null,

    run: function () {

        this.set('args', {
            cmd: 'crdSubmit',
            token: AppC.submitToken.get('token'),
            step6: AppC.step6Data.getObject()
        });

        AppC.setBusy();
        AppC.set('refresh', false);
        AppC.set('isBusy', false); // Just for pretty UI (step6 is still showing when waiting for answer)
        this.postRequest(this);
    },


    successBack: function (response) {
    	    	
        // clear submitting flag
        this.set('submitting',false);

        if( 'error' === response.responseStatus && 'FE0001' === response.errorCode){
            AppC.setReady();
            var _this = this;
            $('div#validationError').modal({
                focus: false, 
                closeHTML: '<a class="modalCloseImg"></a>',
                onClose: function (dialog) {
                    $.modal.close(); 
                    _this.validateStep(1, 6);
                }
            });
        } else {

            if (response.responseStatus == 'error' || response.responseStatus == 'expired') {
                response.responseStatus = 'processing';
            }
            
            // handle DFA Tag
            var status = response.responseStatus;

    		var cdmId = null;
    		if (response.applicantData) {
    			cdmId = response.applicantData.cdmId; 
    		}
    		
            if(['selfID', 'pendingId', 'actionstep', 'processing','denial', 'idCheckReq', 'incomeCheckReq','onlineCalUs','approved','noInstDescision','incomeAddrCheckReq','denied'].indexOf(status)>-1){
            	livePersonTagOnSubmitClickStart(AppC.applicationId, response.productData, $.makeArray(AppC.logo));
                webTrendTagResultPageStart($.makeArray(AppC.logo));
                callDynamicFloodLight(AppC.applicationId, $.makeArray(AppC.logo), $.makeArray(''), cdmId);
            }



            this.handleException(response);
        }
        AppC.setReady();
    }


});
