
/*****************************************************************************
 * JSON ACTION Retrieve
 *****************************************************************************/


AppC.JsonRetrieveController = AppC.JsonActionController.extend({

    needs: ['jsonEntry'],

    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'retrieve',

            option1: AppC.retrieveData.get('option') === 1 ? {
                birthDate: AppC.retrieveData.get('birthDate1'),
                applicationId: AppC.retrieveData.get('applicationId').toUpperCase()
            } : null,

            option2: AppC.retrieveData.get('option') === 2 ? {
                birthDate: AppC.retrieveData.get('birthDate2'),
                email: AppC.retrieveData.get('email'),
                maidenName: AppC.retrieveData.get('maidenName')
            } : null

        });

        AppC.setBusy();
        AppC.set('isBusy', false); // Just for pretty UI (the retrieve page is still showing when loading)
        this.postRequest(this);
    },


    successBack: function (response) {
    	
    	AppC.set('logo', response.logo);
    	AppC.set('contractAccepted', response.contractAccepted);
    	var
        prefix = './images/',
        pathName = '',
        i;
    	switch (AppC.get('productCode')) {

        // HSBC Credit Card
        case 'H':
        i = 0;
        break;

        // HSBC Platinum Credit Card
        case 'P':
        i = 2;
        break;

        // HSBC Platinum Qantas Credit Card
        case 'Q':
        i = 3;
        break;

        // HSBC Premier World Mastercard
        case 'M':
        case 'N':
        i = 6;
        break;

        // HSBC Personal Loans
        case 'W':
        i = 7;
        break;

        // HSBC VISA CLASSIC ALLIANCE
        case 'Y':
        i = 8;
        break;
        
        // HSBC Classic Credit Card
        default:
        case 'V':
        case 'S':
        case 'T':
        i = 1;
        break;        
    }

    AppC.set("bundle", i);

    pathName = (function () {

        switch (i) {

            case 0:
            case 1:
            case 8:
            return prefix + 'card_hsbc_credit_card.png';

            case 2:
            return prefix + 'card_hsbc_platinum_black.png';

            case 3:
            return prefix + 'card_hsbc_qff_platinum.png';

            case 4:
            return prefix + 'cardBlack.png';

            case 5:
            return prefix + 'cardSilver.png';

            case 6:
            return prefix + 'card_hsbc_premier.png'

            default:
            return '';

        }

    }());

    AppC.set('imgFileName', pathName);
    
        if (this.isSuccess(response)) {

            if (!response.bundle  || response.bundle>10) {
                this.loadSteps(response);
                this.get('controllers.jsonEntry').run();
                this.send('goToStep', AppC.getLastSavedStep());
            } else {
                // change to multiapp cross retrieve url later
                window.location.href = '/multiapp/#/crxRetrieve';
            }

        } else {
        	if (!response.bundle  || response.bundle>10 || response.responseStatus=='multi') {
        		this.handleException(response);
            } else {
                // change to multiapp cross retrieve url later
                window.location.href = '/multiapp/#/crxRetrieve';
            }
            
        }

        AppC.setReady();
    }


});
