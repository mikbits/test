/*****************************************************************************
 * JSON ACTION Retrieve
 *****************************************************************************/


AppC.JsonCaptchaRenewController = AppC.JsonActionController.extend({

    needs:['step6'],


    /**
     * Methods
     */
    run: function () {

        this.set('args', {
            cmd: 'captchaRenew',
            type: AppC.config.get('captchaType')
        });

        this.postRequest(this);
    },


    successBack: function (response) {

        if (this.isSuccess(response)) {
            this.get('controllers.step6').setCaptchaLoadedTrue();
            this.get('controllers.step6').refreshCaptchaUrl();
        }
    }

});
