/*****************************************************************************
 * JSON Save
 *****************************************************************************/


AppC.JsonSaveController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'crdSave',
            bundle: AppC.get('bundle'),
            step1: AppC.get('hasSavedStep1') ? AppC.step1Data.getObject() : null,
            step2: AppC.get('hasSavedStep2') ? AppC.step2Data.getObject() : null,
            step3: AppC.get('hasSavedStep3') ? AppC.step3Data.getObject() : null,
            step4: AppC.get('hasSavedStep4') ? AppC.step4Data.getObject() : null,
            step5: AppC.get('hasSavedStep5') ? AppC.step5Data.getObject() : null
        });

        this.postRequest(this);
    },


    successBack: function (response) {

        AppC.setReady();
        var status = response.responseStatus;
        var currentStep=AppC.getCurrentStep();
        if(currentStep === 1) {
            AppC.nothingDirtyUntil(currentStep);
            this.send('goToStep', 2);
        }

        switch (status) {
            case 'success':
                AppC.set('applicationId',this.getApplicationId(response));
                break;

            case 'emailFailed':
                AppC.set('applicationId',this.getApplicationId(response));
                AppC.ux.openModal('emailFailedInfo');
                break;

            case 'existing':
                AppC.set('applicationId',this.getApplicationId(response));
                this.loadSteps(response);
                AppC.toggleProperty('renderSwitch');
                AppC.ux.openModal('existingAppInfo');
                break;
            case 'error':
            	if('FE0001' === response.errorCode){
            		var _this = this;
            		var lastSavedStep= AppC.getLastSavedStep();
            		$('div#validationError').modal({
            			focus: false, 
            			closeHTML: '<a class="modalCloseImg"></a>',
            			onClose: function (dialog) {
            				$.modal.close(); 
            				_this.validateStep(1, lastSavedStep);
            			}
            		});
            	}else{
                    this.handleException(response);            		
            	}
                break;
            default:
                this.handleException(response);
                break;
        }

    }

});


