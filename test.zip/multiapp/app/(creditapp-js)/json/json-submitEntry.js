/*****************************************************************************
 * JSON ACTION Submit RAMP step 0
 *****************************************************************************/


AppC.JsonSubmitEntryController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'branchEntry',
            estimatedFinanceAmount: AppC.entryData.get('estimatedFinanceAmount'),
            customerAtMerchantStore: AppC.entryData.get('customerAtMerchantStore'),
            staffId: AppC.entryData.get('staffId'),
            storeId: AppC.entryData.get('storeId'),
            branchId: AppC.entryData.get('branchId')
        });

        this.postRequest(this);
    },


    successBack: function (response) {
        this.handleException(response);
    }


});
