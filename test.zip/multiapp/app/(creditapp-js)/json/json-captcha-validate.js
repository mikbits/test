/*****************************************************************************
 * JSON ACTION Retrieve
 *****************************************************************************/


AppC.JsonCaptchaValidateController = AppC.JsonActionController.extend({


    /**
     * Methods
     */
    run: function () {

        this.set('args', {
            cmd: 'captchaValidate',
            type: AppC.config.get('captchaType'),
            userInput:AppC.step6Data.get('userInput')
        });

        this.postRequest(this);
    },

    isNotMatch: function (response) {
        return response.responseStatus === 'notMatch';
    },

    successBack: function (response) {

        if (this.isSuccess(response)) {
        	AppC.step6Data.set('captchErrorMessage','Great! Your input matches the Captcha image.');
        } else if(this.isNotMatch(response)){
            AppC.step6Data.set('captchErrorMessage','Your input does not match, please try again.');
        } else {
        	AppC.step6Data.set('captchErrorMessage','Technical error.');
        }
    }

});
