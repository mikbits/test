/*****************************************************************************
 * JSON API
 *****************************************************************************/


AppC.JsonApiController = Ember.Controller.extend({
    /**
     * Methods
     */


    postRequest: function (jsonAction) {

        $.ajax({
            url: AppC.config.get('jsonApiUrl'),
            type: 'post',
            context: this,
            contentType: 'application/json', // Type of data sent to server
            data: jsonAction.getString(), // data sent to server, must be string
            dataType: 'json', // Type of response received from server
            timeout: AppC.get('jsonTimeOut'),

            success: function (response) {
                jsonAction.successBack(response);
            },

            error: function (jqXHR, textStatus, errorThrown) {
                if (errorThrown) jsonAction.failBack();
            }

        });

    },

    post: function(data) {
        
        var _this = this;
        var promise = new Ember.RSVP.Promise(function(resolve, reject) {

            $.ajax({
                url: AppC.config.get('jsonApiUrl'),
                type: 'post',
                contentType: 'application/json; charset=utf-8', // Type of data sent to server
                data: JSON.stringify(data),
                dataType: 'json',
                timeout: AppC.get('jsonTimeOut'),

                success: function(data) {
                    resolve(data);
                },

                error: function(jqXHR, status, error) {
                    reject(error);
                }
            });
        });

        return promise;
    }


});
