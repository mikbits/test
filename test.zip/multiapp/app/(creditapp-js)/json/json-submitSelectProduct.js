/*****************************************************************************
 * JSON ACTION Submit RAMP step 0
 *****************************************************************************/


AppC.JsonSubmitSelectProductController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'selectProduct',

			
			claimAusResident:AppC.selectProductData.get('claimAusResident'),
			claimOver18:AppC.selectProductData.get('claimOver18'),
			claimIncomeOver20k:AppC.selectProductData.get('claimIncomeOver20k'),
			claimGoodCreditHistory:AppC.selectProductData.get('claimGoodCreditHistory'),	
			electronicAccepted:AppC.selectProductData.get('electronicAccepted'),
			declarationPrivacyConsent:AppC.selectProductData.get('declarationPrivacyConsent'),
			tcAcknowledge:AppC.selectProductData.get('tcAcknowledge'),
			hsbcRedirectAgree:AppC.selectProductData.get('hsbcRedirectAgree'),
			productCode:AppC.selectProductData.get('productCode')
       });

        this.postRequest(this);
    },


    successBack: function (response) {
        this.handleException(response);
		this.send('goToStep', 1);
    }


});
