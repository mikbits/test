/*****************************************************************************
 * JSON ACTION Retrieve
 *****************************************************************************/


AppC.JsonLookUpController = AppC.JsonActionController.extend({


    /**
     * Methods
     */

    ajaxArr: [],

    notSent: true,

    sentReq: function () {

        var ajaxArr = this.ajaxArr,
            length = ajaxArr.length,
            frontToBack = AppC.map.frontToBack,
            i = 0, key, tempArr = [];

        if (this.notSent && length !== 0) {

            // change front name to back end name
            for (i = length - 1; i >= 0; i--) {
                key = ajaxArr[i];
                if (frontToBack.hasOwnProperty(key)) {
                    tempArr.push(frontToBack[key]);
                }
            }

            // check again whether ajaxArr has contents
            if (tempArr.length != 0) {
                this.run(tempArr);
                this.notSent = false;
            }

        }

    },


    run: function (arr) {

        this.set('args', {
            cmd: 'getLookUpData',
            categories: arr
        });

        this.postRequest(this);
    },


    successBack: function (response) {

        var result = response.resultMap,
            backToFront = AppC.map.backToFront,
            mappedKey;

        this.notSent = true;

        if (this.isSuccess(response)) {

            // empty ajax array cache
            this.ajaxArr = [];

            // read options from response, pass to corresponding arrayController
            for (var key in result) {
                if (result.hasOwnProperty(key)) {
                    if (backToFront.hasOwnProperty(key)) {
                        mappedKey = backToFront[key];
                        // to camelCase
                        mappedKey = mappedKey.charAt(0).toLowerCase() + mappedKey.slice(1);
                        AppC[mappedKey].set('ajaxed', true);
                        AppC[mappedKey].set('content', result[key]);
                    }
                }
            }

            AppC.toggleProperty('selectRenderSwitch');

        } else {
            this.handleException(response);
        }
    }


});

AppC.jsonLookUpController = AppC.JsonLookUpController.create();
