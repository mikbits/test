/*****************************************************************************
 * JSON ACTION Submit FinalzeByExistingCard
 *****************************************************************************/


AppC.JsonSubmitFinalizeExistingController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'finalizeByExistingCard',

			
			consentsToElectronic:AppC.finalizeExistingData.get('consentsToElectronic'),
			addonDeclarationPrivacyConsent:AppC.finalizeExistingData.get('addonDeclarationPrivacyConsent'),
			cardHolderName:AppC.finalizeExistingData.get('cardHolderName'),	
			cardNumber:AppC.finalizeExistingData.get('cardNumber'),
			cardExpiry:AppC.finalizeExistingData.get('cardExpiry'),
			cardCvv:AppC.finalizeExistingData.get('cardCvv'),
			dob:AppC.finalizeExistingData.get('dob')
       });

        this.postRequest(this);
    },


    successBack: function (response) {
        AppC.finalizeExistingData.set('applicationId', response.applicationId);

        var status = String(response.responseStatus);
        var errorCode = String(response.errorCode);
        switch (status) {
            case 'success':
				AppC.finalizeExistingData.set('isApproved',true);
				if(response.addon){
					AppC.finalizeExistingData.set('authorisationNumber', response.addon.authorisationNumber);
					AppC.finalizeExistingData.set('merchantTxnNumber', response.addon.merchantTxnRefId);
					AppC.finalizeExistingData.set('redirectUrl', response.redirectUrl);
				}
                break;
            case 'error':
				AppC.finalizeExistingData.set('isApproved',false);
				AppC.finalizeExistingData.set('errorCode',errorCode);
				if(errorCode=='CREDIT_LIMIT_NOT_ENOUGH'){
					AppC.finalizeExistingData.set("exceedLimit", 'Y');
					AppC.finalizeExistingData.set('errorMessage','We are unable to proceed your purchase using this card. Please check your available balance or contact us at 1300 308 008');	
				}else{
					AppC.finalizeExistingData.set('errorMessage','Your payment has been declined. Please contact us at 1300 308 008 for further information');	
				}
                break;
		}
        this.transitionToRoute("addonDecision");
    }
});
