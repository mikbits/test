/*****************************************************************************
 * JSON ACTION Cross Retrieve
 *****************************************************************************/


AppC.JsonCrxRetrieveController = AppC.JsonActionController.extend({


    /**
     * Methods
     */


    run: function () {

        this.set('args', {
            cmd: 'crxRetrieve'
        });

        AppC.setBusy();
        this.postRequest(this);
    },


    successBack: function (response) {

    	

        if (this.isSuccess(response)) {
			if(response.addon){
				var addonSum = AppC.addonSummaryData;
        		addonSum.setProperties(response.addon);
        		this.transitionToRoute("addonSummary");
			}else{
				this.loadSteps(response);
				this.send('goToStep', 'entry');
			}

        } else {
            this.handleException(response);
        }

        AppC.setReady();
    }


});
