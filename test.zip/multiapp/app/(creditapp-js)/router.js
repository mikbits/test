/*****************************************************************************
 * ROUTER
 *****************************************************************************/


AppC.Router.map(function () {
    this.route('selectProduct');
    this.route('finalizeExisting');
    this.route('addonSummary');
    this.route('addonDecision');
    this.route('entry');
    this.route('branchEntry');
    this.route('raEntry');
    this.route('retrieve');
    this.route('crxRetrieve');
    this.route('chooseApp');
    this.route('timeout');
    this.route('error');
    this.route('errorAjax');
    this.route('selfId');
    this.route('pendingId');
    this.route('processing');
    this.route('approved');
    
    this.resource('dtdAccount', function () {
        this.route('userform', { path: '/' });
        this.route('review');
        this.route('approved');
    });
    
    this.route('step1');
    this.route('step2');
    this.route('step3');
    this.route('step4');
    this.route('step5');
    this.route('step6');
    this.route('denial');
    this.route('notResponding');
    this.route('onlineCalUs');
    this.route('maintenance');
    this.route('idCheckReq');
    this.route('incomeCheckReq');
    this.route('idIncomeCheckReq');
    this.route('actionstep');
});


/*****************************************************************************
 * CLASSES
 *****************************************************************************/

// Retrieve, timeout or error page
AppC.Step0 = Ember.Route.extend({

    activate: function () {
        AppC.set('isNotStep', true);
        AppC.set('isBusy', false); // To display the page
    },

    model: function () {
        return AppC.retrieveData;
    }

});


// Step 1-6 Route
AppC.StepRoute = Ember.Route.extend({

    activate: function () {

        AppC.set('isDtd', false);
        AppC.set('isNotStep', false);

        if (AppC.get('refresh') === true) {
            AppC.set('refresh', false);
            this.controllerFor('jsonRefresh').run();
        }

        if (AppC.get('checkVeda') === true) {
            AppC.set('checkVeda', false);
            AppC.checkGeoCoder();
        }

    }

});


// Step 1-6
AppC.StepIn = AppC.StepRoute.extend({
    step: null,

    activate: function () {
        AppC.set('isNotStep', false);
        AppC.setStep(this.get('step'));
        this._super();
    }

});

// Response pages
AppC.StepOut = Ember.Route.extend({

    activate: function () {
        AppC.set('isDtd', false);
        AppC.set('isNotStep', true);
        AppC.set('isBusy', false); // To display the page

        if (AppC.get('refresh') === true) {
            AppC.set('refresh', false);
            this.controllerFor('jsonRefresh').run();
        }

    },

    model: function () {
        return AppC.responseData;
    }

});



/*****************************************************************************
 * ROUTE INDEX
 *****************************************************************************/


AppC.IndexRoute = Ember.Route.extend({

    redirect: function () {
        this.transitionTo('entry');
    }

});


/*****************************************************************************
 * ROUTES STEP 0
 *****************************************************************************/

AppC.EntryRoute = Ember.Route.extend({
    activate: function () {
        AppC.setStep(0);
        AppC.set('isNotStep', true);
        AppC.set('isBusy', true);
    }
});


AppC.BranchEntryRoute = AppC.Step0.extend({

    activate: function () {
        AppC.setStep(0);
        AppC.set('isNotStep', true);
        AppC.set('isBusy', false); // To display the page
    },

    model: function () {
        return AppC.entryData;
    }

});

AppC.SelectProductRoute = Ember.Route.extend({

    activate: function () {
        AppC.setStep(0);
        AppC.set('isNotStep', true);
        AppC.set('isBusy', false); // To display the page
    },

    model: function () {
        return AppC.selectProductData;
    }

});

AppC.FinalizeExistingRoute = Ember.Route.extend({

    activate: function () {
        AppC.setStep(0);
        AppC.set('isNotStep', true);
        AppC.set('isBusy', false); // To display the page
    },

    model: function () {
        return AppC.finalizeExistingData;
    }

});

AppC.AddonSummaryRoute = Ember.Route.extend({

    activate: function () {
        AppC.setStep(0);
        AppC.set('isNotStep', true);
        AppC.set('isBusy', false); // To display the page
    },

    model: function () {
        return AppC.addonSummaryData;
    }

});

AppC.RaEntryRoute = AppC.BranchEntryRoute.extend();
AppC.TimeoutRoute = AppC.Step0.extend();
AppC.RetrieveRoute = AppC.Step0.extend();
AppC.ErrorRoute = AppC.Step0.extend();
//AppC.SelectProductRoute = AppC.BranchEntryRoute.extend();
AppC.ErrorAjaxRoute = AppC.Step0.extend();
AppC.ChooseAppRoute = AppC.Step0.extend();



/*****************************************************************************
 * ROUTES STEPS 1-6
 *****************************************************************************/

AppC.Step1Route = AppC.StepIn.extend({
    step: 1,

    model: function () {
        return AppC.step1Data;
    }

});


AppC.Step2Route = AppC.StepIn.extend({
    step: 2,

    model: function () {
        return AppC.step2Data;
    }

});


AppC.Step3Route = AppC.StepIn.extend({
    step: 3,

    model: function () {
        return AppC.step3Data;
    }

});


AppC.Step4Route = AppC.StepIn.extend({
    step: 4,

    model: function () {
        return AppC.step4Data;
    }

});


AppC.Step5Route = AppC.StepIn.extend({
    step: 5,

    model: function () {
        return AppC.step5Data;
    }

});


AppC.Step6Route = AppC.StepIn.extend({
    step: 6,

    model: function () {
        return AppC.step6Data;
    }

});


/*****************************************************************************
 * ROUTES REPONSE PAGES
 *****************************************************************************/


AppC.SelfIdRoute = AppC.StepOut.extend({

    activate: function () {
        AppC.setStep(7);
        this._super();
    },

    model: function () {
        return AppC.selfIdData;
    }

});

AppC.DtdAccountRoute = AppC.StepOut.extend({

    //step: 8,

    activate: function () {
    	this._super();
        
    },

    model: function () {
	    AppC.set('isDtd', true);
        return AppC.dtdAccountData;
    }

});

AppC.DtdAccountUserformRoute = AppC.DtdAccountRoute.extend();
AppC.DtdAccountReviewRoute = AppC.DtdAccountRoute.extend();
AppC.DtdAccountApprovedRoute = AppC.DtdAccountRoute.extend();


AppC.PendingIdRoute = AppC.StepOut.extend();
AppC.ProcessingRoute = AppC.StepOut.extend();
AppC.ApprovedRoute = AppC.StepOut.extend();
AppC.DenialRoute = AppC.StepOut.extend();
AppC.NotRespondingRoute = AppC.StepOut.extend();

AppC.OnlineCalUsRoute = AppC.StepOut.extend();
AppC.MaintenanceRoute = AppC.Step0.extend();

AppC.ConditionalApproved = AppC.StepOut.extend({
    activate: function () {
        AppC.set('conditional', true);
        this._super();
    }
});

AppC.IdCheckReqRoute = AppC.ConditionalApproved.extend();
AppC.IncomeCheckReqRoute = AppC.ConditionalApproved.extend();
AppC.IdIncomeCheckReqRoute = AppC.ConditionalApproved.extend();
AppC.ActionstepRoute = AppC.ConditionalApproved.extend();

AppC.AddonDecisionRoute = AppC.FinalizeExistingRoute.extend();

window.onmessage = function(e) {
	console.log(e);
	if (e.data === 'HSBC:PL:ACCEPT') {
		AppC.set('contractAccepted', true);
	}
};

