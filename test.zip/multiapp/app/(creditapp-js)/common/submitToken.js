AppC.SubmitToken = Ember.Object.extend(AppC.Ajaxeable, {
    token:null,
    
    
    refreshSubmitToken: function () {
        var _this = this;

        var payload = '{ "cmd": "getSubmitToken"}';
        
        $.ajax({
            url: AppC.config.get('jsonApiUrl'),
            type: 'post',
            context: this,
            contentType: 'application/json', // Type of data sent to server
            data: payload, // data sent to server, must be string
            dataType: 'json', // Type of response received from server
            timeout: AppC.get('jsonTimeOut'),

            success: function (response) {
                _this.set('token',response.token);
            },

            error: function (jqXHR, textStatus, errorThrown) {
                // do nothing;
            }

        });	        
    },
    
    resetSubmitToken: function() {
    	this.set('token',null);
    }
	
});


AppC.submitToken = AppC.SubmitToken.create(); 
