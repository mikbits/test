/*****************************************************************************
 * VIEW Checkbox
 *****************************************************************************/

AppC.Checkbox = Ember.View.extend({

	/**
	 * Properties
	 */

	classNames : [ 'checkbox' ],
	value : null,

	/**
	 * Bindings
	 */

	attributeBindings : [ 'em-field', 'em-valid', 'em-aside', 'em-errMsg' ],
	classNameBindings : [ 'isValidated:focusOut' ],

	/**
	 * Computed properties
	 */

	isValidated : function() {
		return this.get('em-valid') ? true : false;
	}.property('em-valid'),

	/**
	 * Events
	 */

	click : function(e) {
		var tar = $(e.target);

		if (!tar.hasClass('checkboxButton')) {
			return;
		}

		if (this.get('value')) {
			this.set('value', false);
		} else {
			this.set('value', true);
		}
	},

	valueChanged : function() {
		var emField = this.get('em-field');
		var emValid = this.get('em-valid');

		var checkBox = this.$().children('div.checkboxButton');
		if (this.get('value')) {
			checkBox.addClass('checked');
		} else {
			checkBox.removeClass('checked');
		}

		this.$().val(this.get('value'));
		var emValid = this.get('em-valid');
		if (emValid) {
			this.$().trigger('focusout');
		}

		// Special steps behaviours
		if (this.get('controller').get('checkboxClick')) {
			this.get('controller').checkboxClick(emField);
		}

		AppC.setCurrentStepDirty();
	}.observes('value'),

	/**
	 * Life cycle hooks
	 */

	didInsertElement : function() {
		if (this.get('value')) {
			$('div[em-field="' + this.get('em-field') + '"]').children(
					'div.checkboxButton').addClass('checked');
		} else {
			$('div[em-field="' + this.get('em-field') + '"]').children(
					'div.checkboxButton').removeClass('checked');
		}
	}

});
