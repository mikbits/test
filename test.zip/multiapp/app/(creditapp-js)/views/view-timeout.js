/*****************************************************************************
 * VIEW Timeout
 *****************************************************************************/


AppC.TimeoutView = AppC.RetrieveView.extend({


    /**
     * Properties
     */


    templateName:'timeout'


});
