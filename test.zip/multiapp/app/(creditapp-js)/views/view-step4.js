/*****************************************************************************
 * VIEW Step 4
 *****************************************************************************/


AppC.Step4View = AppC.StepView.extend({


    /**
     * Properties
     */


    templateName: 'step4',

    touchClick:function (e) {

        var emAction = $(e.target).attr('em-action');

        switch (emAction) {

            case '1':
                //$('div#noLicence').removeClass('destroyed');
                //$('div#idLicence').addClass('destroyed');

                $('div#liveOutAus').removeClass('destroyed');
                $('div#liveInAus').addClass('destroyed');
                break;

            case '2':
                $('div#empOutAus').removeClass('destroyed');
                $('div#empInAus').addClass('destroyed');
                break;

            case 'liveInAus':
                this.get('controller').switchComplexAddr(1);
                break;

            case 'empInAus':
                this.get('controller').switchComplexAddr(2);
                break;

            case 'busInAus':
                this.get('controller').switchComplexAddr(3);
                break;

            case 'preAdd':
                this.get('controller').switchComplexAddr(5);
                break;

            case 'openCoverWW':
                this.get('controller').openCoverWW();
                break;

            case 'openCover':
                this.get('controller').openCover();
                break;

            case 'openCDF':
                this.get('controller').openCDF();
                break;


            default:
                this._super(e);

        }
    },



    /**
     * Life cycle hooks
     */


    didInsertElement: function () {

        this._super();
    }


});
