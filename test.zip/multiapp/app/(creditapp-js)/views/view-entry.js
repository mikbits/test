/*****************************************************************************
 * VIEW Entry
 *****************************************************************************/


AppC.EntryView = AppC.EntryParentView.extend({

    actionFn: function () {
        this.get('controller').initStep1();
        this.get('controller').send('goToStep', 1);
        AppC.set('isHSBC', true);
    },

    didInsertElement: function () {
        this._super();
    }

});

