/*****************************************************************************
 * VIEW Mother class step 1
 *****************************************************************************/


AppC.Step1View = AppC.StepView.extend({


    /**
     * Methods
     */


    touchClick: function (e) {
        var target = $(e.target);
        var action = target.attr('em-action');

        if (action === 'toggleReq') {

            if (!AppC.isRunning) {
                AppC.isRunning = true;

                $('ul#listRequirements').fadeToggle('fast');
                $('#requirements').toggleClass('grey');
                $('ul#listRequirements').toggleClass('destroyed');


                Ember.run.later('S4', function() {
                    AppC.isRunning = false;
                }, 500)

            }






        } else if (action === 'openPrivacyPolicy') {
            this.get('controller').openPrivacyPolicy();

        } else if (action === 'openWhyDebitCard') {
            this.get('controller').openWhyDebitCard();
        }

        this._super(e);
    },

    // rerender if isLoan and user refreshed
    isLoanOb: function () {
        AppC.toggleProperty('renderSwitch');
    }.observes('AppC.isLoan'),


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {

        $('input[em-field="emailConfirm"]').on('paste', false);

        this.get('controller').currentDateOb();

        if (AppC.get('isLoan')){
            $(".loanLong").find('input').removeClass('long');
            $(".loanLong").find('select').removeClass('title');
            $('.namesForm').find('input, select').attr('em-aside', 'side');
        }

        AppC.step1Data.set('loanRate', AppC.get('loanRate'));
        AppC.step1Data.set('loanAmt', AppC.get('loanAmt'));
        AppC.step1Data.set('loanPurpose', AppC.get('loanPurpose'));
        AppC.step1Data.set('loanOtherPurpose', AppC.get('loanOtherPurpose'));
        AppC.step1Data.set('loanTerm', AppC.get('loanTerm'));

        if (AppC.step1Data.get('loanPurpose')){
            AppC.step1Data.set('isShowSel', false);
        }

        this._super();
    }


});
