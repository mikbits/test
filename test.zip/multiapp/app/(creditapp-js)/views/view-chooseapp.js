/*****************************************************************************
 * VIEW Choose application
 *****************************************************************************/


AppC.ChooseAppView = Ember.View.extend({


    /**
     * Properties
     */


    templateName:'chooseApp'


});
