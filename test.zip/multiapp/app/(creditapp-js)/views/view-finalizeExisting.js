/*****************************************************************************
 * VIEW Select Product
 *****************************************************************************/


AppC.FinalizeExistingView = AppC.BranchEntryView.extend({

    actionFn: function () {
        //this.get('controller').initStep1();
        AppC.set('isHSBC', false);
    },
	
	focusOut: function(e) {
        var target = $(e.target);
        // Validate div.focusOut
        if (target.hasClass("focusOut")) {
            this.get("controller").validate(e);
        }
    },

    didInsertElement:function () {
        this.get('controller').logoPic();
        this._super();
    }
    
});
