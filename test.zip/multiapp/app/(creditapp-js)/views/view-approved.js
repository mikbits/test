/*****************************************************************************
 * VIEW Approved page
 *****************************************************************************/


AppC.ApprovedView = Ember.View.extend({


    /**
     * Properties
     */


    templateName: 'approved'


});
