/*****************************************************************************
 * VIEW Step 3
 *****************************************************************************/


AppC.Step3View = AppC.StepView.extend({


    /**
     * Properties
     */


    templateName:'step3',


    /**
     * Life cycle hooks
     */

    touchClick:function (e) {
        var emAction = $(e.target).attr('em-action');

        switch (emAction) {

            case 'alterPhotoId':
                AppC.step3Data.set('photoId', null);
                break;

            default:
                this._super(e);

        }
    },

    didInsertElement:function () {

        this._super();
    }


});
