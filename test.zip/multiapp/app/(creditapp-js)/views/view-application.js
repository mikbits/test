/*****************************************************************************
 * VIEW Application
 *****************************************************************************/


AppC.ApplicationView = Ember.View.extend({


    /**
     * Properties
     */


    templateName: 'application',


    /**
     * Events
     */


    click: function (e) {
        this.touchClick(e);
    },


    touchEnd: function (e) {
        this.touchClick(e);
    },


    /**
     * Methods
     */


    footerAction: function (url) {
        window.open(url, '_blank', 'status=yes,location=no,menubar=no,resizable=yes,scrollbars=yes,toolbar=no,width=680,height=545,screenX=0,left=0,screenY=0,top=0');
        return false;
    },


    touchClick: function (e) {
        var action = $(e.target).attr('em-action');
        var currentStep = AppC.getCurrentStep();
        var controller = this.get('controller');

        if (action === 'goStep1' && currentStep !== 1) {
            controller.goStep(currentStep, 1);

        } else if (action === 'goStep2' && currentStep !== 2 && AppC.get('hasSavedStep1')) {
            controller.goStep(currentStep, 2);

        } else if (action === 'goStep3' && currentStep !== 3 && AppC.get('hasSavedStep2')) {
            controller.goStep(currentStep, 3);

        } else if (action === 'goStep4' && currentStep !== 4 && AppC.get('hasSavedStep3')) {
            controller.goStep(currentStep, 4);

        } else if (action === 'goStep5' && currentStep !== 5 && AppC.get('hasSavedStep4')) {
            controller.goStep(currentStep, 5);

        } else if (action === 'goStep6' && AppC.get('hasSavedStep5')) {
            controller.goStep(currentStep, 6);

        } else if (action === 'saveBack') {
            controller.goStep(currentStep, currentStep - 1);

        } else if (action === 'saveContinue') {
            controller.goStep(currentStep, currentStep + 1, true);

        } else if (action === 'saveReview') {
            controller.goStep(currentStep, 6);

        } else if (action === 'print') {
            print();

        } else if (action === 'close') {
            window.open('', '_self', '');
            window.close();

        } else if (action === 'openPrivacy') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/privacy-and-security');

        } else if (action === 'openKeyFactsCC') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/key-facts-sheet-hcc.pdf');

        } else if (action === 'openKeyFactsCCC') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/key-facts-sheet-classic-card.pdf');

        } else if (action === 'openKeyFactsPCC') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/key-facts-sheet-platcc.pdf');

        } else if (action === 'openKeyFactsPQCC') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/key-facts-sheet-qff.pdf');

        } else if (action === 'openKeyFactsPWM') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/key-facts-sheet-premier-cc.pdf');

        } else if (action === 'openKeyFactsWW') {
            this.footerAction('https://www.apps.asiapacific.hsbc.com/1/PA_WABEngine_1/content/AUH2/key-facts-sheet-wow-edm.pdf');

        } else if (action === 'openKeyFactsCPCCC') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/corporatepartners/pdf/kfs-cp-classic.pdf');

        } else if (action === 'openPolicy') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/hyperlink-policy');

        } else if (action === 'openTerms') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/terms-of-use');

        } else if (action === 'openAdvice') {
            this.footerAction('https://www.hsbc.com.au/1/2/footer/general-advice-warning');

        } else if (action === 'openRetrieveInfo') {
            AppC.ux.openModal('retrieveInfo');

        } else if (action === 'openImportantInformation') {
            AppC.ux.openModal('importantInfo');

        } else if (action === 'openProductInformation') {
            AppC.ux.openModal ('productInformation');

        } else if (action === 'openFeesAndChargesGuide') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/fees-charges.pdf');

        } else if (action === 'openFinancialServicesGuide') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/pfs-fsg.pdf');

        } else if (action === 'openProductDisclosureStatement') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/savings-pds.pdf');

        } else if (action === 'openPrivacyAcknowledgementAndConsent') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/ss-privacy-consent.pdf');

        } else if (action === 'openOstFsg') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/fsg');

        } else if (action === 'openOstTermsConditions') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/terms');

        } else if (action === 'openPartnerSponsorshipAgreement') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/psa');

        } else if (action === 'openOstPrivacyPolicy') {
            this.footerAction('https://www.sharetrading.hsbc.com.au/info/privacypolicy.html');

        } else if (action === 'openCNYLimitations') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/renminbi-supp-pds.pdf');

        } else if (action === 'openCondition') {
            this.footerAction('http://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/credit-card-terms.pdf');
            
        } else if (action === 'openBalanceTransferCondition') {
            this.footerAction('info/index.html');

        } else if (action === 'openConditionPL') {
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/personal-loan-terms.pdf');

        } else if (action === 'openPrivacyConsent'){
            this.footerAction('http://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/cc-app-tncs.pdf');

        } else if (action === 'openPrivacyConsentPL'){
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/pl-privacy-consent.pdf');

        } else if (action === 'openDDAgreementPL'){
            this.footerAction('https://www.hsbc.com.au/1/PA_ES_Content_Mgmt/content/australia/common/pdf/personal/dd-service-agreement.pdf');

        } else {
            this._super(e);
        }

    },

    didInsertElement: function () {
        var controller = this.get('controller');
        controller.refreshServerDate();
    }

});
