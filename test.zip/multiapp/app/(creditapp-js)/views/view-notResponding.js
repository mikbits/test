/*****************************************************************************
 * VIEW Not Responding page
 *****************************************************************************/


AppC.NotRespondingView = Ember.View.extend({


    /**
     * Properties
     */


    templateName: 'notResponding'


});
