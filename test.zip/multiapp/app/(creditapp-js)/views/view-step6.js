/*****************************************************************************
 * VIEW Step 6
 *****************************************************************************/


AppC.Step6View = AppC.StepView.extend({


    /**
     * Properties
     */


    templateName:'step6',

    /**
     * Methods
     */


    touchClick:function (e) {
        var emAction = $(e.target).attr('em-action');

        switch (emAction) {

            case 'editStep1':
                this.get('controller').goStep(1);
                break;

            case 'editStep2':
                this.get('controller').goStep(2);
                break;

            case 'editStep3':
                this.get('controller').goStep(3);
                break;

            case 'editStep4':
                this.get('controller').goStep(4);
                break;

            case 'editStep5':
                this.get('controller').goStep(5);
                break;

            case 'submitApp':
                this.get('controller').submitApp();
                break;

            case 'validateCaptcha':
                this.get('controller').validateCaptcha();
                break;

            default:
                this._super(e);

        }
    },


    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        var $cell15 = $('div#cell15');
        var $cell16 = $('div#cell16');
        var $cell25 = $('div#cell25');
        var $cell26 = $('div#cell26');
        var cell15Height = $cell15.height();
        var cell16Height = $cell16.height();
        var cell25Height = $cell25.height();
        var cell26Height = $cell26.height();
        var maxHeight1 = Math.max(cell15Height, cell25Height);
        var maxHeight2 = Math.max(cell16Height, cell26Height);

        $cell15.height(maxHeight1);
        $cell16.height(maxHeight2);
        $cell25.height(maxHeight1);
        $cell26.height(maxHeight2);

        if(!this.get('controller').get('captchaLoaded')){
        	 this.get('controller').send('refreshCaptcha');
        }else{
            this.get('controller').refreshCaptchaUrl();
        }
        
       	AppC.submitToken.refreshSubmitToken();

        this._super();
    }

});
