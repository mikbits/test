/*****************************************************************************
 * VIEW Ramp
 *****************************************************************************/


AppC.BranchEntryView = AppC.EntryParentView.extend({

    actionFn: function () {
        this.get('controller').initStep1();
        AppC.set('isHSBC', true);
    },

    didInsertElement:function () {
        this.get('controller').logoPicBranch();
        this._super();
    }

});
