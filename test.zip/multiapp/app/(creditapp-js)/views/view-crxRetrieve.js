/*****************************************************************************
 * VIEW Entry Class
 *****************************************************************************/


AppC.CrxRetrieveView = Ember.View.extend({

    didInsertElement: function () {

        this.get('controller').crxRetrieve();

    }

});

