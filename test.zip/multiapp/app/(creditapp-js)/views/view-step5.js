/*****************************************************************************
 * VIEW Step 5
 *****************************************************************************/


AppC.Step5View = AppC.StepView.extend({


    /**
     * Properties
     */


    templateName:'step5',
        touchClick:function (e) {
        var emAction = $(e.target).attr('em-action');

        switch (emAction) {

            case 'intHomePhone':
                AppC.step5Data.set('isIntHomePhone', true);
                break;

            case 'intMobilePhone':
                AppC.step5Data.set('isIntMobilePhone', true);
                break;

            case 'ausHomePhone':
                AppC.step5Data.set('isIntHomePhone', false);
                break;

            case 'ausMobilePhone':
                AppC.step5Data.set('isIntMobilePhone', false);
                break;

            case 'partAdd':
                this.get('controller').switchComplexAddr(4);
                break;

            default:
                this._super(e);

        }
    },

    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        this._super();
    }


});
