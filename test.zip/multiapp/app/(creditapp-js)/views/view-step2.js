/*****************************************************************************
 * VIEW Step 2
 *****************************************************************************/


AppC.Step2View = AppC.StepView.extend({


    /**
     * Properties
     */


    templateName: 'step2',


    /**
     * Methods
     */


    touchClick: function (e) {
        var action = $(e.target).attr('em-action');

        if (action === 'addCard') {
            AppC.step2Data.set('currentCard', AppC.step2Data.currentCard+1);
            AppC.setCurrentStepDirty();

        } else if (action === 'removeCard') {
            AppC.step2Data.set('currentCard', AppC.step2Data.currentCard-1);
            AppC.setCurrentStepDirty();

            if (AppC.step2Data.get('cardNum3')) {
                if (AppC.step2Data.get('currentCard') == 3){
                    return;
                }
                AppC.step2Data.set('cardNum3', null);
                AppC.step2Data.set('cardIssuedBy3', null);
                AppC.step2Data.set('cardBalTranAmt3', null);
                return;
            }

            if (AppC.step2Data.get('cardNum2')) {
                if (AppC.step2Data.get('currentCard') == 2) {
                    return;
                }
                AppC.step2Data.set('cardNum2', null);
                AppC.step2Data.set('cardIssuedBy2', null);
                AppC.step2Data.set('cardBalTranAmt2', null);
                return;
            }



        } else {
            this._super(e);
        }

    },


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {
        if (AppC.step2Data.get('cardNum2')) {
            AppC.step2Data.set('currentCard', 2);
        }

        if (AppC.step2Data.get('cardNum3')) {
            AppC.step2Data.set('currentCard', 3);
        }
        this._super();
    }


});
