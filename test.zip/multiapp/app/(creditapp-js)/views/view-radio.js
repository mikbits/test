/*****************************************************************************
 * VIEW Radio
 *****************************************************************************/


AppC.RadioBool = Ember.View.extend({


    /**
     * Bindings
     */


    attributeBindings:['em-field', 'em-valid', 'em-aside', 'em-errMsg'],
    classNameBindings:['isValidated:focusOut'],


    /**
     * Computed properties
     */


    isValidated:function () {
        return this.get('em-valid') ? true : false;
    }.property('em-valid'),


    /**
     * Events
     */


    click:function (e) {
        var target = $(e.target);
        var emField = this.get('em-field');
        var emBool = target.attr('em-bool');


        var data = AppC.getCurrentStepData();
        var value = data.get(emField);
        var radioTrue = $('div[em-field="' + emField + '"] div.radioButton[em-bool="true"]');
        var radioFalse = $('div[em-field="' + emField + '"] div.radioButton[em-bool="false"]');
        var root = $('div[em-field="' + emField + '"]');

        if (emBool === 'true' && !value) {
            data.set(emField, true);
            AppC.setCurrentStepDirty();
            radioTrue.addClass('checked');
            radioFalse.removeClass('checked');
            root.trigger('focusout');

            // Special steps behaviours
            var controller = (this.get('controller') ? this.get('controller') :  this.get('parentView').get('controller'));
            controller.radioTrue(emField);

        } else if (emBool === 'false' && (value || value === null)) {
            data.set(emField, false);
            AppC.setCurrentStepDirty();
            radioTrue.removeClass('checked');
            radioFalse.addClass('checked');
            root.trigger('focusout');

            // Special steps behaviours
            var controller = (this.get('controller') ? this.get('controller') :  this.get('parentView').get('controller'));
            controller.radioFalse(emField);
        }
    },


    /**
     * Life cycle hooks
     */


    didInsertElement:function () {
        var emField = this.get('em-field');
        var value = AppC.getCurrentStepData().get(emField);

        if (value === true) {
            $('div[em-field="' + emField + '"] div.radioButton[em-bool="true"]').addClass('checked');

        } else if (value === false) {
            $('div[em-field="' + emField + '"] div.radioButton[em-bool="false"]').addClass('checked');
        }

    }


});
