/*****************************************************************************
 * VIEW Autocomplete
 *****************************************************************************/


AppC.InputGeoCoder = Ember.TextField.extend(AppC.Watermark, AppC.InputKeyDown, {


    /**
     * Bindings
     */


    attributeBindings: ['em-holder', 'em-field', 'em-valid', 'em-aside', 'em-focusout', 'em-errMsg'],


    /**
     * Events
     */


    keyUp: function (e) {
        var target = $(e.target);
        var field = target.attr('em-field');

        // Select address on keyUp Tab
        if (e.which === 9) {
            this.$().select();
        }

        // Watermark
        if (target.val()) {
            this.removeWatermark(field);

        } else if (target.attr('em-holder')) {
            this.displayWatermark(target.attr('em-field'), target.prop('tagName').toLowerCase(), target.attr('em-holder'));
        }

        // Step is dirty
        AppC.set('isStep' + AppC.getCurrentStep() + 'Dirty', true);

    },


    focusOut: function (e) {
        var target = $(e.target);
        var valid = target.attr('em-valid');
        var fo = target.attr('em-focusout');

        if (valid && (fo != 'skip')) {
            this.get('parentView').get('controller').validate(e);
        }

    },

    valueChanged: function() {
    	var value = this.get('value');

    	var field = this.get('em-field');

    	var target = this.$();       

    	// Watermark
        if (value) {
            this.removeWatermark(field);

        } else if (target.attr('em-holder')) {
            this.displayWatermark(target.attr('em-field'), target.prop('tagName').toLowerCase(), target.attr('em-holder'));
        }
    }.observes('value'),


    /**
     * Life cycle hooks
     */


    didInsertElement: function () {
        var field = this.get('em-field');
        var $this = this.$();
        var _this = this;

        // Display watermark
        if (!$this.val() && $this.attr('em-holder')) {
            this.displayWatermark($this.attr('em-field'), $this.prop('tagName').toLowerCase(), $this.attr('em-holder'));
        }

        // Autocomplete
        $('input[em-field="' + field + '"]').autocomplete({

            source: function (request, response) {

                $.ajax({
                    url: 'https://geocoderweb.veda.com.au/address?max=5',
                    data: { address: request.term },
                    dataType: "jsonp",

                    success: function (data) {
                        var result = data.Result ? data.Result : '';
                        response($.map(result, function (item) {
                            return item;
                        }));
                    }
                });

            },

            minLength: 2,

            select: function (e, ui) {

                $this.addClass('ui-autocomplete-loading');
                $this.attr('em-focusout', 'skip');

                $.ajax({
                    url: 'https://geocoderweb.veda.com.au/ValidateAddress',
                    data: { address: ui.item.label },
                    dataType: "jsonp",

                    success: function (response) {
                        $this.removeClass('ui-autocomplete-loading');
                        _this.get('parentView').get('controller').addressValidated(response, field);
                    }

                });

            }
        });
    }


});
