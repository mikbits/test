/*****************************************************************************
 * VIEW Step 6
 *****************************************************************************/


AppC.DtdAccountView = AppC.StepView.extend({


    /**
     * Properties
     */


    templateName:'dtdAccount',
	
    /**
     * Methods
     */
    init: function(){
    	this._super();

        if(this.get('controller.nationality')){
            this.get('controller.nationalityCountries2').removeObject(AppC.countries.findBy('code'),this.get('controller.nationality'));
            this.get('controller.nationalityCountries3').removeObject(AppC.countries.findBy('code'),this.get('controller.nationality'));

        }
        if(this.get('controller.nationality2')){
            this.get('controller.nationalityCountries3').removeObject(AppC.countries.findBy('code'),this.get('controller.nationality2'));
        }
    },	


    /**
     * Life cycle hooks
     */
    didInsertElement:function () {
        this._super();
        if (AppC.dtdAccountData.get('hasMultipleNat') === true) {
            $('div#otherNat').removeClass('destroyed');
        }
    }	 


});
