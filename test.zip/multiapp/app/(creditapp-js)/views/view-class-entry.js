/*****************************************************************************
 * VIEW Entry Class
 *****************************************************************************/


AppC.EntryParentView = Ember.View.extend({

    redirect: function () {

        var _this = this;

        if (!AppC.logo) {

            setTimeout(function () {
                _this.redirect();
            }, 100);
            return;

        }

        this.actionFn();
        AppC.setReady();

    },

    didInsertElement: function () {

        this.get('controller').entryReq();
        this.redirect();

    }

});

