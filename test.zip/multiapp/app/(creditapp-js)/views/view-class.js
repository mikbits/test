/*****************************************************************************
 * VIEW Step class
 *****************************************************************************/


AppC.StepView = Ember.View.extend({


    /**
     * Events
     */


    rSwitchOb: function () {
        this.rerender();
    }.observes('AppC.renderSwitch'),


    click: function (e) {
        this.touchClick(e);
    },


    touchEnd: function (e) {
        this.touchClick(e);
    },


    focusOut: function (e) {
        var target = $(e.target);

        // Validate div.focusOut
        if (target.hasClass('focusOut')) {
            this.get('controller').validate(e);
        }

    },



    /**
     * Methods
     */


    touchClick: function (e) {
        var target = $(e.target);

        if (target.hasClass('watermark')) {
            var field = target.attr('em-field');
            $('input[em-field=' + field + ']').select();
        }

    },


    processLogo: function () {

        if (!/entry/i.test(window.location.hash)) {

            if (AppC.get('isInRa')){
                AppC.set('raImgBg', '');
                $('#raImgBg').css('background-image', 'url(' + AppC.get('raImgBg') + ')');
            }

            if (AppC.get('isWoolworths')) {
                AppC.set('logoImg', 'images/woolworths-logo.jpg')
            } else {
                AppC.set('logoImg', 'images/logo.png')
            }

        }

    },


    changeLogo: function () {

        this.processLogo();

    }.observes('AppC.isInRa', 'AppC.isWoolworths'),

    /**
     * Life cycle hooks
     */


    didInsertElement: function () {

        this.processLogo();

    }


});
