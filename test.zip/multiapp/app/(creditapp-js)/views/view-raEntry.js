/*****************************************************************************
 * VIEW Ramp
 *****************************************************************************/


AppC.RaEntryView = AppC.BranchEntryView.extend({

    actionFn: function () {
        this.get('controller').initStep1();
        AppC.set('isHSBC', false);
    },

    didInsertElement:function () {
        this.get('controller').logoPic();
        this._super();
    },
    
    change: function(e){
   		var target = $(e.target);
        var emField = target.attr('em-field');
        if (emField=="customerAtState"){
        	var state = target.val();
			switch (state) {
			 	case "ACT":
	            	state =1;
	            	break;
	            case "NSW":
	                state =2;
	            	break;           
	            case "VIC":
	            	state =3;
	            	break;           	
	            case "QLD":
	            	state =4;
	            	break;           
	            case "SA":
	            	state =5;
	            	break;          	
	            case "WA":
	            	state =6;
	            	break;          	
	            case "TAS":
	            	state =7;
	            	break;          	
	            case "NT":
	            	state =8;
	            	break;
			}	
			
			var hasList="";
			var storeList="";
			
			$("[em-field='storeId']").empty();
			
			AppC.retail.forEach(function (item) {
	    		if (item!=null){
		    		if (state == (item.code).substring(0,1)){
		    			hasList="1";
		    			storeList += "<option value=" + item.code + ">" + item.name + "</option>";
		    		}
	    		}  		
    		});
    		if (storeList ==""){
    			$("#storeDiv").hide();
    			$("#noStore").show();
    			
    		} else {
    			storeList = "<option class='watermark' value=''>Please select</option>"+storeList;
    			$("#storeDiv").show();
    			$("#noStore").hide();
    			$("[em-field='storeId']").append(storeList);
    		}
        }
        
    }
});
