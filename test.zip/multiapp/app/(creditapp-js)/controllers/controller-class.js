/*****************************************************************************
 * CONTROLLER Mother class
 *****************************************************************************/

AppC.StepController = Ember.ObjectController.extend({


    /**
     * Properties
     */

    errorsContainer: AppC.inputErrors,


    /**
     * Methods needed by event proxies (views input, checkbox, radio, select)
     */
    computeYears: function (fieldY, fieldM) {
        var months = this.get(fieldM);
        var years = this.get(fieldY) || 0;
        years = AppC.validationController.hasOnlyDigits(years) ? parseInt(years) : 0;

        if (months && AppC.validationController.hasOnlyDigits(months)) {
            months = parseInt(months);
            var extraYears = Math.floor(months / 12);
            if(extraYears >0){
                years += extraYears;
                months = months % 12;
                if (years > 99){
                    years = 99;
                }
                this.set(fieldY, String(years));
                this.set(fieldM, String(months));
                $('input[em-field="' + fieldY + '"]').val(years);
    			$('input[em-field="' + fieldY + '"]').trigger('focusout');
                $('input[em-field="' + fieldM + '"]').val(months);
            }
        }

        return years;
    },


    inputKeyUp: function (e) {
    },
    inputFocusOut: function (e) {
    },

    inputKeyPress: function (e) {
        var target = $(e.target);
        var valid = target.attr('em-valid');
        var regexp = /(?:^|\s)(onlyDigits)(?:$|\s)/;
        var hasOnlyDigits = regexp.test(valid);
        var charCode = e.which;

        if (
            hasOnlyDigits &&
            charCode &&
            (charCode > 57 || charCode < 48) &&
            (charCode != 8 &&
             charCode != 9 &&
             charCode != 35 &&
             charCode != 36 &&
             charCode != 37 &&
             charCode != 38 &&
             charCode != 39 &&
             charCode != 40 &&
             charCode != 46 &&
             charCode != 110 &&
             charCode != 190)
        ) {
            e.preventDefault();
        }
    },

    checkboxClick: function (emField) {
    },
    radioTrue: function (emField) {
    },
    radioFalse: function (emField) {
    },
    selectChange: function (emField) {
    },
    saveDate: function (field, value) {
    },



    /**
     * Methods
     */


    validate: function (e) {

        var

        target = $(e.target),
        emberId = e.target.id,
        isBypassed = target.parents('div.blockToggle').hasClass('destroyed'),
        value = target.val(),
        validate = AppC.validationController,
        emValid = target.attr('em-valid'),
        ops = emValid ? emValid.split(' ') : [],
        asideClass = target.attr('em-aside'),
        length = ops.length,

        errMsgAry = target.attr('em-errMsg')?target.attr('em-errMsg').split("__") : [],
        errMsgObj = {},
        errMsg,
        errName,
        errVal,

        opArr,
        op,
        param,
        reqMsg,
        isSelect,

        i,
        j;

        for (i = 0; i < errMsgAry.length; i++) {
            errName = errMsgAry[i].split("_")[0];
            errVal = errMsgAry[i].split("_")[1];
            errMsgObj[errName] = errVal;
        };

        // Assume no error (add error later if found)
        this.removeError(emberId);

        for (j = 0; ops[j]; j += 1) {
            var sepIndex = ops[j].indexOf('_');
            if (sepIndex !== -1) {
                op = ops[j].slice(0,sepIndex);
                param = ops[j].slice(sepIndex+1);
            } else {
                op = ops[j];
            }

            switch (op) {

                case 'req':
                case 'sreq':
                reqMsg = (op === 'req') ? 'Required' : 'Req.';
                isSelect = target.prop('tagName').toLowerCase() === 'select';
                if (!validate.isInformed(value) || (isSelect && value === 'seperator')) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:reqMsg;
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'geo':
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Required, please find your address';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                break;

                case 'check':
                if (!target.find('.checked').length) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Required';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'radio':
                var idQuestion = target.children('div.formQuestion').attr('id');
                var radioField = target.attr('em-field');
                this.removeError(idQuestion);
                if (AppC.getCurrentStepData().get(radioField) === null) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Req';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'oneChoiceReq':
                var throwError = true;
                var idLabel = target.children('label:first-child').attr('id');
                this.removeError(idLabel);
                target.find('div.checkboxButton').each(function () {
                    if ($(this).hasClass('checked')) {
                        throwError = false;
                    }
                });
                if (throwError) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Please select at least one option';
                    this.addError(isBypassed, idLabel, errMsg, asideClass);
                    return;
                }
                break;

                case 'maxChoices':
                var maxChoices = param;
                var idLabelMax = target.children('label:first-child').attr('id');
                this.removeError(idLabelMax);
                if (target.find('div.checkboxButton.checked').length > maxChoices) {
                    errMsg = errMsgObj['maxChoices']?errMsgObj['maxChoices']:'Please check at most ' + maxChoices + ' options';
                    this.addError(isBypassed, idLabelMax, errMsg, asideClass);
                    return;
                }
                break;

                case 'gross':

                var salary = parseInt(AppC.step5Data.get('salaryWtTax'), 10) || null ;
                var salaryFreq = AppC.step5Data.get('salaryFreq') || null;
                var salaryTotal = 0;

                var other = parseInt(AppC.step5Data.get('incomeWtTax'), 10) || null;
                var otherFreq = AppC.step5Data.get('incomeFreq') || null;
                var otherTotal = 0;

                var gYear = parseInt(AppC.step5Data.get('incomeGross'), 10);

                var hasSalaryFreq = true;
                var hasOtherFreq = true;


                switch (salaryFreq){
                    case 'W':
                        salaryTotal = salary * 54;
                        break;

                    case 'F':
                        salaryTotal = salary * 27;
                        break;

                    case 'M':
                        salaryTotal = salary * 12;
                        break;

                    case 'Y':
                        salaryTotal = salary * 1;
                        break;

                    default:
                        $('select[em-field="salaryFreq"]').trigger('focusout');
                        hasSalaryFreq = false;
                        break;

                }

                switch (otherFreq){
                    case 'W':
                        otherTotal = other * 54;
                        break;

                    case 'F':
                        otherTotal = other * 27;
                        break;

                    case 'M':
                        otherTotal = other * 12;
                        break;

                    case 'Y':
                        otherTotal = other * 1;
                        break;

                    default:
                        $('select[em-field="incomeFreq"]').trigger('focusout');
                        hasOtherFreq = false;
                        break;
                }


                if (gYear < salaryTotal + otherTotal) {
                    this.addError(isBypassed, emberId, 'Please check, should be more than your net income', asideClass);
                    return;
                }

                if (gYear < AppC.incomeRe) {
                    this.addError(isBypassed, emberId, 'Gross income per year must be higher than ' + this.formatCurrency(AppC.incomeRe), asideClass);
                    return;
                }
                
                if (otherTotal && !gYear) {
                	this.addError(isBypassed, emberId, 'Req.', asideClass);
                	return;
                }
                
                break;

                case 'creditLimit':
                if ( value > Number(AppC.maxCredit) || value < Number(AppC.minCredit) ) {
                    this.addError(isBypassed, emberId, 'The amount should be between ' + this.formatCurrency(AppC.minCredit) + ' and ' + this.formatCurrency(AppC.maxCredit), asideClass);
                    return;
                }
                break;

                case 'creditLimitRA':
                if ( value > 20000 || value < 1000 ) {
                    this.addError(isBypassed, emberId, 'The amount should be between ' + this.formatCurrency(1000) + ' and ' + this.formatCurrency(20000), asideClass);
                    return;
                }
                break;

                case 'sreqwhen':

                    var paramArr = param.split('_');
                    var emberId2 = $('input[em-field="' + paramArr[0] + '"]').attr('id');
                    var value2 = $('input#' + emberId2).val();

                    if (value2 > 0 && !value) {
                        this.addError(isBypassed, emberId, 'Req.', asideClass);
                        return;
                    } else {
                        $('#' + emberId2).removeClass('error');
                    }

                break

                case 'reqPhoneWith':
                var paramArr = param.split('_');
                var emberId2 = $('input[em-field="' + paramArr[0] + '"]').attr('id');
                var value2 = $('input#' + emberId2).val();

                value = value.indexOf('_') === -1 ? value : '';
                value2 = value2.indexOf('_') === -1 ? value2 : '';

                if (!validate.isInformed(value)) {

                    if (!validate.isInformed(value2)) {
                        var targetDisplay = $('input[em-field="' + paramArr[1] + '"]').attr('id');
                        this.addError(isBypassed, emberId, 'Please enter at least 1 valid phone number', asideClass, emberId2, targetDisplay);
                        return;
                    }

                } else if (!validate.isInformed(value2)) {

                    $('#' + emberId2).removeClass('error');

                }
                break;

                case 'diff':
                var fieldComp = op.split('_')[1];
                var $fieldComp = $('select[em-field="' + fieldComp + '"]');
                var fieldCompId = $fieldComp.attr('id');
                var fieldCompVal = $fieldComp.val();
                if (fieldCompVal && (fieldCompVal != 'seperator') && (fieldCompVal === value)) {
                    this.addError(isBypassed, emberId, '2nd and 3rd nationalities can\'t be the same', asideClass);
                    return;
                } else {
                	var errHtml = $('aside.error_' + fieldCompId).find('span').html();
                	if (errHtml != 'Required' && errHtml != 'Req.') {
                		this.removeError(fieldCompId);
                	}
                }
                break;

                case 'name':
                if (!validate.isName(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Invalid char.';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'email':
                if(!validate.isEmail(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid email address';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'confirm':
                if ($('input[em-field="email"]').val().toLowerCase() != value.toLowerCase()) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'The email address does not match, please re-enter';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'homePhone':
                if (value && !validate.isHomePhone(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid phone number';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'mobilePhone':
                if (value && !validate.isMobilePhone(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid mobile phone number';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'intPhone':
                if (value && !validate.isIntPhone(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid mobile phone number';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;
                
                case 'allPhone':
                    if (value && !validate.isAllPhone(value)) {
                        errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid phone number';
                        this.addError(isBypassed, emberId, errMsg, asideClass);
                        return;
                    }
                break;

                case 'onlyDigits':
                if (!validate.hasOnlyDigits(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Only digits please';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'isBusinessName':
                    if (!(/^[a-zA-Z0-9\s\-\&\/]*$/.test(value))) {
                        errMsg = 'Only Alnum - & / allowed';
                        this.addError(isBypassed, emberId, errMsg, asideClass);
                        return;
                    }

                    break;

                case 'onlyLetters':
                if (!validate.hasOnlyLetters(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Only letters please';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'onlyDigitsStrict':
                if (!validate.hasOnlyDigitsStrict(value)) {
                    errMsg = errMsgObj[op]?errMsgObj[op]:'Only digits please';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'onlyDigitsAndLetters':
                case 'sonlyDigitsAndLetters':
                if (!validate.hasOnlyDigitsAndLetters(value)) {
                    reqMsg = (op === 'onlyDigitsAndLetters') ? 'Invalid character' : 'Invalid char.';
                    errMsg = errMsgObj[op]?errMsgObj[op]:reqMsg;
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'streetNb':
                if (!validate.isStreetNb(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'Invalid char.';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'pobox':
                if (!validate.pobox(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'P.O. Box addresses are not allowed. <br /> <span style="">Please use a different address.</span>';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'date':
                if (!validate.isDate(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid date';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'dateMMYYYY':
                if (!validate.isDateMMYYYY(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'Please enter a valid date';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
               }
               break;

                case 'is18':
                if (!validate.is18(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'You must be at least 18 years old';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'ageLessThan100':
                if (!validate.ageLessThan100(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'You have entered a date 100 years ago';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'notExpired':
                if (!validate.notExpired(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'You have entered an expired date';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;
                
                case 'notExpiredMMYYYY':
                if (!validate.notExpiredMMYYYY(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'You have entered an expired date';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;
                
                case 'agreed':
                if (!this.get(emberId)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'Required';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'noSpace':
                if (validate.hasSpace(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'No space please';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'noDigit':
                if (validate.hasDigit(value)) {
                    var errMsg = errMsgObj[op]?errMsgObj[op]:'No digit please';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'min':
                if (!validate.isMin(value, param)) {
                    if (value) {
                        var errMsg = errMsgObj['min']?errMsgObj['min']:'Too short';
                        this.addError(isBypassed, emberId, errMsg, asideClass);
                        return;
                    }
                }
                break;

                case 'lessThanField':
                if (!validate.isLessThanField(value, param)) {
                    var errMsg = errMsgObj['lessThanField']?errMsgObj['lessThanField']:'This field should less than ' + param;
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'isNotGreaterThanField':
                if (!validate.isNotGreaterThanField(value, param)) {
                    var value2 = $('input[em-field="' + param + '"]').val();
                    var errMsg = errMsgObj['isNotGreaterThanField']?errMsgObj['isNotGreaterThanField']:'This field should not be greater than ' + this.formatCurrency(value2);
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'sumIsNotGreaterThanField':
                if (!validate.sumIsNotGreaterThanField(value, param)) {
                    var errMsg = errMsgObj['sumIsNotGreaterThanField']?errMsgObj['sumIsNotGreaterThanField']:'The fields summary should not greater than ' + param;
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'isNotGreaterThan':
                if (!validate.isNotGreaterThan(value, param)) {
                    var errMsg = errMsgObj['isNotGreaterThan']?errMsgObj['isNotGreaterThan']:'This field should not be greater than ' + this.formatCurrency(param);
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'lengthEither':
                if (value && !validate.lengthEither(value, param)) {
                    var errMsg = errMsgObj['lengthEither']?errMsgObj['lengthEither']:'The field length do not match the requirement';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'isNotLessThan':
                if (!validate.isNotLessThan(value, param)) {
                    var errMsg = errMsgObj['isNotLessThan']?errMsgObj['isNotLessThan']:'Please enter more than ' + this.formatCurrency(param);
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                // special case for RA applicants who are not Australian,
                // and Personal Loan pplicants who are not HSBC customer.
                case 'notCusPL':
                if (validate.notCusPL()) {
                    if (AppC.get('bundle') == 6) {
                        errMsg = 'Unfortunately only existing HSBC customers may apply for a HSBC Premier World Mastercard.';
                        errMsg += '<br>' +
                        'To find out more please call 1300 308 008 between 8am to 8pm AEST';
                    } else {
                        errMsg = 'If you have received an invitation to apply for a HSBC Personal Loan, please call HSBC on 1300 308 280 (option 2) and quote the promotional code we sent you. Unfortunately only those who have received an invitation or existing HSBC customers can apply.';
                    }
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;

                case 'notAuRA':
                if (validate.notAuRA()) {
                    errMsg = 'Only a permanent Australian resident can apply';
                    this.addError(isBypassed, emberId, errMsg, asideClass);
                    return;
                }
                break;
				
				// syntax minMonthsWith_{minimum months required}_{the years input field name}
				// em-valid="minMonthsWith_1_contractLengthYears"
                case 'minMonthsWith':
					var paramArr = param.split('_');
					var minimumMonthsRequired = parseInt(paramArr[0]);
					var emberId2 = $('input[em-field="' + paramArr[1] + '"]').attr('id');
					var value2 = $('input#' + emberId2).val();
					var years=0;
					if(value2){
						years=parseInt(value2);
					}

					if (validate.isInformed(value)) {
						var months= years * 12 + parseInt(value);
						if(months < minimumMonthsRequired ) {
							var errMsg = "At least " + minimumMonthsRequired + " months";
							if(minimumMonthsRequired === 1 ) {
								errMsg = "At least " + minimumMonthsRequired + " month";
							}
							this.addError(isBypassed, emberId, errMsg, asideClass);
						}
					} 
                break;	

				// syntax sumNotMoreThan_{maximum value holding field name}_{the field name of the value to be added to current field}_{the field name of the value to be added to current field}_.....
				// em-valid="sumNotMoreThan_totalBalOwing_cardBalTranAmt2_cardBalTranAmt3"
				// meaning: the value of this field + the value of field cardBalTranAmt2 + the value of field cardBalTranAmt3 should not be more than the value of totalBalOwing
                case 'sumNotMoreThan':
					var paramArr = param.split('_');
					var maximumValueFieldName = $('input[em-field="' + paramArr[0] + '"]').attr('id')
					var maximumValue= parseInt($('input#' + maximumValueFieldName).val());
					var sum=parseInt(value);
					for(i=1;i<param.length;i++){
						var tempEmberId = $('input[em-field="' + paramArr[i] + '"]').attr('id');
						var tempValue = $('input#' + tempEmberId).val();
						if(tempValue){
							sum = sum + parseInt(tempValue);
						}
					}

					if (sum>maximumValue) {
						var errMsg = errMsgObj['sumIsNotGreaterThanField']?errMsgObj['sumIsNotGreaterThanField']:'Total balance transfer amount should not be more than total balance owing';
						this.addError(isBypassed, emberId, errMsg, asideClass);
					} 
                break;					
            }
        }
    },


    displayCommonError: function (emberId1, emberId2, msg, targetDisplay) {
        $('#' + targetDisplay).after('<aside class="mix error_' + emberId1 + ' error_' + emberId2 + '"><div class="bigMustache">}</div><div class="errorIcon mix"></div><span id="mixed">' + msg + '</span></aside>');
        $('#' + emberId1 + ', #' + emberId2).addClass('error');
    },


    displayError: function (emberId, asideClass, msg) {
        var target = $('#' + emberId);
        var parent = target.parent();
        var errorHtml = '<aside class="error_' + emberId + ' ' + asideClass + '"><div class="errorIcon"></div><p>' + msg + '</p></aside>';

        if (parent.hasClass('formWrapper')) {
            parent.after(errorHtml);

        } else {
            target.addClass('error').after(errorHtml);
        }

    },


    addError: function (isBypassed, emberId1, msg, asideClass, emberId2, targetDisplay) {
        if (!isBypassed) {
            var aclass = asideClass || 'side';
            this.get('errorsContainer').addError(emberId1, msg);

            if (emberId2) {
                this.displayCommonError(emberId1, emberId2, msg, targetDisplay);

            } else {
                this.displayError(emberId1, aclass, msg);
            }

        }
    },


    removeError: function (emberId) {
        this.get('errorsContainer').removeError(emberId);
        $('#' + emberId).removeClass('error');
        $('aside.error_' + emberId).remove();
    },

    formatCurrency: function (intNum) {
        var intNumb = parseInt(intNum, 10);

        if (isNaN(intNumb)) {
            return '0';
        }

        var intStr = String(intNumb),
            strArr = intStr.split(''),
            arrLen = strArr.length,
            i = 1;

        for (i; arrLen > 3 * i; i++) {
            strArr.splice(arrLen - 3*i, 0, ',');
        }
        return '$' + strArr.join('');
    },

    addressValidated: function (response, field) {
        var addrValidated = null;

        if (response.Result) {
            var result = response.Result;
            var array = result.Street ? result.Street.split(' ') : null;
            var street = array ? array[0] : '';
            var streetType = array ? array[array.length - 1].toUpperCase() : '';

            if (array) {

                for (var i = 1; i < array.length - 1; i++) {
                    street = street + ' ' + array[i];
                }

            }

            if(streetType){
                if(!AppC.streetTypes.findProperty('code', streetType)){
                    streetType = "";
                }
            }

            var unitArray=result.Unit?result.Unit.split(' '):null;
            var unit='';
            if(unitArray){
            	if(unitArray.length>1){
            		unit=unitArray[1];
            	}else{
            		unit=unitArray[0];
            	}
            }
            if (field === 'address') {
            	
                this.set('unitNb', unit);
                this.set('streetNb', result.StreetNumber);
                this.set('street', street);
                this.set('streetType', streetType);
                this.set('suburb', result.Suburb);
                this.set('state', result.State);
                this.set('postcode', result.Postcode);

            } else {
                this.set(field + 'UnitNb', unit);
                this.set(field + 'StreetNb', result.StreetNumber);
                this.set(field + 'Street', street);
                this.set(field + 'StreetType', streetType);
                this.set(field + 'Suburb', result.Suburb);
                this.set(field + 'State', result.State);
                this.set(field + 'Postcode', result.Postcode);
            }

            switch (field) {

                case 'address':
                    addrValidated = 'addr1Validated';
                    break;

                case 'employerAddress':
                    addrValidated = 'addr2Validated';
                    break;

                case 'selfEmployerAddress':
                    addrValidated = 'addr3Validated';
                    break;

                case 'partnerAddress':
                    addrValidated = 'addr4Validated'

                case 'previousAddress':
                    addrValidated = 'addr5Validated';
                    break;

            }
        }

        // Display complex address
        this.set(addrValidated, true);
    },


    switchComplexAddr: function (addr) {

        var _this = this;
        var $input;
        var field;

        switch (addr) {

            case 1:
                field = 'address';
                break;

            case 2:
                field = 'employerAddress';
                break;

            case 3:
                field = 'selfEmployerAddress';
                break;

            case 4:
                field = 'partnerAddress';
                break;

            case 5:
                field = 'previousAddress';
                break;
        }

        $input = $('input[em-field="' + field + '"]');
        $input.addClass('ui-autocomplete-loading');
        //$('aside.error_' + $input.attr('id')).remove();

        if ($input.val()) {

            $.ajax({
                url: 'https://geocoderweb.veda.com.au/ValidateAddress',
                data: { address: $input.val() },
                dataType: "jsonp",

                success: function (response) {
                    $input.removeClass('ui-autocomplete-loading');
                    _this.addressValidated(response, field);
                },

                complete: function () {
                    _this.set('addr' + addr + 'Validated', true);
                }

            });

        } else {

            this.set('addr' + addr + 'Validated', true);
        }

    }


});
