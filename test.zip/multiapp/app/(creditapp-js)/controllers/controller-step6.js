/*****************************************************************************
 * CONTROLLER Step 6
 *****************************************************************************/


AppC.Step6Controller = AppC.StepController.extend(AppC.Nav, {

	actions: {
		refreshCaptcha: function() {
	    	this.get('controllers.jsonCaptchaRenew').run();
	    }
	},

    /**
     * Dependencies
     */


    needs: ['jsonSubmit','jsonCaptchaRenew','jsonCaptchaValidate', 'step5'],

    captchaLoaded: false,
    captchaUrlSuffix: '1',

    /**
     * Computed properties
     */

    homePhoneNum: function () {
        return AppC.step1Data.get('homePhone');
    }.property('AppC.step1Data.homePhone'),

    mobilePhoneNum: function () {
        return AppC.step1Data.get('mobilePhone');
    }.property('AppC.step1Data.mobilePhone'),


    isAusPassport: function(){
        return AppC.step3Data.get('photoId') === 'AP';
    }.property('AppC.step3Data.photoId'),

    isAusDriverLicence: function(){
        return AppC.step3Data.get('photoId') === 'DL';
    }.property('AppC.step3Data.photoId'),

    isIntPassport: function(){
        return AppC.step3Data.get('photoId') === 'IP'
    }.property('AppC.step3Data.photoId'),

    years: function () {
        return this.getPrettyCounter(parseInt(AppC.step4Data.get('years')), 'year');
    }.property('AppC.step4Data.years'),


    months: function () {
        return this.getPrettyCounter(parseInt(AppC.step4Data.get('months')), 'month');
    }.property('AppC.step4Data.months'),

    isOthers: function(){
        var es = AppC.step4Data.get('employmentStatus');
        if (es === 'O' || es === 'E' || es === 'H' || es === 'U' || es === 'R')
            return true;
        else
            return false;
    }.property('AppC.step4Data.employmentStatus'),

    isFullTime: function(){
        return AppC.step4Data.get('employmentStatus') === 'F';
    }.property('AppC.step4Data.employmentStatus'),

    isSelfEmp: function () {
        return AppC.step4Data.get('employmentStatus') === 'S';
    }.property('AppC.step4Data.employmentStatus'),

    hasPreviousAdd: function () {
        return AppC.step4Data.get('years') < 3 && (AppC.step4Data.get('previousAddressStreet') || AppC.step4Data.get('previousIntAddr1'));
    }.property('years', 'previousAddressStreet', 'previousIntAddr1'),


    empYears: function () {
        return this.getPrettyCounter(parseInt(AppC.step4Data.get('employeeYears')), 'year');
    }.property('AppC.step4Data.employeeYears'),


    empMonths: function () {
        return this.getPrettyCounter(parseInt(AppC.step4Data.get('employeeMonths')), 'month');
    }.property('AppC.step4Data.employeeMonths'),

    businessYears: function () {
        return this.getPrettyCounter(parseInt(AppC.step4Data.get('businessYears')), 'year');
    }.property('AppC.step4Data.businessYears'),

    businessMonths: function () {
        return this.getPrettyCounter(parseInt(AppC.step4Data.get('businessMonths')), 'month');
    }.property('AppC.step4Data.businessMonths'),

    hasExtraCard: function(){
        return AppC.step5Data.get('isJoint');
    }.property('AppC.step5Data.isJoint'),

    isLiveWith: function(){
        return AppC.step5Data.get('partnerHasSameAddress');
    }.property('AppC.step5Data.partnerHasSameAddress'),

    hasNoLimited: function(){
        return !AppC.step5Data.get('isLimited');
    }.property('AppC.step5Data.isLimited'),

    empAddress: function () {
        var unitNb = AppC.step4Data.get('employerAddressUnitNb') ? (AppC.step4Data.get('employerAddressUnitNb') + '/') : '';
        var streetNb = AppC.step4Data.get('employerAddressStreetNb') ? (AppC.step4Data.get('employerAddressStreetNb') + ' ') : '';
        var street = AppC.step4Data.get('employerAddressStreet');
        var streetType = AppC.streetTypes.getName(AppC.step4Data.get('employerAddressStreetType'));
        var suburb = AppC.step4Data.get('employerAddressSuburb');
        var state = AppC.step4Data.get('employerAddressState');
        var postcode = AppC.step4Data.get('employerAddressPostcode');

        return unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode;
    }.property('AppC.step4Data.employerAddressUnitNb', 'AppC.step4Data.employerAddressStreetNb', 'AppC.step4Data.employerAddressStreet', 'AppC.step4Data.employerAddressStreetType', 'AppC.step4Data.employerAddressSuburb', 'AppC.step4Data.employerAddressState', 'AppC.step4Data.employerAddressPostcode'),


    address: function () {
        var unitNb = AppC.step4Data.get('unitNb') ? (AppC.step4Data.get('unitNb') + '/') : '';
        var streetNb = AppC.step4Data.get('streetNb') ? (AppC.step4Data.get('streetNb') + ' ') : '';
        var street = AppC.step4Data.get('street');
        var streetType = AppC.streetTypes.getName(AppC.step4Data.get('streetType'));
        var suburb = AppC.step4Data.get('suburb');
        var state = AppC.step4Data.get('state');
        var postcode = AppC.step4Data.get('postcode');

        return unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode;
    }.property('AppC.step4Data.unitNb', 'AppC.step4Data.streetNb', 'AppC.step4Data.street', 'AppC.step4Data.streetType', 'AppC.step4Data.suburb', 'AppC.step4Data.state', 'AppC.step4Data.postcode'),


    previousAddress: function () {
        var unitNb = AppC.step4Data.get('previousAddressUnitNb') ? (AppC.step4Data.get('previousAddressUnitNb') + '/') : '';
        var streetNb = AppC.step4Data.get('previousAddressStreetNb') ? (AppC.step4Data.get('previousAddressStreetNb') + ' ') : '';
        var street = AppC.step4Data.get('previousAddressStreet');
        var streetType = AppC.streetTypes.getName(AppC.step4Data.get('previousAddressStreetType'));
        var suburb = AppC.step4Data.get('previousAddressSuburb');
        var state = AppC.step4Data.get('previousAddressState');
        var postcode = AppC.step4Data.get('previousAddressPostcode');

        return unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode;
    }.property('AppC.step4Data.previousAddressUnitNb', 'AppC.step4Data.previousAddressStreetNb', 'AppC.step4Data.previousAddressStreet', 'AppC.step4Data.previousAddressStreetType', 'AppC.step4Data.previousAddressSuburb', 'AppC.step4Data.previousAddressState', 'AppC.step4Data.previousAddressPostcode'),


    partnerAddress: function () {

        var unitNb = AppC.step5Data.get('partnerAddressUnitNb') ? (AppC.step5Data.get('partnerAddressUnitNb') + '/') : '';
        var streetNb = AppC.step5Data.get('partnerAddressStreetNb') ? (AppC.step5Data.get('partnerAddressStreetNb') + ' ') : '';
        var street = AppC.step5Data.get('partnerAddressStreet');
        var streetType = AppC.streetTypes.getName(AppC.step5Data.get('partnerAddressStreetType'));
        var suburb = AppC.step5Data.get('partnerAddressSuburb');
        var state = AppC.step5Data.get('partnerAddressState');
        var postcode = AppC.step5Data.get('partnerAddressPostcode');

        return unitNb + streetNb + street + ' ' + streetType + ', ' + suburb + ', ' + state + ' ' + postcode;
    }.property('AppC.step5Data.partnerAddressUnitNb', 'AppC.step5Data.partnerAddressStreetNb', 'AppC.step5Data.partnerAddressStreet', 'AppC.step5Data.partnerAddressStreetType', 'AppC.step5Data.partnerAddressSuburb', 'AppC.step5Data.partnerAddressState', 'AppC.step5Data.partnerAddressPostcode'),



    displayCards: function () {
        return AppC.step2Data.get('numOfCards') && AppC.step2Data.get('numOfCards')>0 && AppC.step2Data.get('cardNum1') && AppC.step2Data.get('balanceTransfer');
    }.property('AppC.step2Data.balanceTransfer','AppC.step2Data.numOfCards','AppC.step2Data.cardNum1'),




    checkNotEmpty: function (str) {
        return str ? str : '-';
    },


    getPrettyCounter: function (nb, counter) {
        switch (nb) {
            case 0:
                return '';
                break;

            case 1:
                return nb + ' ' + counter;
                break;

            default:
                return nb + ' ' + counter + 's';

        }

    },


    submitApp: function () {
        var errors = AppC.inputErrors;
        errors.clear();
        $('div.focusOut').trigger('focusout');

        if (errors.total()) {
            AppC.ux.scrollFirstError();

        } else {
            var submitting= this.get('controllers.jsonSubmit').get('submitting');
            if(!submitting){
                this.get('controllers.jsonSubmit').set('submitting',true);
                this.get('controllers.jsonSubmit').run();
            }else{
                alert('The form has been submitted, please wait for it to complete ...');
            }
        }

    },

    captchaUrl: function() {
	    var url='img/spinner.gif';
        if(this.get('captchaLoaded')){
            url=AppC.config.get('captchaUrlRoot')+'?key='+this.get('captchaUrlSuffix');
        }
        return url;
    }.property('captchaUrlSuffix','captchaLoaded'),

    

    refreshCaptchaUrl: function(){
        this.set('captchaUrlSuffix',Math.random());
    },

    setCaptchaLoadedTrue:function(){
        this.set('captchaLoaded',true);
    },

    goStep: function (step) {

        switch (step) {

            case 1:
                this.goRoute('step1');
                break;

            case 2:
                this.goRoute('step2');
                break;

            case 3:
                this.goRoute('step3');
                break;

            case 4:
                this.goRoute('step4');
                break;

            case 5:
                this.goRoute('step5');
                break;

        }

        AppC.ux.scrollTop();

    },

    displayPurpose: function () {
        return AppC.step1Data.get('loanPurpose') == 'OO' ? AppC.step1Data.get('loanOtherPurpose') : AppC.step1Data.get('purposeLong');
    }.property('AppC.step1Data.loanPurpose', 'AppC.step1Data.loanOtherPurpose'),

    displayLoanAmt: function () {
        return this.formatCurrency(AppC.step1Data.get('loanAmt'));
    }.property('AppC.step1Data.loanAmt')


});
