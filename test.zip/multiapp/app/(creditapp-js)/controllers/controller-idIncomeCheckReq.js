/*****************************************************************************
 * CONTROLLER
 *****************************************************************************/


AppC.IdIncomeCheckReqController = AppC.OutcomeController.extend({


    /**
     * Computed properties
     */

    radioTrue: function (field) {

        if (field === 'hsbcBranchThd') {
            this.set('hsbcBranchThd', true);
            this.set('ausPostFax', false);
            this.set('raName', false);
            $('div[em-field="ausPostFax"] div.radioButton[em-bool="true"]').removeClass('checked');
            $('div[em-field="raName"] div.radioButton[em-bool="true"]').removeClass('checked');

        } else if (field === 'ausPostFax') {
        	this.set('hsbcBranchThd', false);
        	this.set('ausPostFax', true);
            this.set('raName', false);
            $('div[em-field="hsbcBranchThd"] div.radioButton[em-bool="true"]').removeClass('checked');
            $('div[em-field="raName"] div.radioButton[em-bool="true"]').removeClass('checked');

        } else if (field === 'raName') {
            this.set('hsbcBranchThd', false);
            this.set('ausPostFax', false);
            this.set('raName', true);
            $('div[em-field="hsbcBranchThd"] div.radioButton[em-bool="true"]').removeClass('checked');
            $('div[em-field="ausPostFax"] div.radioButton[em-bool="true"]').removeClass('checked');
        }

    }
});
