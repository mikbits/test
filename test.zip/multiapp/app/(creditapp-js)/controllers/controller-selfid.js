/*****************************************************************************
 * CONTROLLER Self id page
 *****************************************************************************/


AppC.SelfIdController = AppC.StepController.extend({


    /**
     * Dependencies
     */

	actions: {
		submitIds: function () {
	        var errors = this.get('errorsContainer');

	        errors.clear();
	        this.validateIds();
	        $('input, select, div.focusOut').trigger('focusout');

	        if (errors.total()) {
	            AppC.ux.scrollFirstError();

	        } else {
	            AppC.set('refresh', false);
	            this.get('controllers.jsonSubmitIds').run();
	        }

	    }
	},

    needs: ['jsonSubmitIds'],


    /**
     * Computed properties
     */


    displayLicence: function () {
        return this.get('licenceState');
    }.property('licenceState'),


    licenceIsNsw: function () {
        return this.get('licenceState') === 'NSW';
    }.property('licenceState'),


    licenceIsWa: function () {
        return this.get('licenceState') === 'WA';
    }.property('licenceState'),


    licenceImg: function () {
        return 'img/dl-' + this.get('licenceState') + '.png';
    }.property('licenceState'),


    isOzPassport: function () {
        return this.get('photoId') === 'AP';
    }.property('photoId'),


    isIntPassport: function () {
        return this.get('photoId') === 'IP';
    }.property('photoId'),

    displayAusPassportInfo: function () {
        return this.get('ozPassportCountryBirth');
    }.property('ozPassportCountryBirth'),

    displayAusBirth: function () {
        return this.get('ozPassportCountryBirth') !== 'AUS';
    }.property('ozPassportCountryBirth'),

    isMedicareExpiryDateMMYYYY: function() {
        var result=false;
        if(this.get('medicareColor')==='G'){
            result=true;
        }
        return result;
    }.property('medicareColor'),

    isMedicareColorSelected: function() {
        if(this.get('medicareColor')){
            return true;
        }else{
            return false;
        }
    }.property('medicareColor') ,

    /**
     * Methods
     */


    checkboxClick: function (field) {

        this.validateIds();

    },


    validateIds: function () {
        var selfIdData = AppC.selfIdData;
        this.removeError('selfIdLabel');

        if ($('.checked').length === 0) {

            this.addError(false, 'selfIdLabel', 'Required', 'side');
        }
    },

    /**
     * Observers
     */

    medicareColorChangeded: function() {
        if(this.get('medicareColor')==='G'){
            if(this.get('medicareExpiryDate') && !this.get('medicareExpiryDate').match(/^[0-9][0-9]\/[0-9][0-9][0-9][0-9]/g)){
                var matches=this.get("medicareExpiryDate").match(/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/g);
                if(matches) {
                    this.set('medicareExpiryDate',matches[0]);
                }
            }
        }else{
            if(this.get('medicareExpiryDate') && !this.get('medicareExpiryDate').match(/^[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/g)){
                this.set('medicareExpiryDate','');
            }
        }
    }.observes('medicareColor')
});
