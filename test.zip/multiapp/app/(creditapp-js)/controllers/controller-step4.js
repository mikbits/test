/*****************************************************************************
 * CONTROLLER Step 4
 *****************************************************************************/


AppC.Step4Controller = AppC.StepController.extend({


    /**
     * Computed properties
     */


    geoCoder1: Em.computed.alias('content.geoCoder1'),
    geoCoder2: null,
    geoCoder3: null,
    geocoder5: null,

    openCoverWW: function () {
        AppC.ux.openModal('cardCoverWW');
    },

    openCDF: function () {
        AppC.ux.openModal('cdf');
    },

    openCover: function () {
        AppC.ux.openModal('cardCover');
    },

    displayGeoCoder1: function () {
        return AppC.vedaResponse.get('ajaxStatus') && !this.get('addr1Validated');
    }.property('AppC.vedaResponse.ajaxStatus', 'addr1Validated'),

    displayGeoCoder2: function () {
        return AppC.vedaResponse.get('ajaxStatus') && !this.get('addr2Validated');
    }.property('AppC.vedaResponse.ajaxStatus', 'addr2Validated'),

    displayGeoCoder3: function () {
        return AppC.vedaResponse.get('ajaxStatus') && !this.get('addr3Validated');
    }.property('AppC.vedaResponse.ajaxStatus', 'addr3Validated'),

    displayGeoCoder5: function () {
        return AppC.vedaResponse.get('ajaxStatus') && !this.get('addr5Validated');
    }.property('AppC.vedaResponse.ajaxStatus', 'addr5Validated'),


    displayEmployStatus: function () {
        var emp = this.get('employmentStatus');
        if (emp === 'E' || emp === 'H' || emp === 'R' || emp === 'U' || !emp)
            return false;
    }.property('employmentStatus'),

    displayEmployed: function () {
        var emp = this.get('employmentStatus');
        if (emp === 'F' || emp === 'P' || emp === 'A' || emp === 'O' || emp === 'C')
            return true;
    }.property('employmentStatus'),

    displayContract: function () {
        return this.get('employmentStatus') === 'C';
    }.property('employmentStatus'),


    displaySelfEmployed: function () {
        return this.get('employmentStatus') === 'S';
    }.property('employmentStatus'),

    displayPreAddr: function () {
        return this.get('years') < AppC.get('previousAddressTrigger') && this.get('years');
    }.property('years'),

    /**
     * Events
     */

    employerOutAus: function(){
        this.set('isEmpOutAdd', 'true');
    },

    computeYearsMonths: function () {
        return this.computeYears('years', 'months');
    },

    computeEmployYearsMonths: function () {
        return this.computeYears('employeeYears', 'employeeMonths');
    },

    computeContYearsMonths: function () {
        return this.computeYears('contractLengthYears', 'contractlengthMonths')
    },

    computeBusYearsMonths: function () {
        return this.computeYears('businessYears', 'businessMonths')
    },

    inputFocusOut: function (e) {
        var target = $(e.target);
        var emField = target.attr('em-field');

        if (emField === 'months') {

            if (target.val()) {
                this.computeYearsMonths();
            }

        } else if (emField === 'employeeMonths') {

            if (target.val()) {
                this.computeEmployYearsMonths();
            }

        } else if (emField === 'contractlengthMonths') {

            if (target.val()) {
                this.computeContYearsMonths();
            }

        } else if (emField === 'businessMonths') {

            if (target.val()) {
                this.computeBusYearsMonths();
            }

        } else if (emField === 'years') {
            var years = target.val();

            if (years) {
                var months = $('input[em-field="months"]');

                if (AppC.validationController.hasOnlyDigits(years)) {
                    if (!months.val()) {
                        AppC.step4Data.set('months', 0);
                        months.val(0).trigger('focusout');
                    }

                }
            }

        } else if (emField === 'employeeYears') {
            var EmployYears = target.val();

            if (EmployYears) {
                var EmployMonths = $('input[em-field="employeeMonths"]');

                if (AppC.validationController.hasOnlyDigits(EmployYears)) {

                    if (!EmployMonths.val()) {
                        AppC.step4Data.set('employeeMonths', 0);
                        EmployMonths.val(0);
                    }
					if(EmployYears === '0' && EmployMonths.val() === '0'){
						EmployMonths.trigger('focusout');
					}

                }
            }
        } else if (emField === 'contractLengthYears') {
            var ContYears = target.val();

            if (ContYears) {
                var ContMonths = $('input[em-field="contractLengthMonths"]');

                if (AppC.validationController.hasOnlyDigits(ContYears)) {

                    if (!ContMonths.val()) {
                        AppC.step4Data.set('contractLengthMonths', 0);
                        ContMonths.val(0);
                    }
					if(ContYears === '0' && ContMonths.val() === '0'){
						ContMonths.trigger('focusout');
					}

                }
            }
        } else if (emField === 'businessYears') {
            var busYears = target.val();

            if (busYears) {
                var busMonths = $('input[em-field="businessYears"]');

                if (AppC.validationController.hasOnlyDigits(busYears)) {

                    if (!busMonths.val()) {
                        AppC.step4Data.set('businessYears', 0);
                        busMonths.val(0).trigger('focusout');
                    }

                }
            }
        }
    }


});
