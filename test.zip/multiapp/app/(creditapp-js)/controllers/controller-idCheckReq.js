/*****************************************************************************
 * CONTROLLER
 *****************************************************************************/


AppC.IdCheckReqController = AppC.OutcomeController.extend(AppC.OutcomeStatusMixin, {


    /**
     * Computed properties
     */


    radioTrue: function (field) {

        if (field === 'hsbcBranch') {
            this.set('hsbcBranch', true);
            this.set('ausPost', false);
            this.set('raName', false);
            $('div[em-field="ausPost"] div.radioButton[em-bool="true"]').removeClass('checked');
            $('div[em-field="raName"] div.radioButton[em-bool="true"]').removeClass('checked');

        } else if (field === 'ausPost') {
        	this.set('hsbcBranch', false);
        	this.set('ausPost', true);
            this.set('raName', false);
            $('div[em-field="hsbcBranch"] div.radioButton[em-bool="true"]').removeClass('checked');
            $('div[em-field="raName"] div.radioButton[em-bool="true"]').removeClass('checked');

        } else if (field === 'raName') {
            this.set('hsbcBranch', false);
            this.set('ausPost', false);
            this.set('raName', true);
            $('div[em-field="hsbcBranch"] div.radioButton[em-bool="true"]').removeClass('checked');
            $('div[em-field="ausPost"] div.radioButton[em-bool="true"]').removeClass('checked');
        }

    }

});
