/*****************************************************************************
 * CONTROLLER Step 5
 *****************************************************************************/


AppC.Step5Controller = AppC.StepController.extend(AppC.DebitCards, {


    /**
     * Methods
     */

    validate: function (e) {

        function removeReq (arr) {
            for (var i = 0; arr[i]; i++) {
                if (arr[i] === 'req' || arr[i] === 'sreq') {
                    arr.splice(i, i + 1);
                    return arr.join(' ');
                }
            }
        }

        function addReq (arr) {

            var count = 0;

            for (var i = 0; arr[i]; i++) {
                if (arr[i] === 'req' || arr[i] === 'sreq') {
                    count++;
                }
            }

            if (count === 0) {
                arr.splice(0, 1, 'req');
            }

            return arr.join(' ');

        }

        function specialActionforHouseOwner () {
            if (rStatus !== 'O') {
                tempStr = removeReq(emValidArr);
            } else {
                tempStr = addReq(emValidArr);
            }
            emValid = target.attr('em-valid', tempStr);
        }

        var target = $(e.target),
            emberId = e.target.id,
            isBypassed = target.parents('div.blockToggle').hasClass('destroyed'),
            value = target.val(),
            rStatus = AppC.step5Data.residentialStatus,
            emValid = target.attr('em-valid'),
            emValidArr = emValid.split(' '),
            emField = target.attr('em-field'),
            asideClass = target.attr('em-aside'),
            errMsg = 'Please enter',
            tempStr;

        this.removeError(emberId);

        this._super(e);

    },

    showPartner: function () {
        var mStatus = AppC.step3Data.maritalStatus;
        if (mStatus === 'M' || mStatus === 'FC' || mStatus === 'FD') {
            return true;
        }
        return false;
    }.property('AppC.step3Data.maritalStatus'),

    showIntMobilePhone: function () {
        return this.get('isIntMobilePhone');
    }.property('isIntMobilePhone'),

    showIntHomePhone: function () {
        return this.get('isIntHomePhone');
    }.property('isIntHomePhone'),

    displayGeoCoder4: function () {
        return AppC.vedaResponse.get('ajaxStatus') && !this.get('addr4Validated');
    }.property('AppC.vedaResponse.ajaxStatus', 'addr4Validated'),

    partnerOutAus: function(){
        this.set('isPartnerOutAdd', true);
    },

    showRewCardNum: function () {
        return this.get('partnerCustRewardInd');
    }.property('partnerCustRewardInd')

});
