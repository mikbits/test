/*****************************************************************************
 * CONTROLLER Application
 *****************************************************************************/


AppC.ApplicationController = Ember.Controller.extend(AppC.Nav, {



    /**
     * Dependencies
     */


    needs: ['jsonSave','jsonGetServerDate'],


    /**
     * Methods
     */

    goStep: function (currentStep, nextStep, submit) {

        if ((currentStep != 1 && submit != true && currentStep === AppC.getLastSavedStep() + 1) || AppC.get('isStep' + currentStep + 'Dirty') === false) {
            // If user is ediding the last step and didn't push "Save and Continue", or current step is not dirty, just re-route without validation/ajax
            this.send('goToStep', nextStep);

        } else {
            // Reset errors
            var errors = AppC.inputErrors;
            errors.clear();

            // Trigger all validation
            $('input, select, div.focusOut').trigger('focusout');

            if (errors.total()) {
                AppC.ux.scrollFirstError();

            } else {
                AppC.set('hasSavedStep' + currentStep, true);
                this.get('controllers.jsonSave').run();
                if(currentStep === 1) {
                    AppC.setBusy();
                    AppC.set('isBusy', false);
                    AppC.nothingDirtyUntil(currentStep); //TBC
                    this.send('goToStep', nextStep);
                 }else{
                    AppC.nothingDirtyUntil(currentStep);
                    this.send('goToStep', nextStep);
                 }
            }

        }

    },

    isStep1Loan: function() {
        if (AppC.get('isLoan') && AppC.get('isStep1')) {
            return true;
        } else  {
            return false;
        }
    }.property('AppC.isLoan', 'AppC.isStep1'),


    refreshServerDate: function () {
        this.get('controllers.jsonGetServerDate').run();
    }


});
