/*****************************************************************************
 * CONTROLLER Step 2
 *****************************************************************************/


AppC.Step2Controller = AppC.StepController.extend({

	actions: {
		openModal: function (id) {
	        AppC.ux.openModal(id);
	    }
	},

    /**
     * Properties
     */

    selectedCustomer: function () {
        return typeof(this.get('isCustomer')) != 'object';
    }.property('isCustomer'),


    computeYearsMonths: function () {
        return this.computeYears('timeMBankYear', 'timeMBankMonth');
    },


    computePartnerYearsMonths: function () {
        return this.computeYears('partnerYears', 'partnerMonths');
    },


    inputFocusOut: function (e) {
        var target = $(e.target);
        var emField = target.attr('em-field');
        var lastAddress = $('div#lastAddress');
        var partnerLastAddress = $('div#partnerLastAddress');

        if (emField === 'timeMBankMonth') {
            if (target.val()) {
            	this.computeYearsMonths();
            }

        } else if (emField === 'partnerMonths') {
            if (target.val()) {
                this.computePartnerYearsMonths();
            }
        } else if (emField === 'numOfCards') {
            if(parseInt(target.val()) == 1){
                this.set('currentCard', 1);
            }
            else if(parseInt(target.val()) == 2 && this.get('currentCard') >= 2){
                this.set('currentCard', 2);
            }
        }
    },


    radioTrue: function (emField) {
        if (emField === 'balanceTransfer') $('div#balanceTransferCards').removeClass('destroyed');
    },

    radioFalse: function (emField) {
        if (emField === 'balanceTransfer') $('div#balanceTransferCards').addClass('destroyed');
    }

    

});
