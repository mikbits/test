/*****************************************************************************
 * CONTROLLER Retrieve
 *****************************************************************************/


AppC.RetrieveController = AppC.StepController.extend({


    /**
     * Dependencies
     */
	actions: {
		retrieve: function () {
	        var errors = AppC.inputErrors;
	        var option = this.get('option');

	        // Reset errors
	        errors.clear();

	        // Trigger all validation by keyup
	        $('input.option' + option).trigger('focusout');

	        if (!errors.total() && option) {
	            AppC.set('refresh', false);
	            AppC.set('refreshStep1', true);
	            this.get('controllers.jsonRetrieve').run();
	        }

	    }
	},


    needs: ['jsonRetrieve'],


    /**
     * Computed properties
     */


    isOption1: function () {
        return this.get('option') === 1;
    }.property('option'),


    isOption2: function () {
        return this.get('option') === 2;
    }.property('option'),


    notFoundOption1: function () {
        return (this.get('option') === 1) && this.get('notFound');
    }.property('option', 'notFound'),


    notFoundOption2: function () {
        return (this.get('option') === 2) && this.get('notFound');
    }.property('option', 'notFound'),


    /**
     * Observers
     */


    optionSelected: function () {
        this.activateOption(this.get('option'));
    }.observes('option'),


    /**
     * Methods
     */


    setOption1: function () {
        this.set('option', 1);
    },


    setOption2: function () {
        this.set('option', 2);
    },


    activateOption: function (option) {
        var disabledOption = option === 1 ? 2 : 1;

        $('input.option' + option).removeClass('disabled');
        $('input.option' + disabledOption).addClass('disabled').removeClass('error').next('aside').remove();
    }


    


});
