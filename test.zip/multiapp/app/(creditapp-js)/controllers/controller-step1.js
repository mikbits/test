/*****************************************************************************
 * CONTROLLER Mother class step 1
 *****************************************************************************/


AppC.Step1Controller = AppC.StepController.extend(AppC.DebitCards, {

	actions: {
		ShowSel: function () {
	        if (this.get('isShowSel')) {
	            this.set('isShowSel', false);
	        } else {
	            this.set('isShowSel', true);
	        }
	    },
	    scrollToName: function () {
	        // Reset errors
	        var errors = AppC.inputErrors;
	        errors.clear();

	        // Trigger validation
	        $(".namesForm").find('input, select').trigger('focusout');
	        $(".calculatorOuter").find('input, select, div.focusOut').trigger('focusout');

	        if (errors.total()) {
	            AppC.ux.scrollFirstError();
	        } else {
	            this.set('isHappy', true);
	            $(".detailForm").find('input, select').prop('disabled', false);
	            AppC.ux.scrollToEl($('.detailForm'));
	        }
	    },
	    changeHappy: function () {

	        // Reset errors
	        var errors = AppC.inputErrors;
	        errors.clear();

	        // Trigger validation
	        $(".namesForm").find('input, select').trigger('focusout');
	        $(".calculatorOuter").find('input, select, div.focusOut').trigger('focusout');

	        if (errors.total()) {

	            AppC.ux.scrollFirstError();

	        } else {

	            if (!this.get('isHappy')) {
	                $(".namesForm").find('input, select').removeAttr('disabled');
	                $(".detailForm").find('input, select').removeAttr('disabled');
	                this.set('isHappy', true);
	                AppC.ux.scrollToEl($('.detailForm'));
	            } else {
	                $(".namesForm").find('input, select').removeAttr('disabled');
	                $(".detailForm").find('input, select').removeAttr('disabled');
	                this.set('isHappy', false);
	                AppC.ux.scrollToEl($('.cardName'));
	            }

	        }
	    },
	    loginAndApply: function () {
	        window.open('https://www.hsbc.com.au/1/2/HUB_IDV2/FUSED_EPP?__EntryPage=hubpib.applicationcentre.landing');
	    },
	    printPolicy: function () {
	        var w = window.open('', 'HSBCPrivacyPolicy', 'height=700,width=1000');

	        w.document.write('<html><head><title>' + $('div#privacyPolicy h3').html() + '</title>');
	        w.document.write('</head><body >');
	        w.document.write($('div#privacyPolicy').html());
	        w.document.write('</body></html>');

	        w.print();
	    }
	},
	
    /**
     * Properties
     */


    isHappy: false,
    retryTimes: 0,


    /**
     * Computed properties
     */


    isIndividual: function () {
        var isJoint = this.get('isJoint');
        return isJoint === null ? false : !isJoint;
    }.property('isJoint'),

    isBodyDisplayed: function () {
        var isJoint = this.get('isJoint');
        var isCustomer = this.get('isCustomer');

        if (!this.hasCustomerCheck(AppC.get('bundle'))) {
            return isJoint !== null;
        } else {
            return isJoint ? true : isCustomer === false;
        }
    }.property('isJoint', 'isCustomer'),


    /**
     * Observers
     */

    currentDateOb: function () {

        var _this = this,
            data = AppC.step1Data,
            serverDate = AppC.validationController.serverDate,
            dateArray,
            month,
            year,
            laterYear;

        if ($('p.textOnCard').length === 0) {
            return;
        }

        if ((!data || !serverDate) && this.retryTimes < 100) {
            setTimeout(function () {
                _this.currentDateOb();
            }, 1000);
            this.retryTimes++;
            return;
        }

        dateArray = serverDate.split('/');
        month = dateArray[1];
        year = dateArray[2].slice(-2);
        laterYear = year;

        if (laterYear.slice(0,1) === '0') {
            laterYear = '0' + (parseInt(laterYear, 10) + 3);
        } else {
            laterYear = String(parseInt(laterYear, 10) + 3);
        }

        data.set('currentDate', month + '/' + year);
        data.set('threeYearsLater', month + '/' + laterYear);

    }.observes('AppC.validationController.serverDate'),


    titleHasChanged: function () {
        var title = this.get('title');

        if (title === 'Sir' || title === 'Mr') {
            AppC.step3Data.set('gender', 'M');
        } else if (title === 'Ldy' || title === 'Mrs' || title === 'Ms' || title === 'Mis') {
            AppC.step3Data.set('gender', 'F');
        }

    }.observes('title'),


    /**
     * Methods
     */

    
    


    inputKeyUp: function (e) {
        var target = $(e.target);
        var field = target.attr('em-field');

        if (this.get('emailConfirm') && field === 'email') {
            $('input[em-field="emailConfirm"]').keyup();
        }

    },

    openPrivacyPolicy: function () {
        AppC.ux.openModal('privacyPolicy');
    },


    openWhyDebitCard: function () {
        AppC.ux.openModal('whyDebitCard');
    },


    radioTrue: function (emField) {

        var data = AppC.getCurrentStepData(),
            pathPrefix = './images/';

        $('.editCard').find('.radioButton').removeClass('checked');
        data.set('isBlack', false);
        data.set('isBlue', false);
        data.set('isPink', false);
        data.set('isGreen', false);


        switch (emField) {

            case 'isBlack':
            data.set('isBlack', true);
            $('[em-field="isBlack"]').find('div[em-bool="true"]').addClass('checked');
            AppC.set('imgFileName', pathPrefix + 'cardBlack.png');
            break;

            case 'isBlue':
            data.set('isBlue', true);
            $('[em-field="isBlue"]').find('div[em-bool="true"]').addClass('checked');
            AppC.set('imgFileName', pathPrefix + 'cardBlue.png');
            break;

            case 'isPink':
            data.set('isPink', true);
            $('[em-field="isPink"]').find('div[em-bool="true"]').addClass('checked');
            AppC.set('imgFileName', pathPrefix + 'cardPink.png');
            break;

            case 'isGreen':
            data.set('isGreen', true);
            $('[em-field="isGreen"]').find('div[em-bool="true"]').addClass('checked');
            AppC.set('imgFileName', pathPrefix + 'cardGreen.png');
            break;

        }

    },


    radioFalse: function (emField) {

    },


    selectChange: function (e) {
        var target = $(e.target);
        var emField = target.attr('em-field');
        var value = target.val();

        if (emField === 'multiCurrencyMain') {
            this.updateCurrencies(value);
        }

        if (emField === 'loanPurpose') {
            if (this.get('loanPurpose')) {
                this.set('isShowSel', false);
            }
        }

    },


    saveDate: function (field, value) {
        this.set('birthDate', value);
    },


    


    

    showProductChange: function () {
        return !AppC.get('isInRa') && !AppC.get('isWoolworths') && !AppC.get('isLoan');
    }.property('AppC.isInRa', 'AppC.isWoolworths', 'AppC.isLoan'),

    showChange: function () {
        return AppC.get('isLoan') && this.get('isShowSel');
    }.property('AppC.isLoan', 'isShowSel'),

    showOther: function () {
        return this.get('loanPurpose') == 'OO';
    }.property('AppC.isLoan', 'loanPurpose'),

    

    showNewOrUsed: function () {
        return this.get('loanPurpose') == "1" || this.get('loanPurpose') == "2";
    }.property('loanPurpose'),

    showConsolidate: function () {
        return this.get('loanPurpose') == "7";
    }.property('loanPurpose')

});
