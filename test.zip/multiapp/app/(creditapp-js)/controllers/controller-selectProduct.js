/*****************************************************************************
 * CONTROLLER Select Product
 *****************************************************************************/


AppC.SelectProductController = AppC.StepController.extend(AppC.Nav, {

    logoPic: function () {
		//alert("SelectProductController.logoPic");
        function setBg () {
            $('#raImgBg').css('background-image', 'url(' + AppC.get('raImgBg') + ')');
        }

        var _this = this,
            id = AppC.get('merchantGroupId'),
            prefix = 'images/ra/',
            lgSuffix = '/step0-logo.png',
            bgSuffix = '/step0-bg.png',
            logoPath = prefix + id + lgSuffix,
            bgPath = prefix + id + bgSuffix,
            dLogoPath = prefix + '999' + lgSuffix,
            dBgPath = prefix + '999' + bgSuffix;

        if (!id) {

            setTimeout(function () {
                _this.logoPic();
            }, 50);
            return;

        }

        AppC.set('isInRa', true);

        // check image files existence
        $.ajax({
            type: 'GET',
            url: logoPath,
            // files exist
            success: function () {
                AppC.set('logoImg', logoPath);
                AppC.set('raImgBg', bgPath);
                setBg();
            },
            // files do NOT exist, default HSBC logo
            error: function (xhr) {
                AppC.set('logoImg', dLogoPath);
                AppC.set('raImgBg', dBgPath);
                setBg();
            }
        });


    },

    radioTrue: function (emField) {
    },

    radioFalse: function (emField) {
    },

	actions: {
		completeForm: function () {

	        var errors = this.get('errorsContainer');

	        errors.clear();

	        $('input, select, .focusOut').trigger('focusout');

	        if (errors.total()) {
	            AppC.ux.scrollFirstError();

	        } else {
	            AppC.set('refresh',true);
	            this.get('controllers.jsonSubmitSelectProduct').run();
	            //this.send('goToStep', 1);
	        }

	    }
	},

    needs: ['jsonSubmitSelectProduct', 'jsonEntry'],


    /**
     * Methods
     */

    entryReq: function () {
        this.get('controllers.jsonEntry').run();
    },

    logoPicBranch: function () {
        AppC.set('isInRa', false);
        AppC.set('logoImg', 'images/logo.png');
    }
});
