/*****************************************************************************
 * CONTROLLER UX
 *****************************************************************************/


AppC.Ux = Ember.Object.extend({


    /**
     * Methods
     */

    scrollToEl: function (tar) {
        $('html, body').animate({scrollTop: tar.offset().top}, AppC.get('scrollSpeed') * 1.5);
    },

    scrollHeader: function () {
        $('html, body').animate({scrollTop: 450}, AppC.get('scrollSpeed'));
    },


    scrollTop: function () {
        $('html, body').animate({scrollTop: 0}, 1);
    },


    scrollFirstError: function () {
        var offsetTop = $('aside').first().offset().top;
        $('html, body').animate({scrollTop: offsetTop - 80}, AppC.get('scrollSpeed'));
    },


    openModal: function (id) {
        $('div#' + id).modal({focus: false, closeHTML: '<a class="modalCloseImg"></a>'});
    }


});


AppC.ux = AppC.Ux.create();
