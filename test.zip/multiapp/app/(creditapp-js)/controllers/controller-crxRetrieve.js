
AppC.CrxRetrieveController = Ember.ObjectController.extend(AppC.Nav, {

    needs: ['jsonCrxRetrieve'],

    crxRetrieve: function () {
        this.get('controllers.jsonCrxRetrieve').run();
    }

});

