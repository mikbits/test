AppC.ActionstepController = Ember.ObjectController.extend(AppC.OutcomeStatusMixin, {
	
});