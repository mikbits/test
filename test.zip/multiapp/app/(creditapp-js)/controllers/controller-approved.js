/*****************************************************************************
 * CONTROLLER
 *****************************************************************************/


AppC.ApprovedController = AppC.OutcomeController.extend(AppC.Nav, AppC.OutcomeStatusMixin, {
	actions: {
		backToMerchant: function () {
        	//alert(this.get('redirectURL'));
    		window.opener.location.href=this.get('redirectURL');
    		window.close();
	    }
	}

});
