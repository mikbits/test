/*****************************************************************************
 * CONTROLLER Validation
 *****************************************************************************/


AppC.ValidationController = Ember.Object.extend({

    /**
     * properties
     */
    serverDate: null,


    /**
     * Validation methods
     */

    Max21: function (value) {
        return value <=21
    },

    isMin: function (value, min) {
        var string = value || '';
        return string.length >= min;
    },

    isInformed: function (value) {
        var string = value || '';
        return string.length >= 1;
    },


    isName: function (value) {
        return /^[\sa-zA-Z'-]*$/.test(value);
    },


    isEmail: function (value) {
        return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,6})+$/.test(value);
    },


    isHomePhone: function (value) {
        return /^((02)|(03)|(07)|(08))-\d{4}-\d{4}$/.test(value);
    },


    isMobilePhone: function (value) {
        return /^((04)|(05))\d\d-\d{3}-\d{3}$/.test(value);
    },
	
	isAllPhone: function (value) {
        return /^((02)|(03)|(04)|(05)|(07)|(08))-\d{4}-\d{4}$/.test(value);
    },
	
    isIntPhone: function (value) {
        return /^\d{3}-\d{12}$/.test(value);
    },


    hasSpace: function (value) {
        return /\s/g.test(value);
    },


    hasDigit: function (value) {
        return /\d/g.test(value);
    },


    hasOnlyDigits: function (value) {
        return /^[\d\s]*$/.test(value);
    },


    hasOnlyDigitsStrict: function (value) {
        return /^[\d]*$/.test(value);
    },


    hasOnlyLetters: function (value) {
        return /^[a-zA-Z\s]*$/.test(value);
    },


    hasOnlyDigitsAndLetters: function (value) {
        return /^[a-zA-Z0-9\s]*$/.test(value);
    },


    isDate: function (value) {
        var userInputDate=moment(value, 'DD/MM/YYYY');
        var result = false;
        if(userInputDate && userInputDate.isValid()){
            result = true;
        }
        return result;
    },
    
    isDateMMYYYY: function (value) {
        var userInputDate=moment(value, 'MM/YYYY');
        var result = false;
        if(userInputDate && userInputDate.isValid()){
            result = true;
        }
        return result;
    },    

    ageLessThan100: function (value) {
        var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
        var userInputDate=moment(value, 'DD/MM/YYYY');
        var result=false;
        if(userInputDate){
            var age = now.diff(userInputDate, 'years');
            if(age <100){
                result= true;
            }
        }
        return result;
    },

    is18: function (value) {
        var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
        var userInputDate=moment(value, 'DD/MM/YYYY');
        var result=false;
        if(userInputDate){
            var age = now.diff(userInputDate, 'years');
            if(age >=18){
                result= true;
            }
        }
        return result;
    },

    notExpired: function (value) {
    	var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
    	var userInputDate=moment(value, 'DD/MM/YYYY');
    	var result=false;
    	if(userInputDate){
    		if(userInputDate.diff(now, 'days') > 0){
    			result= true;
    		}
    	}
    	return result;
    },
    

    notExpiredMMYYYY: function (value) {
    	var now = moment();
        if(this.get('serverDate')){
            now=moment(this.get('serverDate'),'DD/MM/YYYY');
        }
    	var userInputDate=moment(value, 'MM/YYYY');
    	var result=false;
    	if(userInputDate){
    		if(userInputDate.diff(now, 'months') > 0){
    			result= true;
    		}
    	}
    	return result;
    },


    isStreetNb: function (value) {
        return /^[a-zA-Z0-9\s\-]*$/.test(value);
    },

    pobox: function (value) {
        return !(value.replace(/\W/g, '').toLowerCase().indexOf('pobox') > -1);
    },

    isLessThanField: function (value, fieldName) {
        var tarValue = $('input[em-field="' + fieldName + '"]').val();
        return (parseInt(value, 10) < parseInt(tarValue, 10));
    },


    isNotGreaterThanField: function (value, fieldName) {
        var tarValue = $('input[em-field="' + fieldName + '"]').val();
        return (parseInt(value, 10) <= parseInt(tarValue, 10));
    },

   

    sumIsNotGreaterThanField: function (value, fieldNames) {
        var fieldNameAry = fieldNames.split('_');
        var tarValue = $('input[em-field="' + fieldNameAry[0] + '"]').val();
        var sum = parseInt(value, 10);
        for(var i = 1; i < fieldNameAry.length; i++){
            sum += $('input[em-field="' + fieldNameAry[i] + '"]').val()? parseInt($('input[em-field="' + fieldNameAry[i] + '"]').val(), 10) : 0;
        }
        return (sum <= parseInt(tarValue, 10));
    },


    isNotGreaterThan: function (value, tarValue) {
        return (value <= parseInt(tarValue, 10));
    },

    lengthEither: function(value, lengthVals){
        var lengthAry = lengthVals.split('_');
        for(var i = 0; i < lengthAry.length; i++){
            if(value.length === parseInt(lengthAry[i])){
                return true;
            }
        }
        return false;
    },

    isNotLessThan: function(value, tarValue){
        return (parseInt(value, 10) >= parseInt(tarValue, 10));
    },

    notCusPL: function () {
    	var result=(AppC.bundle == 6 && !AppC.step2Data.isCustomer);
    	if(!result){
    		if(AppC.isLoan){
    			if(!AppC.step2Data.isCustomer){
    				result=true;
        			var campaignCode=AppC.marketCode.substring(0,4)+AppC.loanTerm+AppC.marketCode.substring(6,8);
        			if('WZXO60NN' === campaignCode || 'WZXB60NN' === campaignCode){
        				result=false;
        			}
    			}
    		}
    	}
        return result;
    },

    notAuRA: function () {
        return AppC.isInRa && !AppC.step3Data.isResident;
    }


});


AppC.validationController = AppC.ValidationController.create();
