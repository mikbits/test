AppC.OnlineCalUsController = Ember.ObjectController.extend(AppC.OutcomeStatusMixin, {
	
}); 