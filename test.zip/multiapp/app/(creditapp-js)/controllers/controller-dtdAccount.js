/*****************************************************************************
 * CONTROLLER Day to Day Account Page
 *****************************************************************************/


AppC.DtdAccountController = AppC.OutcomeController.extend(AppC.Nav, {

    needs: ['jsonDtdSave'], 	

    nationalityCountries2: [],
    nationalityCountries3: [],
	
     init:function(){
        this._super();
        if (this.get("nationalityCountries2").length) this.get("nationalityCountries2").removeAt(0, this.get("nationalityCountries2").length);
        this.get("nationalityCountries2").addObjects(AppC.countries.get("content"));
        if (this.get("nationalityCountries3").length) this.get("nationalityCountries3").removeAt(0, this.get("nationalityCountries3").length);
        this.get("nationalityCountries3").addObjects(AppC.countries.get("content"));
     },	

	actions: {
		openModal: function (id) {
	        AppC.ux.openModal(id);
	    },
	    validateGo: function (str) {
	        // Reset errors
	        var errors = AppC.inputErrors;
	        errors.clear();

	        // Trigger all validation
	        $('input, select, div.focusOut').trigger('focusout');

	        if (errors.total()) {
	            AppC.ux.scrollFirstError();
	        } else {
	            this.send('goToStep', str);
	            if (AppC.isDtdDirty) {
	                this.get('controllers.jsonDtdSave').run();
	            }
	        }
	    }
	},
	
    nationalityChanged: function(){
        var nationality=this.get('nationality');
        var nationality2=this.get('nationality2');
        var nationality3=this.get('nationality3');
        if (this.get("nationalityCountries2").length) this.get("nationalityCountries2").removeAt(0, this.get("nationalityCountries2").length);
        this.get("nationalityCountries2").addObjects(AppC.countries.get("content"));
        this.get('nationalityCountries2').removeObject(this.get('nationalityCountries2').findBy('code',nationality));

        if (this.get("nationalityCountries3").length) this.get("nationalityCountries3").removeAt(0, this.get("nationalityCountries3").length);
        this.get("nationalityCountries3").addObjects(AppC.countries.get("content"));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality2));

        if(nationality2 === nationality) nationality2=null;
        if(nationality3 === nationality) nationality3=null;
        this.set('nationality2', nationality2);
        this.set('nationality3', nationality3);

    }.observes('nationality'),


    nationality2Changed: function(){
        var nationality=this.get('nationality');
        var nationality2=this.get('nationality2');
        var nationality3=this.get('nationality3');
        if (this.get("nationalityCountries3").length) this.get("nationalityCountries3").removeAt(0, this.get("nationalityCountries3").length);
        this.get("nationalityCountries3").addObjects(AppC.countries.get("content"));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality));
        this.get('nationalityCountries3').removeObject(this.get('nationalityCountries3').findBy('code',nationality2));

        if(nationality3 === nationality || nationality3 === nationality2) nationality3=null;;
        this.set('nationality3', nationality3);
    }.observes('nationality2'), 


    nationality3Changed: function(){
        var nationality3=this.get('nationality3');
        if(nationality3 === 'seperator') nationality3=null;;
        this.set('nationality3', nationality3);
    }.observes('nationality3')	

    
});

AppC.DtdAccountUserformController = AppC.DtdAccountController.extend({
    radioTrue: function (field) {
        if (field === 'hasMultipleNat') {
		    AppC.dtdAccountData.set('hasMultipleNat', true);
            $('div#otherNat').removeClass('destroyed');
        } 
    },
    radioFalse: function (field) {
        if (field === 'hasMultipleNat') {
			 AppC.dtdAccountData.set('hasMultipleNat', false);
            $('div#otherNat').addClass('destroyed');
        } 
    }
});

AppC.DtdAccountReviewController = AppC.DtdAccountController.extend({

	actions: {
		dtdSubmit: function () {

	        // Reset errors
	        var errors = AppC.inputErrors;
	        errors.clear();

	        // Trigger all validation
	        $('input, select, div.focusOut').trigger('focusout');

	        if (errors.total()) {
	            AppC.ux.scrollFirstError();
	        } else {
	            var submitting= this.get('controllers.jsonDtdSubmit').get('submitting');
	            if(!submitting){
	                this.get('controllers.jsonDtdSubmit').set('submitting',true);
	                this.get('controllers.jsonDtdSubmit').run();
	            }else{
	                alert('The form has been submitted, please wait for it to complete ...');
	            }
	        }
	    }
	},
	
    needs: ['jsonDtdSubmit']

    

});

AppC.DtdAccountApprovedController = AppC.DtdAccountController.extend();
