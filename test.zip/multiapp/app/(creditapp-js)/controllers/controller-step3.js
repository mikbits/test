/*****************************************************************************
 * CONTROLLER Step 3
 *****************************************************************************/


AppC.Step3Controller = AppC.StepController.extend({

    licenceIsNsw: function () {
        return this.get('licenceState') === 'NSW';
    }.property('licenceState'),

    licenceIsWa: function () {
        return this.get('licenceState') === 'WA';
    }.property('licenceState'),

    licenceIsVic: function () {
        return this.get('licenceState') === 'VIC';
    }.property('licenceState'),

    displayLicence: function () {
        return !!this.get('licenceState');
    }.property('licenceState'),

    licenceImg: function () {
        return 'img/dl-' + this.get('licenceState') + '.png';
    }.property('licenceState'),

    displayAusLicence: function () {
        return this.get('photoId') === 'DL';
    }.property('photoId'),

    displayNonAusLicence: function () {
        return this.get('photoId') !== 'DL';
    }.property('photoId'),

    displayAusPassport: function () {
        return this.get('photoId') === 'AP';
    }.property('photoId'),

    displayIntPassport: function () {
        return this.get('photoId') === 'IP';
    }.property('photoId'),

    displayAusBirth: function () {
        return this.get('ozPassportCountryBirth') !== 'AUS';
    }.property('ozPassportCountryBirth'),

    displayAusPassportInfo: function () {
        return this.get('ozPassportCountryBirth');
    }.property('ozPassportCountryBirth')

});
