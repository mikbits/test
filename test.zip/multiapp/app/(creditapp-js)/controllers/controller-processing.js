AppC.ProcessingController = Ember.ObjectController.extend(AppC.OutcomeStatusMixin, {
	
}); 