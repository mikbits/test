/*****************************************************************************
 * CONTROLLER Ramp
 *****************************************************************************/


AppC.RaEntryController = AppC.BranchEntryController.extend({

    logoPic: function () {

        function setBg () {
            $('#raImgBg').css('background-image', 'url(' + AppC.get('raImgBg') + ')');
        }

        var _this = this,
            id = AppC.get('merchantGroupId'),
            prefix = 'images/ra/',
            lgSuffix = '/step0-logo.png',
            bgSuffix = '/step0-bg.png',
            logoPath = prefix + id + lgSuffix,
            bgPath = prefix + id + bgSuffix,
            dLogoPath = prefix + '999' + lgSuffix,
            dBgPath = prefix + '999' + bgSuffix;

        if (!id) {

            setTimeout(function () {
                _this.logoPic();
            }, 50);
            return;

        }

        AppC.set('isInRa', true);

        // check image files existence
        $.ajax({
            type: 'GET',
            url: logoPath,
            // files exist
            success: function () {
                AppC.set('logoImg', logoPath);
                AppC.set('raImgBg', bgPath);
                setBg();
            },
            // files do NOT exist, default HSBC logo
            error: function (xhr) {
                AppC.set('logoImg', dLogoPath);
                AppC.set('raImgBg', dBgPath);
                setBg();
            }
        });


    },

    radioTrue: function (emField) {
    },

    isCustomerStore: function () {
        return AppC.entryData.get('customerAtMerchantStore');
    }.property('AppC.entryData.customerAtMerchantStore'),

    isCustomerState: function () {
    	//Init to hide both section.
    	$("#noStore").hide();
    	$("#storeDiv").hide();
    	
        return this.get('customerAtMerchantStore') && this.get('customerAtState');
    }.property('customerAtState', 'customerAtMerchantStore'),
    
    termsDescription: function () {
    	var result="";
    	if(AppC.interestFreeTerms && AppC.interestFreeTerms!=0){
    		if(AppC.deferredTerms && AppC.deferredTerms!=0){
    			result=AppC.interestFreeTerms+ " months interest free and " + AppC.deferredTerms + " months deferred payment";
    		}else{
    			result=AppC.interestFreeTerms+ " months interest free";
    		}
    	}else{
    		if(AppC.deferredTerms && AppC.deferredTerms!=0){
    			result=AppC.deferredTerms + " months deferred payment";
    		}
    	}
        return result;
    }.property('AppC.interestFreeTerms','AppC.deferredTerms')
	
});
