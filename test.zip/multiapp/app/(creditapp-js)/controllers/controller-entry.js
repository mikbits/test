AppC.EntryController = Ember.ObjectController.extend(AppC.Nav, {

    needs: ['jsonEntry'],


    entryReq: function () {
        this.get('controllers.jsonEntry').run();
    }

});

