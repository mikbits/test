/*****************************************************************************
 * CONTROLLER Ramp
 *****************************************************************************/


AppC.BranchEntryController = AppC.StepController.extend(AppC.Nav, {


    /**
     * Dependencies
     */
	actions: {
		completeForm: function () {

	        var errors = this.get('errorsContainer');

	        errors.clear();

	        $('input, select').trigger('focusout');

	        if (errors.total()) {
	            AppC.ux.scrollFirstError();

	        } else {
	            AppC.set('refresh',false);
	            AppC.set('merchantStoreId',AppC.get('entryData.storeId'));
	            this.get('controllers.jsonSubmitEntry').run();
	            this.send('goToStep', 1);
	        }

	    }
	},

    needs: ['jsonSubmitEntry', 'jsonEntry'],


    /**
     * Methods
     */

    entryReq: function () {
        this.get('controllers.jsonEntry').run();
    },

    logoPicBranch: function () {
        AppC.set('isInRa', false);
        AppC.set('logoImg', 'images/logo.png');
    }

    


});
