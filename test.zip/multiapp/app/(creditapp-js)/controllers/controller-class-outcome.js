/*****************************************************************************
 * CONTROLLER OUTCOME PAGES
 *****************************************************************************/


AppC.OutcomeController = AppC.StepController.extend({
	actions: {
		changeStore: function () {
	        this.set('storeId', null);
	    }
	},
	
    displayFax: function () {
        return this.get('ausPostFax') && !this.get('hsbcBranchThd');
    }.property('ausPostFax', 'hsbcBranchThd'),

    displayAusPost: function () {
        return this.get('ausPost') && !this.get('hsbcBranch');
    }.property('ausPost', 'hsbcBranch'),

    displayRa: function () {
        return this.get('raName') && AppC.get('isInRa');
    }.property('raName', 'AppC.isInRa'),

    isSelected: function () {
        return this.get('storeId') && this.get('storeId') != '';
    }.property('storeId'),

    

    storeNameRe: function () {
        return AppC.retail.getName(this.get('storeId'));
    }.property('storeId')


});
