AppC.map = {

    backToFront: {
        //'MULTIAPP_COUNTRYCODE': 'Countries',
        //'MULTIAPP_OCCUPATION': 'Occupations'
        //'MULTIAPP_DIRECT_DEBIT_FINANCIALINST': 'FinancialInstitutions',
        //'MULTIAPP_INDUSTRIES': 'Industries'
    },

    frontToBack: {
    },

    reverse: function () {

        var key, value,
            backToFront = this.backToFront,
            tempObj = {};

        for (key in backToFront) {
            if (backToFront.hasOwnProperty(key)) {
                value = backToFront[key];
                tempObj[value] = key;
            }
        }

        this.frontToBack = tempObj;

    }

};

AppC.map.reverse();
