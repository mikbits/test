/*****************************************************************************
 * MIXIN Input max length
 *****************************************************************************/


AppC.InputKeyDown = Ember.Mixin.create({


    /**
     * Events
     */


    keyDown:function (e) {
        var target = $(e.target);
        var valid = target.attr('em-valid');
        var ops = [];
        var keyCode = e.which;
        if(valid) {
            ops=valid.split(' ');
        }
        var length = ops.length;

        // Block if max chars reached
        for (var i = 0; i < length; i++) {
            var op = ops[i];

            if (op.slice(0, 3) === 'max' && !this.isOverMax(target.val(), op.split('_')[1] - 1)) {
                if (keyCode != 8 && keyCode != 9 && keyCode != 35 && keyCode != 36 && keyCode != 37 && keyCode != 38 && keyCode != 39 && keyCode != 40 && keyCode != 46) {
                    return false;
                }
            }

        }

        // Block if starts with space
        // depends on jquery.maskedinput.js
        if (this.$().caret().begin === 0 && e.which === 32) {
            return false;
        }

        return true;
    },


    /**
     * Methods
     */


    isOverMax:function (value, max) {
        var string = value || '';
        return string.length <= max;
    }


});
