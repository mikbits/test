AppC.OutcomeStatusMixin = Ember.Mixin.create({

	//E
	outcomeStatusINCOME: function() {
		if (AppC.get('outcomeStatus') == 'incomeCheckReq') {
			return true;
		}

		return false;
	}.property('AppC.outcomeStatus'),

	//GP
	outcomeStatusIDINCOME: function() {
		if (AppC.get('outcomeStatus') == 'idIncomeCheckReq') {
			return true;
		}

		return false;
	}.property('AppC.outcomeStatus'),

	//F
	outcomeStatusINCOMEADDR: function() {
		if (AppC.get('outcomeStatus') == 'incomeAddrCheckReq') {
			return true;
		}

		if (AppC.get('outcomeStatus') == 'noInstDescision') {
			return true;
		}

		return false;
	}.property('AppC.outcomeStatus'),

	isSetA: function() {
		return (['incomeCheckReq', 'incomeAddrCheckReq', 'processing', 'onlineCalUs'].indexOf(AppC.get('outcomeStatus')) > -1);
	
	}.property('AppC.outcomeStatus'),

	isSetB: function() {
		return (['incomeAddrCheckReq', 'onlineCalUs', 'processing'].indexOf(AppC.get('outcomeStatus')) > -1);
	
	}.property('AppC.outcomeStatus'),

    actions: {
    	openLn: function() {
    		
    		var oldIE;
		    if ($('html').is('.ie6, .ie7, .ie8')) {
		        oldIE = true;
		    }

		    if (oldIE) {
		        AppC.ux.openModal ('ieBrowserHappy');

		    } else {
		        var ln = window.open('%@#/contract/personal-loan/%@'.fmt(AppC.lnEndPointUrl, AppC.applicationId), 'ln', 'scrollbars=1,resizable=1,width=1024,height=768,location=no,menubar=no,status=no,titlebar=no');
		    }
    	},

    	openIa: function() {

    		var oldIE;
		    if ($('html').is('.ie6, .ie7, .ie8')) {
		        oldIE = true;
		    }

		    if (oldIE) {
		        AppC.ux.openModal ('ieBrowserHappy');

		    } else {
		        window.open('%@#/capture'.fmt(AppC.iaEndPointUrl), 'ia', 'scrollbars=1,resizable=1,width=1024,height=768,location=no,menubar=no,status=no,titlebar=no');
		    }
    		
    	}
    }
});
