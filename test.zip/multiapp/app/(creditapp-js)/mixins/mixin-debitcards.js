/*****************************************************************************
 * MIXIN Debit cards
 *****************************************************************************/


AppC.DebitCards = Ember.Mixin.create({


    /**
     * Methods
     */


    toggleCard:function (emField) {
        $('div#' + emField).parent().toggleClass('off');
    }


});
