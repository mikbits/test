/*****************************************************************************
 * MIXIN Navigation
 *****************************************************************************/


AppC.Nav = Em.Mixin.create({
	
    validateStep: function($n,$currentStep) {
        var _this = this;
        _this.goRoute('step' + $n);
        Ember.run.next(this, function() {
            var errors = AppC.inputErrors;
            errors.clear();
            $('input, select, div.focusOut').trigger('focusout');

            //console.log('Step %@ Error %@ Length %@'.fmt($n,errors.total(),$('.error').length));

            if (errors.total() || $('.error').length) {
                AppC.ux.scrollFirstError();
                AppC.setReady();
            } else {
                if ($n < $currentStep) {
                    _this.validateStep($n + 1,$currentStep);
                } else {
                	_this.goRoute('step' + $currentStep);        	
                }
            }
        });
    },	


	actions: {
		goToStep: function (step) {

	        if (typeof step === 'string') {
	            this.goRoute(step);
	        } else if (step > 0) {
	            this.goRoute('step' + step);
	        }

	        AppC.ux.scrollTop();
	    }
	},
    /**
     * Methods
     */

    initStep1: function () {

        var _this = this,

            // corresponding to switch below
            keyFactValArr = [
                'openKeyFactsCC',
                'openKeyFactsCCC',
                'openKeyFactsPCC',
                'openKeyFactsPQCC',
                'openKeyFactsWW',
                '',
                'openKeyFactsPWM',
                '',
                'openKeyFactsCPCCC'
            ],

            prefix = './images/',
            pathName = '',
            i;

//        switch (parseInt(AppC.logo, 10)) {
//
//            // HSBC Credit Card
//            case 305:
//            case 430:
//            i = 0;
//            break;
//
//            // HSBC Classic Credit Card
//            default:
//            case 301:
//            case 400:
//            case 410:
//            case 421:
//            case 440:
//            case 441:
//            i = 1;
//            break;
//
//            // HSBC Platinum Credit Card
//            case 304:
//            case 456:
//            case 457:
//            i = 2;
//            break;
//
//            // HSBC Platinum Qantas Credit Card
//            case 308:
//            case 458:
//            i = 3;
//            break;
//
//            // Woolworths Everyday Money Credit Card
//            case 520:
//            case 540:
//            case 541:
//            i = 4;
//            break;
//
//            // Woolworths Everyday Rewards Qantas Credit Card
//            case 571:
//            i = 5;
//            break;
//
//            // HSBC Premier World Mastercard
//            case 584:
//            case 585:
//            i = 6;
//            break;
//
//            // HSBC Personal Loans
//            case 200:
//            i = 7;
//            break;
//
//            // HSBC VISA CLASSIC ALLIANCE
//            case 420:
//            i = 8;
//            break;
//
//        }
        switch (AppC.logo) {
        // HSBC Credit Card
        case "H":
          i = 0;
          break;

        // HSBC Classic Credit Card
          default:
        case "T":
        case "V":
        case "S":
          i = 1;
          break;

        // HSBC Platinum Credit Card
        case "P":
          i = 2;
          break;

        // HSBC Platinum Qantas Credit Card
        case "Q":
          i = 3;
          break;

        // HSBC Premier World Mastercard
        case "N":
        case "M":
          i = 6;
          break;

        // HSBC Personal Loans
        case "W":
          i = 7;
          break;

        // HSBC VISA CLASSIC ALLIANCE
        case "Y":
          i = 8;
          break;
      }

        AppC.set("bundle", i);

        pathName = (function () {

            switch (i) {

                case 0:
                case 1:
                case 8:
                return prefix + 'card_hsbc_credit_card.png';

                case 2:
                return prefix + 'card_hsbc_platinum_black.png';

                case 3:
                return prefix + 'card_hsbc_qff_platinum.png';

                case 4:
                return prefix + 'cardBlack.png';

                case 5:
                return prefix + 'cardSilver.png';

                case 6:
                return prefix + 'card_hsbc_premier.png'

                default:
                return '';

            }

        }());

        AppC.set('imgFileName', pathName);
        AppC.set('keyFactVal', keyFactValArr[i]);
        AppC.set("isLoan", AppC.logo === "W" ? true : false);
        AppC.set('isWoolworths', AppC.organizationCode === '300' ? true : false);
        AppC.set('isInRa', AppC.retail.sentByEntry ? true : false);

    },

    


    goRoute: function (route) {

        this.transitionToRoute(route);

    },


    goRouteAndReset: function (route) {
        this.goRoute(route);

        // Kill personal data
        AppC.retrieveData.set('option', null);
        AppC.set('step1Data', AppC.Step1Data.create());
        AppC.set('step2Data', AppC.Step2Data.create());
        AppC.set('step3Data', AppC.Step3Data.create());
        AppC.set('step4Data', AppC.Step4Data.create());
        AppC.set('step5Data', AppC.Step5Data.create());
        AppC.set('step6Data', AppC.Step6Data.create());

        // Reset some App properties
        AppC.set('refresh', true);
        AppC.set('applicationId', null);
        AppC.set('conditionalBundle', null);
        AppC.set('isStep0', false);
        AppC.set('isStep1', false);
        AppC.set('isStep2', false);
        AppC.set('isStep3', false);
        AppC.set('isStep4', false);
        AppC.set('isStep5', false);
        AppC.set('isStep6', false);
        AppC.set('hasSavedStep1', false);
        AppC.set('hasSavedStep2', false);
        AppC.set('hasSavedStep3', false);
        AppC.set('hasSavedStep4', false);
        AppC.set('hasSavedStep5', false);
        AppC.set('isStep1Dirty', true);
        AppC.set('isStep2Dirty', true);
        AppC.set('isStep3Dirty', true);
        AppC.set('isStep4Dirty', true);
        AppC.set('isStep5Dirty', true);
        AppC.set('lastSavedStepAsJointApp', null);
        AppC.set('lastSavedStepAsIndividualApp', null);
    }


});
