/*****************************************************************************
 * MIXIN Watermark
 *****************************************************************************/


AppC.Watermark = Ember.Mixin.create({


    /**
     * Methods
     */


    getWatermark: function (field, watermark) {
        return '<div class="watermark" em-field="' + field + '">' + watermark + '</div>';
    },


    displayWatermark: function (field, tagName, watermark) {
        if ($(window).width() < 480) {
            this.$().attr('placeholder', watermark);
        } else {
            if($("div.watermark[em-field='"+field+"']").length === 0){
                $(tagName + '[em-field="' + field + '"]').before(this.getWatermark(field, watermark));
                // register the hook to handle watermark
                $("div.watermark[em-field='"+field+"']").click( function(){
                    $(tagName + '[em-field="' + field + '"]').focus();
                });
            } else {
                $('div.watermark[em-field=' + field + ']').removeClass('destroyed');
            }
        }


    },


    removeWatermark: function (field) {
        $('div.watermark[em-field=' + field + ']').addClass('destroyed');
    }


});
