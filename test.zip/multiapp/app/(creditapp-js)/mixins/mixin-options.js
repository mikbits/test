/*****************************************************************************
 * MIXIN Options
 *****************************************************************************/


AppC.Options = Ember.Mixin.create({


    /**
     * Computed properties
     */


    options:function () {

        function addToAjaxArray () {

            // get constructor name to identify arrayController
            name = self.constructor.toString();
            name = name.slice(name.indexOf('.') + 1);

            // check the array, don't push the same value
            for (var i = 0; jsonLookUp.ajaxArr[i]; i++) {
                if (jsonLookUp.ajaxArr[i] === name) {
                    return;
                }
            }

            jsonLookUp.ajaxArr.push(name);
            setTimeout(function () {
                jsonLookUp.sentReq();
            }, 500);

        }

        var $select = $('<select>'),
            self = this,
            name = '',
            jsonLookUp = AppC.jsonLookUpController;

        if (!this.ajaxed) {
            addToAjaxArray();
        }

        this.get('content').forEach(function (item) {
            var name = item.name || item.value || item.store || item.branch;
            var $option = $('<option>').attr('value', item.code).html(name);
            $select.append($option);
        });

        return $select.html();

    }.property('content')


});
