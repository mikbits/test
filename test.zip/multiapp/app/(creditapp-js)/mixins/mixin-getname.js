/*****************************************************************************
 * MIXIN get option names
 *****************************************************************************/


AppC.GetName = Ember.Mixin.create({


    /**
     * Methods
     */

    getName: function (code) {

        var obj = this.findProperty('code', code), name;

        if (!obj) {
            return '';
        }

        name = obj.name || obj.value || obj.store || obj.branch;
        return name || '';

    }


});
