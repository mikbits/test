/*****************************************************************************
 * ARRAY CONTROLLER Titles
 *****************************************************************************/


AppC.Titles = Ember.ArrayController.extend(AppC.Options, {


    /**
     * Properties
     */


    content:[
        {code:'Mr', name:'Mr'},
        {code:'Mrs', name:'Mrs'},
        {code:'Ms', name:'Ms'},
        {code:'Mis', name:'Miss'},
        {code:'Dr', name:'Doctor'},
        {code:'Sir', name:'Sir'},
        {code:'Ldy', name:'Lady'},
        {code:'Pas', name:'Pastor'},
        {code:'Prf', name:'Professor'},
        {code:'Rev', name:'Reverend'}
    ]


});


AppC.titles = AppC.Titles.create();
