/*****************************************************************************
 * ARRAY CONTROLLER Terms and conditions
 *****************************************************************************/


AppC.Conditions = Ember.ArrayController.extend(AppC.Checkboxes, {


    /**
     * Properties
     */


    content:[
        {code:'PCD', name:'Privacy Consent and Declaration for your credit card'},
        {code:'COU', name:'HSBC credit card Conditions of use'},
        {code:'PCDI', name:'Privacy Consent and Declaration for your credit card insurance'},
        {code:'PDSPD', name:'The Financial Services Guide and Product Disclosure Statement and Policy document or your credit card insurance'}
    ]


});


AppC.conditions = AppC.Conditions.create();
