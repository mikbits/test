/*****************************************************************************
 * ARRAY CONTROLLER Tfn exemptions
 *****************************************************************************/


AppC.TfnExemptions = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'No TFN exception', name:'No TFN exemption'},
        {code:'Pensioner', name:'Pensioner'},
        {code:'Receive social security pension/benefit', name:'Receive social security pension/benefit'},
        {code:'Income tax return not required', name:'Income tax return not required'},
        {code:'Business provides consumer/business finance', name:'Business provides consumer/business finance'},
        {code:'Norfolk Island resident', name:'Norfolk Island resident'},
        {code:'Non-resident', name:'Non-resident'}
    ]


});


AppC.tfnExemptions = AppC.TfnExemptions.create();
