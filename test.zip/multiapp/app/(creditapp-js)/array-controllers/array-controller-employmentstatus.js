/*****************************************************************************
 * ARRAY CONTROLLER Employment Status
 *****************************************************************************/


AppC.Employmentstatus = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'F', name:'Full Time Employment'},
        {code:'P', name:'Permanent Part Time'},
        {code:'C', name:'Contractor'},
        {code:'A', name:'Casual'},
        {code:'S', name:'Self Employed'},
        {code:'E', name:'Full Time Education'},
        {code:'H', name:'Home Duties/Housewife'},
        {code:'R', name:'Retired'},
        {code:'U', name:'Unemployed'},
        {code:'O', name:'Other'}
    ]

});


AppC.employmentstatus = AppC.Employmentstatus.create();
