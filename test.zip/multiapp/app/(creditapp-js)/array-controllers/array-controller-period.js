/*****************************************************************************
 * ARRAY CONTROLLER period
 *****************************************************************************/


AppC.Period = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'Y', name:'Yearly'},
        {code:'M', name:'Monthly'},
        {code:'F', name:'Fortnightly'},
        {code:'W', name:'Weekly'}
    ]


});


AppC.period = AppC.Period.create();
