/*****************************************************************************
 * ARRAY CONTROLLER Occupations
 *****************************************************************************/


AppC.Occupations = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {



    /**
     * Properties
     */


    content:[
        {code:'19', name:'Agricultural worker (excluding farmer)'},
        {code:'10', name:'Building/Engineering'},
        {code:'02', name:'Cleaner'},
        {code:'25:DA', name:'Diplomat / Ambassador'},
        {code:'13', name:'Factory worker'},
        {code:'01', name:'Farmer/farm manager'},
        {code:'14', name:'Health and welfare'},
        {code:'23', name:'Labourer'},
        {code:'24', name:'Manager'},
        {code:'21', name:'Not in employment / Retired'},
        {code:'20', name:'Other / Not included elsewhere'},
        {code:'16', name:'Production and Transport'},
        {code:'25:PE', name:'Professional or Executive'},
        {code:'11', name:'Sales/Service worker'},
        {code:'03', name:'Sales/service supervisor'},
        {code:'25:PO', name:'Senior public official (judge / politician / civil servant)'},
        {code:'25:RMO', name:'Senior ranking military officer  (Colonel or above)'},
        {code:'04', name:'Trade person'}
    ]

});


AppC.occupations = AppC.Occupations.create();
