/*****************************************************************************
 * ARRAY CONTROLLER Credit Card Products
 *****************************************************************************/


AppC.Products = Ember.ArrayController.extend(AppC.Options, {
    /**
     * Properties
     */
    content: [
		{code: "H",name: "HSBC Credit Card"}, 
		{code: "T",name: "HSBC Classic Credit Card"} 
	]
});

AppC.products = AppC.Products.create();

