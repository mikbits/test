/*****************************************************************************
 * ARRAY CONTROLLER Jobs
 *****************************************************************************/


AppC.Term = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {



    /**
     * Properties
     */


    content:[
        {code:'12',name:'12 months'},
        {code:'18',name:'18 months'},
        {code:'24',name:'24 months'},
        {code:'30',name:'30 months'},
        {code:'36',name:'36 months'},
        {code:'42',name:'42 months'},
        {code:'48',name:'48 months'},
        {code:'54',name:'54 months'},
        {code:'60',name:'60 months'}
    ]


});


AppC.term = AppC.Term.create();
