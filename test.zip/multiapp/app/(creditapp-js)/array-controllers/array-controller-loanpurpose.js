/*****************************************************************************
 * ARRAY CONTROLLER Branches
 *****************************************************************************/


AppC.Purpose = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content: [
        {code: "", name: "-- please select --"},
        {code: "1", name: "Car"},
        {code: "2", name: "Motorbike/Boat/Caravan"},
        {code: "7", name: "Consolidating debt"},
        {code: "HT", name: "Holiday"},
        {code: "HR", name: "Home renovations"},
        {code: "RG", name: "Household or personal items"},
        {code: "ED", name: "Education"},
        {code: "WF", name: "Wedding/Funerals"},
        {code: "OO", name: "Other"}
    ]


});


AppC.purpose = AppC.Purpose.create();
