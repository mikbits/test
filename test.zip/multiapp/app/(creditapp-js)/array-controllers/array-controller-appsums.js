/*****************************************************************************
 * ARRAY CONTROLLER Application summaries for multi retrieval
 *****************************************************************************/


AppC.AppSums = Ember.ArrayController.extend({


    /**
     * Properties
     */


    rowSelected: false,


    /**
     * Methods
     */


    addObject: function (appSum) {
        var model = AppC.AppSumData.create();
        model.setProperties(appSum);
        // convert status to be more user friendly format
        var status=model.get('status');
        if(AppC.appStatus.findProperty('code',status)){
            status=AppC.appStatus.findProperty('code',status).name;
            model.set('status',status);
        }

        // check whether the application already exists
        var duplicatedModel=this.findProperty('applicationId',model.get('applicationId')) ;
        // remove the old one
        if(duplicatedModel){
           this.removeObject(duplicatedModel);
        }

        // append the new one at the end
        this.pushObject(model);
    },

    lastUpdateDate: function(){
        var result=null;
        if(this.get('content').length>0){
            this.get('content').forEach(function(appSum){
                var lastUpdateDate=appSum.get('lastUpdateDate');
                if(result){
                    if(lastUpdateDate){
                        var newDate=moment(lastUpdateDate,'DD/MM/YYYY');
                        var latestDate=moment(result,'DD/MM/YYYY');
                        if(newDate.diff(latestDate,'days')>0){
                            result=lastUpdateDate;
                        }
                    }
                }else{
                    result=lastUpdateDate;
                }
            });
        }
        return result;
    }.property('content.@each.lastUpdateDate'),


    total: function () {
        return this.get('content').length;
    }
});


AppC.appSums = AppC.AppSums.create();
