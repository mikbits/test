/*****************************************************************************
 * ARRAY CONTROLLER Genders
 *****************************************************************************/


AppC.Genders = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'M', name:'Male'},
        {code:'F', name:'Female'}
    ]

});


AppC.genders = AppC.Genders.create();
