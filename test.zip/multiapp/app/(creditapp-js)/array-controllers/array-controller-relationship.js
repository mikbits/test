/*****************************************************************************
 * ARRAY CONTROLLER Friends Relationship
 *****************************************************************************/


AppC.Relationship = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'U', name:'AUNT/UNCLE'},
        {code:'B', name:'BROTHER/SISTER'},
        {code:'L', name:'BROTHER/SISTER IN-LAW'},
        {code:'C', name:'CHILD'},
        {code:'E', name:'COLLEAGUES'},
        {code:'O', name:'COUSIN'},
        {code:'F', name:'FRIEND'},
        {code:'G', name:'GRANDPARENT'},
        {code:'N', name:'NIECE/NEPHEW'},
        {code:'Z', name:'OTHERS'},
        {code:'P', name:'PARENT'},
        {code:'I', name:'PARENT IN-LAW'},
        {code:'T', name:'PARTNER'},
        {code:'S', name:'SPOUSE'},
    ]

});


AppC.relationship = AppC.Relationship.create();
