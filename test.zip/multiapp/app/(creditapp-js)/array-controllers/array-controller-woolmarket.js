/*****************************************************************************
 * ARRAY CONTROLLER Jobs
 *****************************************************************************/


AppC.WoolMarket = Ember.ArrayController.extend(AppC.Options, {



    /**
     * Properties
     */


    content:[
        {code:'woolworth',name:'Letter from Woolworths'},
        {code:'television',name:'Television advertising'},
        {code:'outdoor',name:'Outdoor advertising'},
        {code:'magazine',name:'Magazine/Newspaper advertising'},
        {code:'online',name:'Online advertising'},
        {code:'mouth',name:'Word of mouth'},
        {code:'store',name:'Masters Home Improvement Stores'},
    ]


});


AppC.woolMarket = AppC.WoolMarket.create();
