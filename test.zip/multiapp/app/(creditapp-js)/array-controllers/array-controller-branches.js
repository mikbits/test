/*****************************************************************************
 * ARRAY CONTROLLER Branches
 *****************************************************************************/


AppC.Branches = Ember.ArrayController.extend(AppC.Options, {


    /**
     * Properties
     */


    content: [
        {code: '', name: 'Please wait ...'}
    ]


});


AppC.branches = AppC.Branches.create();
