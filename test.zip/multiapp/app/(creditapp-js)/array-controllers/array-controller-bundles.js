/*****************************************************************************
 * ARRAY CONTROLLER Bundles
 *****************************************************************************/


AppC.Bundles = Ember.ArrayController.extend(AppC.Options, {


    /**
     * Properties
     */


    content:[

        {
            bundle: 0,
            cardName: 'HSBC Credit Card'
        },

        {
            bundle: 1,
            cardName: 'HSBC Classic Credit Card'
        },

        {
            bundle: 2,
            cardName: 'HSBC Platinum Credit Card'
        },

        {
            bundle: 3,
            cardName: 'HSBC Platinum Qantas Credit Card'
        },

        {
            bundle: 4,
            cardName: 'Woolworths Everyday Money credit card'
        },

        {
            bundle: 5,
            cardName: 'Woolworths Everyday Rewards Qantas Credit Card'
        },

        {
            bundle: 6,
            cardName: 'HSBC Premier World Mastercard'
        },

        {
            bundle: 7,
            cardName: 'HSBC Personal Loans'
        }

    ]
});

AppC.bundles = AppC.Bundles.create();
