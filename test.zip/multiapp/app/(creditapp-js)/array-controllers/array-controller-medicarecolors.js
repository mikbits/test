/*****************************************************************************
 * ARRAY CONTROLLER Medicare Card Colors
 *****************************************************************************/


AppC.MedicareColors = Ember.ArrayController.extend(AppC.Options, {



    /**
     * Properties
     */


    content:[
          	{code:'B',name:'Blue'},
        	{code:'G',name:'Green'},
        	{code:'Y',name:'Yellow'}
    ]
});


AppC.medicareColors = AppC.MedicareColors.create();
