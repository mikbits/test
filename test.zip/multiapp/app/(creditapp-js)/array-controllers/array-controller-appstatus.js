/*****************************************************************************
 * ARRAY CONTROLLER Activities
 *****************************************************************************/


AppC.AppStatus = Ember.ArrayController.extend(AppC.Checkboxes, {


    /**
     * Properties
     */


    content:[
        {code:'I', name:'incomplete'},
        {code:'P', name:'pending ID'},
        {code:'C', name:'contact required'},
        {code:'D', name:'service delivery'},
        {code:'F', name:'completed'}
    ]


});


AppC.appStatus = AppC.AppStatus.create();
