/*****************************************************************************
 * ARRAY CONTROLLER Activities
 *****************************************************************************/


AppC.Activities = Ember.ArrayController.extend(AppC.Checkboxes, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'ODW', name:'Online deposits or withdrawals'},
        {code:'CDW', name:'Cash deposits or withdrawals'},
        {code:'DAP', name:'Daily purchases'},
        {code:'OFT', name:'Offshore transactions'}
    ]


});


AppC.activities = AppC.Activities.create();
