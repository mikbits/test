/*****************************************************************************
 * ARRAY CONTROLLER Purposes
 *****************************************************************************/


AppC.Purposes = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'Salary and living expenses', name:'Salary and living expenses'},
        {code:'Savings', name:'Savings'},
        {code:'Investment', name:'Investment'},
        {code:'Loan repayment', name:'Loan repayment'},
        {code:'International payments', name:'International payments'},
        {code:'Educational funds', name:'Educational funds'}
    ]


});


AppC.purposes = AppC.Purposes.create();
