/*****************************************************************************
 * ARRAY CONTROLLER Ids
 *****************************************************************************/


AppC.Ids = Ember.ArrayController.extend(AppC.Options, {


    /**
     * Properties
     */


    content:[
        {code:'DL', name:'Australian drivers licence'},
        {code:'AP', name:'Australian passport'},
        {code:'IP', name:'International passport'}
    ],


    /**
     * Methods
     */


    getLicenceCode:function () {
        return this.get('content')[0].code;
    },


    getOzPassportCode:function () {
        return this.get('content')[1].code;
    },


    getIntPassportCode:function () {
        return this.get('content')[2].code;
    }


});


AppC.ids = AppC.Ids.create();
