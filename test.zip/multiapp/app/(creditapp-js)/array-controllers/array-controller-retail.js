/*****************************************************************************
 * ARRAY CONTROLLER Branches
 *****************************************************************************/


        AppC.Retail = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content: [
        {code: '', name: 'Please wait ...'}
    ]

});


AppC.retail = AppC.Retail.create();
