/*****************************************************************************
 * ARRAY CONTROLLER Industries
 *****************************************************************************/


AppC.Industries = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {



    /**
     * Properties
     */


    content:[

         	{code:'09637', name:'Finance /Accounting /Auditing'},
            {code:'09630', name:'Real Estate / Property'},
            {code:'11823', name:'Education / Training'},
            {code:'13990:G', name:'Government'},
            {code:'11810', name:'Healthcare / Pharmaceutical'},
            {code:'12290', name:'Hospitality / Tourism '},
            {code:'13990:HRR', name:'Human Resources / Recruitment'},
            {code:'09637', name:'Legal / Judicial'},
            {code:'13990:UO', name:'Unemployed / Other'},
            {code:'13990:DPS', name:'Defence / Police Force / Security '},
            {code:'06480', name:'Sales / Retail / Wholesale / Trading'},
            {code:'10710', name:'Administrative and Support Services '},
            {code:'08590', name:'Telecommunications'},
            {code:'07550', name:'Transportation and Warehousing '},
     		{code:'08590', name:'Advertising /Marketing /Public Relations '},
     		{code:'01010', name:'Agriculture, Forestry, & Fishing '},
     		{code:'12913', name:'Entertainment / Media / Arts'},
     		{code:'09614', name:'Banking / Insurance / Financial Services'},
     		{code:'11849', name:'Community / Social Services / Non-profit '},
     		{code:'05424', name:'Information Technology /Computers'},
     		{code:'03340', name:'Manufacturing / Construction / Mining'},
    ]


});


AppC.industries = AppC.Industries.create();
