/*****************************************************************************
 * ARRAY CONTROLLER Residential Status
 *****************************************************************************/


AppC.Residentialstatus = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'R', name:'Renting'},
        {code:'B', name:'Boarding'},
        {code:'P', name:'Live with Parents'},
        {code:'O', name:'Owner Occupied / Home Buyer'},
        {code:'Z', name:'Other'}
    ]

});


AppC.residentialstatus = AppC.Residentialstatus.create();
