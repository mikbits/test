/*****************************************************************************
 * ARRAY CONTROLLER Input errors
 *****************************************************************************/


AppC.InputErrors = Ember.ArrayController.extend({


    /**
     * Properties
     */


    content:[],


    /**
     * Require methods
     */


    addObject:function (inputError) {
        this.removeObject(inputError);
        this.pushObject(inputError);
    },


    removeObject:function (inputError) {
        var foundObject = this.findProperty('field', inputError.get('field'));

        if (foundObject) {
            var index = this.indexOf(foundObject);
            this.removeAt(index, 1);
        }

    },


    /**
     * Methods
     */


    addError:function (id, error) {
        this.addObject(new AppC.InputError(id, error));
    },


    removeError:function (id) {
        this.removeObject(new AppC.InputError(id, null));
    },


    total:function () {
        return this.get('content').length;
    }


});


AppC.inputErrors = AppC.InputErrors.create();
