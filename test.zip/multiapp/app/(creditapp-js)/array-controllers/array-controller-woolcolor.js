/*****************************************************************************
 * ARRAY CONTROLLER Jobs
 *****************************************************************************/


AppC.WoolColor = Ember.ArrayController.extend(AppC.Options, {



    /**
     * Properties
     */


    content:[
          	{code:'0001',name:'Black'},
        	{code:'0002',name:'Green'},
        	{code:'0003',name:'Blue'},
        	{code:'0004',name:'Pink'},
    ]


});


AppC.woolColor = AppC.WoolColor.create();
