/*************************************************
* Marital Status (step 3)
**************************************************/

AppC.NoLicence = Ember.ArrayController.extend(AppC.Options, {
	/*******
	*options
	********/

	content:[
		{code:'DL', name:'Australian Driver\'s Licence'},
		{code:'AP', name:'Australian Passport'},
		{code:'IP', name:'International Passport'}
	]

});

AppC.noLicence = AppC.NoLicence.create();
