/*****************************************************************************
 * ARRAY CONTROLLER Passport types
 *****************************************************************************/


AppC.Passports = Ember.ArrayController.extend(AppC.Options, {


    /**
     * Properties
     */


    content:[
        {code:'AP', name:'Australian Passport'},
        {code:'IP', name:'International Passport'}
    ]


});


AppC.passports = AppC.Passports.create();
