/*****************************************************************************
 * ARRAY CONTROLLER adlicence
 *****************************************************************************/


AppC.Adlicence = Ember.ArrayController.extend(AppC.Options, {


    /**
     * Properties
     */


    content: [
        {code: "ACT", name: "Australian Capitol Territory"},
        {code: "NSW", name: "New South Wales"},
        {code: "NT", name: "Northern Territory"},
        {code: "QLD", name: "Queensland"},
        {code: "SA", name: "South Australia"},
        {code: "TAS", name: "Tasmania"},
        {code: "VIC", name: "Victoria"},
        {code: "WA", name: "Western Australia"}
    ]

});


AppC.adlicence = AppC.Adlicence.create();
