/*****************************************************************************
 * ARRAY CONTROLLER Financial Institutions
 *****************************************************************************/


AppC.FinancialInstitutions = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        { code: "ANZ", name: "ANZ" },
        { code: "CBA", name: "CBA" },
        { code: "HSBC", name: "HSBC" },
        { code: "NAB", name: "NAB" },
        { code: "OTHER", name: "OTHER" },
        { code: "STG", name: "St George" },
        { code: "WSP", name: "Westpac" },
    ]

});


AppC.financialInstitutions = AppC.FinancialInstitutions.create();
