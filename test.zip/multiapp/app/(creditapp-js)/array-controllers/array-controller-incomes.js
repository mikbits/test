/*****************************************************************************
 * ARRAY CONTROLLER Incomes
 *****************************************************************************/


AppC.Incomes = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {


    /**
     * Properties
     */


    content:[
        {code:'SLRY', name:'Salary'},
        {code:'CTLK', name:'Centrelink/DVA payments'},
        {code:'INVM', name:'Investment income'},
        {code:'ALLW', name:'Student allowances'},
        {code:'SUPR', name:'Superannuation/Pension payments'}
    ]

});


AppC.incomes = AppC.Incomes.create();
