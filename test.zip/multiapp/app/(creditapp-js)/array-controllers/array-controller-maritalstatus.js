/*************************************************
* Marital Status (step 3)
**************************************************/

AppC.MaritalStatus = Ember.ArrayController.extend(AppC.Options, AppC.GetName, {

	content:[
		{code:'M', name:'Married'},
		{code:'S', name:'Single'},
		{code:'FD', name:'De Facto'},
		{code:'D', name:'Seperated/Divorced'},
		{code:'W', name:'Widow/Widower'},
		{code:'FC', name:'Civil Union'}
	]

});

AppC.maritalStatus = AppC.MaritalStatus.create();
