/*****************************************************************************
 * DFA Tag Handlerbar Helpers
 * Usage:
 *     {{DFATag bundle="1" productsBinding="App.step5Data.accountTypesRe" applicationIdBinding="App.applicationId" page="1" pageType="S"}}
 *     {{DFATag status="P" errorBinding=App.responseData.errorCode}}
 *     {{DFATag statusBinding="App.responseData.responseCode" errorBinding="App.responseData.errorCode"}}
 *
 * Notes:
 *     - pageType="S" means start page
 *     - pageType="E" means end page/last page/thank you page/error page
 *
 *      - page is the identifier of any page
 *
 *****************************************************************************/



Ember.Handlebars.registerBoundHelper('DFATag', function (options) {

    var bundle = options.hash['bundle'];
    var allProdCodeArray = options.hash['products'];
    var pageIdentifier = options.hash['page'];
    var applicationId = options.hash['applicationId'];
    var status = options.hash['status'];
    var errorCode = options.hash['error'];
    var pageType = options.hash['pageType'];


    var axel = Math.random() + "";
    var randomNumber = axel * 10000000000000;
    var u1 = (applicationId ? applicationId : '');                                   //[Application  ID];
    var u2 = (AppC.get('marketCode') ? AppC.get('marketCode') : 'multiapp');                                      //[Source Code ]
    var u3 = (status ? status : '');                                          //[Status ]
    var u4 = AppC.logo;                       //[Pre-Selected Products]
    var u5 = '1';                                             //[Revenue]
    var u6 = (applicationId ? applicationId : '');                                   //[Reference Code]
    var u7 = (errorCode ? errorCode : '');                                       //[Error Code];
    var u8 = (pageIdentifier ? pageIdentifier : '');                                  //[Step Number];
    var u9 = (AppC.get('isDtd') ? 'CMG' : '');    // [Cross-sale products]
    var u10 = (pageType ? pageType : '');
    
    var u17 = (AppC.get('merchantGroupId') ? AppC.get('merchantGroupId') : ''); 

    if ($(window).width() < 480) {
        var u18 = 'Mobile';
    } else {
        var u18 = 'Desktop';
    }// [type of page, either S which means start or E which means end]

    var u19 = '';
    if (u9) {
        var u19 = 0;
    } else {
        var u19 = 1;
    }

    var u20 = (AppC.get('merchantStoreId') ? AppC.get('merchantStoreId') : '');

    //tag = tag + dfaProducts(bundle, allProdCodeArray);

    var axel = Math.random() + "";
    var a = axel * 10000000000000;

    //tag = tag + 'u18=' + u18 + ';ord=' + randomNumber + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';
    var tag = '<iframe src="https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=multi494;u2='+u2+';u3='+u3+';u4='+u4+';u5='+u5+';u6='+u6+';u7='+u7+';u8='+u8+';u18='+u18+';u9='+u9+';u10='+u10+';u17='+u17+';u20='+u20+';u1='+u1+';ord=1;num=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';
    tag += '<iframe src="https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=multi754;u2='+u2+';u3='+u3+';u4='+u4+';u5='+u5+';u6='+u6+';u7='+u7+';u8='+u8+';u18='+u18+';u9='+u9+';u10='+u10+';u17='+u17+';u20='+u20+';u1='+u1+';ord=1;num=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';

    // for thank you page, trigger extra tag
    if('ND' === pageIdentifier ){
    	tag += '<iframe src="https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=hsbcr0;u2='+u2+';u3='+u3+';u4='+u4+';u5='+u5+';u6='+u6+';u7='+u7+';u8='+u8+';u18='+u18+';u9='+u9+';u10='+u10+';u17='+u17+';u20='+u20+';u1='+u1+';ord=1;num=' + a + '?" width="1" height="1" frameborder="0" style="display:none"></iframe>';
    }
    
    return new Handlebars.SafeString(tag);
});



function callDynamicFloodLight(applicationId, product, crossSellProduct, cdmId) {
    var u1 = applicationId;                                   //[Application  ID];
    var u2 = (AppC.get('marketCode') ? AppC.get('marketCode'): 'multiapp');
    var u4 = product.join('|');                               //[Pre-Selected Products]
    var u5 = '1';                                             //[Revenue]
    var u6 = (cdmId ? cdmId : applicationId);                 //[Reference Code]
    var u9 = crossSellProduct.join('|');
    var u7 = '';
    var u11 = '';

    if (crossSellProduct.length) {
        var u11 = '1';
    }

    var axel = Math.random() + "";
    var a = axel * 10000000000000;

    // u11 to u20
    var tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=liabi840;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u7=' + u7 + ';u9=' + u9 + ';' + 'u11=' + u11 + ';u12=;u13=;u14=;u15=;u16=;' + 'u1=' + u1 + ';ord=1;num=' + a + '?';

    var flDiv = null;
    if (document.getElementById("DCLK_FLDiv")) {
        flDiv = document.getElementById("DCLK_FLDiv");
    } else {
        flDiv = document.body.appendChild(document.createElement("div"));
        flDiv.id = "DCLK_FLDiv";
        flDiv.style.display = "none";
    }

    var DCLK_FLIframe = document.createElement("iframe");
    DCLK_FLIframe.id = "DCLK_FLIframe_" + Math.floor(Math.random() * 10000000000000);
    DCLK_FLIframe.src = tag;
    flDiv.appendChild(DCLK_FLIframe);

    $.each(u4.split('|'), function(k, v) {
        var u19 = 1;
        addLayer1(flDiv, v, u1, u2, u4, u5, u6, u9, u19);
    });

    $.each(u9.split('|'), function(k, v) {
        var u19 = 0;
        addLayer1(flDiv, v, u1, u2, u4, u5, u6, u9, u19);
    });


};

/**
 HSBC Credit Card                  430	H
 HSBC Platinum Card                457	P
 HSBC Platinum Card                457	B   (no anual fee) ????
 HSBC QFF Card                     458	Q
 Premier Card                      584	M
 Corporate partners                420
 Personal Loan                     100	W
 Personal Loan                     200	W
 CLASSIC VISA						440/441	T  ????
HSBC STAFF VISA						421	S
PREMIER QFF							585	N  ????
CORPORATE ALLIANCE					420	Y
PILS								100	C
CLASSIC VISA						400	V   ????

 */

function addLayer1(flDiv, v, u1, u2, u4, u5, u6, u9, u19) {
    if (v) {

        var tag = '';
        var axel = Math.random() + "";
        var a = axel * 10000000000000;

        switch(v) {
            case 'CMG':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=dayto238;cat=hsbcd672;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'MSV':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=multi475;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'SSP':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=ssfin633;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'ACS':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=flexi524;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'OST':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=savin635;cat=ostth749;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'NAF':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=hsbcc134;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'H':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=hsbcc134;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'P':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=credi247;cat=plati700;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'B':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=credi247;cat=plati700;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'Q':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=compl335;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'M':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=hsbcp032;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;
            case 'Y':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=corpo265;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=1?';
                break;
            case 'W':
            case 'C':
                tag = 'https://986806.fls.doubleclick.net/activityi;src=986806;type=hsbcp974;cat=perso301;u2=' + u2 + ';u4=' + u4 + ';u5=' + u5 + ';u6=' + u6 + ';u19=' + u19 + ';u9=' + u9 + ';u1=' + u1 + ';ord=1;num=' + a + '?';
                break;

            default:
                return false;
                break;
        }

        var DCLK_FLIframe = document.createElement("iframe");
        DCLK_FLIframe.id = "DCLK_FLIframe_" + Math.floor(Math.random() * 10000000000000);
        DCLK_FLIframe.src = tag;
        flDiv.appendChild(DCLK_FLIframe);

        return true;

    }
    return false;
}




