Ember.Handlebars.helper('ucwords', function(value, options) {
    return value.ucwords();
});