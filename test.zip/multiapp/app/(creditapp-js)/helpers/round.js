Ember.Handlebars.helper('round', function(value, options) {
    return Math.round(value);
});