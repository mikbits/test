Ember.Handlebars.registerBoundHelper('LivePersonTagAllPageStart', function(options) {
    var bundle=options.hash['bundle'];
    var page=options.hash['page'];

    var unit = bundleToLivePersonUnit(bundle);
    var section = bundleToLivePersonSection(bundle);
    
    conversionStageNumber = pageToLPConversionStageNumber(page)
    conversionStage = pageToLPConversionStage(page)
    
    var errorName = options.hash['errorName'];
    
    // reset first page, last page tag
    var pageVars = [
  		{ scope:'page', name:'unit', value:unit, mobile:true }, 
      	{ scope:'page', name:'Section', value:section, mobile:true },
      	{ scope:'page', name:'ConversionStageNumber', value:conversionStageNumber, mobile:true }, 
      	{ scope:'page', name:'ConversionStage', value:conversionStage, mobile:true },
      	{ scope:'page', name:'ErrorName', value:errorName, mobile:true },
     ];
    
    lpTag.section = unit //give lpTag.section the same value as 'unit'
    lpTag.vars.push(pageVars);
    
    var tag='<span class="LivePersonTagAllPageStart"></span>';
    return new Handlebars.SafeString(tag);
});

function pageToLPConversionStageNumber(page){
	 if(!page){
		 conversionStageNumber='';
	 }
	 
	 var pageString = ''+page;
	 
	 switch (pageString){
	 	case "1":
	 		conversionStageNumber = '1';
	 		break;
	 	case "2":
	 		conversionStageNumber = '2';
	 		break;
	 	case "3":
	 		conversionStageNumber = '3';
	 		break;
	 	case "4":
	 		conversionStageNumber = '4';
	 		break;
	 	case "5":
	 		conversionStageNumber = '5';
	 		break;
	 	case "6":
	 		conversionStageNumber = '6';
	 		break;
	 	default:
	 		conversionStageNumber = ''; 
	 		break;
	 }
	 return conversionStageNumber;
}

function pageToLPConversionStage(page){
	 if(!page){
		conversionStage='';
	 }
	 
	 var pageString = ''+page;
	 
	 switch (pageString){
	 	case "AP":
	 		conversionStage = 'approved';
	 		break;
	 	case "PI":
	 		conversionStage = 'pendingId';
	 		break;
	 	case "SI":
	 		conversionStage = 'selfId';
	 		break;
	 	case "ND":
	 		conversionStage = 'processing';
	 		break;
	 	case "IC":
	 		conversionStage = 'idCheckReq';
	 		break;
	 	case "IR":
	 		conversionStage = 'incomeCheckReq';
	 		break;
	 	case "DN":
	 		conversionStage = 'denial';
	 		break;
	 	case "IX":
	 		conversionStage = 'idincomeCheckreq';
	 		break;
	 	case "AS":
	 		conversionStage = 'actionstep';
	 		break;
	 	case "1":
	 		conversionStage = 'Step 1';
	 		break;
	 	case "2":
	 		conversionStage = 'Step 2';
	 		break;
	 	case "3":
	 		conversionStage = 'Step 3';
	 		break;
	 	case "4":
	 		conversionStage = 'Step 4';
	 		break;
	 	case "5":
	 		conversionStage = 'Step 5';
	 		break;
	 	case "6":
	 		conversionStage = 'Step 6';
	 		break;
	 	default:
	 		conversionStage = '';
	 		break;
	 }
	 
	 return conversionStage;
}

function bundleToLivePersonSection(bundle){
    var bundleString = ''+bundle;
    var prodCodes='ba-application-cc';

    switch (bundleString) {
        case "2":
            prodCodes = 'ba-application-platinum';
        break;
        case "3":
            prodCodes = 'ba-application-qff'; 
        break;
        case "7":
            prodCodes = 'ba-application-pl';
        break;
    }
    return prodCodes;
};

function bundleToLivePersonUnit(bundle){
    var bundleString = ''+bundle;
    var unit='sales-credit-cards';

    switch (bundleString) {
        case "7":
        	unit = 'sales-personal-loans';
        break;
    }
    return unit;
};
/*
CC H / V 
Platinum P
QFF N
PL W / C
*/
function cardProductCodesToName(allProdCodeArray) {
    var prodName = 'unknown';
    if (allProdCodeArray) {
    	if(!(allProdCodeArray instanceof Array)){
    		allProdCodeArray=new Array(allProdCodeArray);
    	}
        var allCodes = [];
        allProdCodeArray.forEach(function (item) {
            switch (item) {
                case "H":
                case "V":
                case "T":
                    allCodes.push('CC');
                    break;
                case "P":
                    allCodes.push('Platinum');
                    break;
                case "N":
                    allCodes.push('QFF');
                    break;
                case "W":
                case "C":
                    allCodes.push('PL');
                    break;
                default:
                	allCodes.push('CC');
                	break;
            }
        });

        prodName = allCodes.join(';');
    }
    return prodName;
}

function livePersonTagOnSubmitClickStart(appNumber, productData, products) {
	
	var creditLimit = '1';
	if (productData) {
		if(productData.creditLimit){
			creditLimit = productData.creditLimit;
		}
	}
	
	var productName = cardProductCodesToName(products);
	
	var OnClickVars = [        
           	{ scope:'page', name:'ConversionAction', value:'Submitted', mobile:true  },
	        { scope:'page', name:'OrderNumber', value:''+appNumber, mobile:true  },
	        { scope:'page', name:'OrderTotal', value:'' + creditLimit, mobile:true  },
	        { scope:'page', name:'Product_Name', value:productName, mobile:true  }
   	];
   		
   	if (typeof(LPMobile) !== "undefined") {  
   		for (var i = 0; i < OnClickVars.length; i++) {  
   			if (OnClickVars[i].mobile) {  
   				LPMobile.reportEvent(OnClickVars[i].name,OnClickVars[i].value);  
   			}  
   		}  
   	} else {  
		lpTag.vars.push(OnClickVars);  
		try{  
			lpTag.vars.send();  
		} catch(e) {}  
   	}  
}