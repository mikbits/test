
/*****************************************************************************
 * WebTrend Tag Handlerbar Helpers
 * Usage:
 *     {{WebTrendTagAllPageStart page="1"}}
 *     {{WebTrendTagFirstPageStart bundleBinding="AppC.bundle"}}
 *     {{WebTrendTagResultPageStart productsBinding="AppC.step5Data.accountTypesRe"}}
 *
 * Notes:
 *
 *      - page is the identifier of any page
 *****************************************************************************/


Ember.Handlebars.registerBoundHelper('WebTrendTagAllPageStart', function(options) {
    var bundle=options.hash['bundle'];
    var pageIdentifier=options.hash['page'];
    if(!pageIdentifier){
        pageIdentifier='unknown';
    }
    var dcsuriPageIdentifier = "CurrentStep%3D"+pageIdentifier;
    
    var pageName=cardPageIdToPageName(pageIdentifier);

    // reset first page, last page tag
    HSBC.EXT.HSBC_e = null;
    HSBC.EXT.HSBC_u = null;
    HSBC.PAGE.pn_sku = null;
    HSBC.PAGE.si_n = null;
    HSBC.PAGE.si_x = null;
    HSBC.PAGE.tx_e = null;
    HSBC.PAGE.tx_i = null;
    HSBC.PAGE.tx_id = null;
    HSBC.PAGE.tx_it = null;
    HSBC.PAGE.tx_s = null;
    HSBC.PAGE.tx_u = null;
    HSBC.PAGE.ti = pageName

    // start of all page tag
    HSBC.SITE.rgn="Asia Pacific";
    HSBC.SITE.subrgn="Rest of Asia Pacific";
    HSBC.SITE.cnty="Australia";
    HSBC.SITE.ent="HSBC Bank Australia Limited";
    HSBC.SITE.brand ="HSBC";
    HSBC.DCS.ID = "dcsoerk141000004jdy7sftrk_3m8z";
    HSBC.SITE.cam = (HSBC.SITE.cam ? HSBC.SITE.cam: "0");

    HSBC.DCS.DOMS="www.hsbc.com.au,www.apps.asiapacific.hsbc.com,mmw.hsbc.com.au,online.hsbc.com.au,sharetrading.hsbc.com.au,apply.hsbc.com.au,credit.hsbc.com.au";

    var thisSiteType="Public";
    HSBC.SITE.custgrp="PFS";
    HSBC.SITE.busline="General";
    HSBC.SITE.prodline="Credit Cards";
    HSBC.SITE.site=thisSiteType.substring(thisSiteType.indexOf('\;')+1);
    HSBC.SITE.ibtype=thisSiteType.substring(0,thisSiteType.indexOf('\;'));
    HSBC.PAGE.cg_n=thisSiteType;
    HSBC.SITE.language="en";

    var prods = wtCardProductCodesToName(AppC.logo);
    HSBC.PAGE.pn_sku=prods;
    
    switch (pageIdentifier) {
        case 'AP':
        
            HSBC.PAGE.decisionstatus = 'Approved';
            break;

        case 'ND':
        case 'PI':
        case 'SI':
            HSBC.PAGE.decisionstatus = 'Pending';

            HSBC.EXT.HSBC_u="1"; 
            HSBC.EXT.HSBC_e="apsu"; 
            HSBC.PAGE.si_n="ProdConvAll"; 
            HSBC.PAGE.si_x="3"; 


            break;

        case 'GE':
        case 'AE':
            HSBC.PAGE.decisionstatus = 'Declined';

            HSBC.EXT.HSBC_u="1"; 
            HSBC.EXT.HSBC_e="apsu"; 
            HSBC.PAGE.si_n="ProdConvAll"; 
            HSBC.PAGE.si_x="3"; 

            break; 
    }

    // /furl/Content Root/Home/AUH2/HSBC Credit Card Application/CurrentStep=1
    // ...
    // /furl/Content Root/Home/AUH2/HSBC Credit Card Application/CurrentStep=Submit
    HSBC.LOG.dcsuri='/furl/Content Root/Home/AUH2/HSBC Credit Card Application/'+dcsuriPageIdentifier;

    var tag='<span class="WebTrendTagAllPageStart"></span>';
    return new Handlebars.SafeString(tag);
});


Ember.Handlebars.registerBoundHelper('WebTrendTagAllPageEnd', function(options) {
    if (_tag) {
    	Ember.run.later(function() {
    		_tag.dcsCollect();
    	}, 2000);
        
    }

    var tag = '<span class="WebTrendTagAllPageEnd"></span>';
    return new Handlebars.SafeString(tag);
});

Ember.Handlebars.registerBoundHelper('WebTrendTagFirstPageStart', function (options) {
    var bundle = options.hash['bundle'];
    var prods = wtCardProductCodesToName(AppC.logo);

    if (typeof(HSBC) != "undefined") {
        HSBC.PAGE.pn_sku = prods;
        HSBC.EXT.HSBC_u = "1";
        HSBC.EXT.HSBC_e = "apst";
        HSBC.PAGE.si_n = "ProdConvAll";
        HSBC.PAGE.si_x = "2";
        HSBC.SITE.cam = (HSBC.SITE.cam ? HSBC.SITE.cam: "0");
    }
    var tag = '<span class="WebTrendTagFirstPageStart"></span>';
    return new Handlebars.SafeString(tag);
});

function webTrendTagResultPageStart(products) {

    var prods = wtCardProductCodesToName(products);

    var curDateTime = new Date();
    var randNo = Math.round(Math.abs(Math.sin(curDateTime.getTime())) * 1000000000) % 10000000;
    var curHour = curDateTime.getHours();
    var curMin = curDateTime.getMinutes();
    var curSec = curDateTime.getSeconds();
    var curTime = ((curHour < 10) ? "0" : "") + curHour + ":" + ((curMin < 10) ? "0" : "") + curMin + ":" + ((curSec < 10) ? "0" : "") + curSec;

    var today = new Date();
    var month = today.getMonth() + 1;
    var year = today.getYear();
    var day = today.getDate();
    var curDate = "";
    if (day < 10) day = "0" + day;
    if (month < 10) month = "0" + month;
    if (year < 1000) year += 1900;
    curDate = month + "/" + day + "/" + year;

    HSBC.PAGE.pn_sku = prods;
    HSBC.PAGE.tx_u = "1";
    HSBC.PAGE.tx_e = "p";
    HSBC.PAGE.tx_s = prods;

    HSBC.PAGE.tx_i = randNo;
    HSBC.PAGE.tx_it = curTime;
    HSBC.PAGE.tx_id = curDate;
    
    HSBC.EXT.HSBC_u = "1";
    HSBC.EXT.HSBC_e = "apsu";
    HSBC.PAGE.si_n = "ProdConvAll";
    HSBC.PAGE.si_x = "3";
    HSBC.SITE.cam = (HSBC.SITE.cam ? HSBC.SITE.cam: "0");

    if (_tag) {
    	// Send application submit event based on the value of the Webtrends variable hsbc.e="apsu" for Causata
    	// commented out on 10-03-2014 to remove the tag logic
    	// jsHub.trigger('application-submit', {'custom-event': 'true', 'wt-pn-sku': HSBC.PAGE.pn_sku, 'wt-tx-u': HSBC.PAGE.tx_u, 'wt-tx-e': HSBC.PAGE.tx_e, 'wt-tx-s': HSBC.PAGE.tx_s, 'wt-tx-i': HSBC.PAGE.tx_i, 'wt-tx-it': HSBC.PAGE.tx_it, 'wt-tx-id': HSBC.PAGE.tx_id, 'hsbc-u': HSBC.EXT.HSBC_u, 'hsbc-e': HSBC.EXT.HSBC_e, 'wt-si-n': HSBC.PAGE.si_n, 'wt-si-x': HSBC.PAGE.si_x  });
        Ember.run.later(function() {
    		_tag.dcsCollect();
    	}, 2000);
    }
}


function wtCardProductCodesToName(allProdCodeArray) {
    var prodName = 'unknown';

    if (allProdCodeArray) {
    	if(!(allProdCodeArray instanceof Array)){
    		allProdCodeArray=new Array(allProdCodeArray);
    	}
        var allCodes = [];
        allProdCodeArray.forEach(function (item) {
            switch (item) {
                case "CMG":
                    allCodes.push('AUH_SavingsOSA01');
                    break;
                case "MSV":
                    allCodes.push('AUH_SavingsMCA01');
                    break;
                case "SSP":
                    allCodes.push('AUH_SavingsSS01');
                    break;
                case "OST":
                    allCodes.push('AUH_InvestBroking01');
                    break;
                case "ACS":
                    allCodes.push('AUH_SavingsFSA01');
                    break;
                case "430":
                    allCodes.push('AUH_LowRateCard01');
                    break;
                case "457":
                    allCodes.push('AUH_PlatinumCard01');
                    break;
                case "458":
                    allCodes.push('AUH_PlatinumCard02');
                    break;
                case "584":
                    allCodes.push('AUH_PremierCard01');
                    break;
                case "585":
                    allCodes.push('AUH_PremierCard01');
                    break;
                case "200":
                    allCodes.push('AUH_LoansPersonal01');
                    break;  
                case "H":
                    allCodes.push('AUH_LowRateCard01');
                    break;
                case "P":
                    allCodes.push('AUH_PlatinumCard01');
                    break;
                case "B":
                    allCodes.push('AUH_PlatinumCard01');
                    break;                    
                case "Q":
                    allCodes.push('AUH_PlatinumCard02');
                    break;
                case "M":
                    allCodes.push('AUH_PremierCard01');
                    break;
                case "N":
                    allCodes.push('AUH_PremierCard01');
                    break;
                case "W":
                    allCodes.push('AUH_LoansPersonal01');
                    break;
                case "V":
                case "T":
                    allCodes.push('AUH_ClassicCard01');
                    break;                       
            }
        });

        prodName = allCodes.join(';');
    }
    return prodName;
}


function cardPageIdToPageName(pageIdentifier){
	var pageName='unknown';
	var mappings=[
			{code:'1',name:'Step 1'},
			{code:'2',name:'Step 2'},
			{code:'3',name:'Step 3'},
			{code:'4',name:'Step 4'},
			{code:'5',name:'Step 5'},
			{code:'6',name:'Step 6'},
			{code:'AE',name:'Application Error'},
			{code:'AP',name:'Approved'},
			{code:'AS',name:'Conditional Approved'},
			{code:'B ',name:'Branch Entry'},
			{code:'DA',name:'DTD Approved'},
			{code:'DN',name:'Denied'},
			{code:'DR',name:'DTD Review'},
			{code:'DU',name:'DTD Input'},
			{code:'GE',name:'Techincal Error'},
			{code:'IC',name:'ID Check Required'},
			{code:'IR',name:'Income Check Required'},
			{code:'IX',name:'ID Income Check Required'},
			{code:'MA',name:'Maintenance'},
			{code:'MM',name:'Multiple Matches'},
			{code:'ND',name:'In Progress'},
			{code:'NR',name:'No Decision'},
			{code:'OC',name:'Customer Callback'},
			{code:'PI',name:'Pending ID'},
			{code:'RE',name:'Retrieve'},
			{code:'SI',name:'Self ID'},
			{code:'TO',name:'Timeout'},
			{code:'VC',name:'Victoria Licence'}
			];
	mappings.forEach(function (item) {		
		if(item.code === pageIdentifier){			
			pageName = item.name;		
		}	
	});
	pageName = "HSBC Credit Card Application - "+pageName+" | HSBC Australia";
    return pageName;
}

