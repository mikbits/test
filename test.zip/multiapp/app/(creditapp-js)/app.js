/*****************************************************************************
 * APPLICATION
 *****************************************************************************/

window.AppC = Ember.Application.create({


    /**
     * System settings
     */

    LOG_TRANSITIONS: false,


    iaEndPointUrl: '@@iaUri@@',
    lnEndPointUrl: '@@lnUri@@',

    //jsonTimeOut: 60000, // ms
    jsonTimeOut: 240000, // ms
    scrollSpeed: 500, // ms
    previousAddressTrigger: 3, // Customers have to fill previous address if nb of years at current address < x years
    inputTimer: 1000, // ms

    /**
     * System global variables
     */


    isBusy: true,
    refresh: true,
    refreshStep1: false,
    applicationId: null,

    outcomeStatus: null,



    

    bundle: null,
    conditional: null,

    isNotStep: false,
    isStep0: false,
    isStep1: false,
    isStep2: false,
    isStep3: false,
    isStep4: false,
    isStep5: false,
    isStep6: false,
    isStep7: false,
    isDtd: false,
    hasSavedStep1: false,
    hasSavedStep2: false,
    hasSavedStep3: false,
    hasSavedStep4: false,
    hasSavedStep5: false,
    isStep1Dirty: true,
    isStep2Dirty: true,
    isStep3Dirty: true,
    isStep4Dirty: true,
    isStep5Dirty: true,
    isDtdDirty: true,
    lastSavedStepAsJointApp: null,
    lastSavedStepAsIndividualApp: null,

    // Entry Received Settings
    productCode: null,
    organizationCode: null,
    merchantGroupId: null,
    merchantStoreId: null,
    logo: '',
    contractAccepted: null,
    imgClass: 'cardImg', // deprecated
    imgFileName: '',

    isSso: false,

    // if logo Code equals 200
    loanRate: null,
    loanAmt: null,
    loanPurpose: null,
    loanOtherPurpose: null,
    loanTerm: null,
    repaymentAdjust: 0,

    // Credit Card Attributes
    productName: '',
    incomeRe: 0,
    minCredit: 0,
    maxCredit: 0,
    annualFee: 0,

    isHSBC: true,
    isWoolworths: false,
    isInRa: false,
    logoImg: null,
    raImgBg: null,
    isLoan: null,

    renderSwitch: true,
    selectRenderSwitch: true,
   

    /**
     * Observers
     */

    productNameChanged: function() {
        if (this.get('productName')) {
            $(document).attr('title', this.get('productName'));
        }
    }.observes('productName'),


    /**
     * Methods
     */


    getCurrentStep: function() {

        var hash = location.hash;

        if (/entry/i.test(hash)) {
            return 0;
        }

        if (/step/.test(hash)) {
            return parseInt(hash.slice(-1));
        }

        if (/selfId/.test(hash)) {
            return 7;
        }

        if (/dtdAccount/.test(hash)) {
            return 8;
        }

        if (this.get('isNotStep')) {
            return 9;
        }

    },


    setCurrentStepDirty: function() {
        if (this.isDtd) {
            this.set('isDtdDirty', true);
        }
        this.set('isStep' + this.getCurrentStep() + 'Dirty', true);
    },


    nothingDirtyUntil: function(step) {
        for (var i = 1; i <= step; i++) {
            this.set('isStep' + i + 'Dirty', false);
        }
    },


    nothingSaved: function() {
        for (var i = 1; i <= 6; i++) {
            this.set('hasSavedStep' + i, false);
        }
    },


    getLastSavedStep: function() {
        var lastSaved = null;

        for (var i = 1; i <= 6; i++) {
            if (this.get('hasSavedStep' + i)) {
                lastSaved = i;
            }
        }

        return lastSaved;
    },


    setSavedUntil: function(step) {
        for (var i = 1; i <= step; i++) {
            this.set('hasSavedStep' + i, true);
        }
    },


    getCurrentStepData: function() {
        var step = this.getCurrentStep();


        switch (step) {

            case 0:
                return AppC.entryData;

            case 1:
                return AppC.step1Data;

            case 2:
                return AppC.step2Data;

            case 3:
                return AppC.step3Data;

            case 4:
                return AppC.step4Data;

            case 5:
                return AppC.step5Data;

            case 6:
                return AppC.step6Data;

            case 7:
                return AppC.selfIdData;

            case 8:
                return AppC.dtdAccountData;

            case 9:
                return AppC.responseData;

            default:
                return null;

        }
    },


    setStep: function(step) {

        for (var i = 0; i <= 7; i++) {
            this.set('isStep' + i, i === step);
        }

    },

    setBusy: function() {
        this.set('isBusy', true);
        $('div#busy').modal({
            focus: false
        });
        $('a.modalCloseImg').remove();
    },


    setReady: function() {
        this.set('isBusy', false);
        $.modal.close();
    },


    /**
     * Life cycle hooks
     */


    ready: function() {
        $(document).tooltip();
        $(document).on('focus', '.hasDatepicker', function() {
            $(this).val('');
        });
    }
});


AppC.reopen({


    /**
     * Veda Properties
     */


    checkVeda: true,


    /**
     * Veda Methods
     */


    checkGeoCoder: function() {
        return AppC.callVeda('580 George St Sydney NSW 2000', 'ValidateAddress');
    },


    callVeda: function(address, endPoint) {
        
        var params = {
            address: address
        };

        var _this = this;

        AppC.set('vedaResponse', AppC.VedaResponse.create());

        return AppC.vedaSend(params, endPoint).then(function(response) {

            AppC.vedaResponse.setProperties({
                ajaxStatus: true,
                response: response
            });

        }, function(response) {

            AppC.vedaResponse.setProperties({
                ajaxStatus: false,
                response: null
            });

        });
    },

    vedaSend: function(params, endPoint) {

        return new Ember.RSVP.Promise(function(resolve, reject) {
            $.ajax({
                url: 'https://geocoderweb.veda.com.au/' + endPoint + '?max=5',
                data: params, // data sent to server
                dataType: "jsonp", // Type of response received from server

                error: function(response) {
                    reject(response);
                },

                success: function(response) {
                    resolve(response);
                },

                timeout: 5000
            });
        });
    },

    marketCellTitle: function() {

        var message = null;

        switch (this.get('marketCell')) {
            //PREMIER
            case '020':
            case '021':
            case '022':
            case '023':
            case '024':
            case '025':
            case '026':
            case '027':
            case '028':
                message = "11.69% p.a. HSBC Personal Loan for Premier customers  <br /> 11.91% Comparison rate for Premier customers.";
                break;
                //CORPORATE
            case '029':
            case '031':
            case '032':
            case '033':
            case '034':
            case '035':
            case '036':
            case '037':
                message = "11.69% p.a. HSBC Personal Loan for Corporate Partners   <br /> 11.91% Comparison rate for Corporate Partners.";
                break;
                //STAFF
            case '010':
            case '011':
            case '012':
            case '013':
            case '014':
            case '015':
            case '016':
            case '017':
            case '018':
                message = "11.69% p.a. HSBC Personal Loan for Staff   <br /> 12.02% Comparison rate for Staff.";
                break;
            default:
                //PUBLIC
                message = "11.99% p.a. HSBC Personal Loan <br /> (12.54% p.a. Comparison Rate).";
                break;
        }

        return message;
    }.property('AppC.marketCell'),

    marketCellMessage: function() {

        switch (this.get('marketCell')) {
            //PREMIER
            case '020':
            case '021':
            case '022':
            case '023':
            case '024':
            case '025':
            case '026':
            case '027':
            case '028':
                message = "The comparison rate is based on an unsecured loan of $30,000 over the term of 5 years. WARNING : This comparison rate is true only for the examples given and may not include all fees and charges. Different terms, fees or other loan amounts might result in a different comparison rate.";
                break;
                //CORPORATE
            case '029':
            case '031':
            case '032':
            case '033':
            case '034':
            case '035':
            case '036':
            case '037':
                message = "The comparison rate is based on an unsecured loan of $30,000 over the term of 5 years. WARNING : This comparison rate is true only for the examples given and may not include all fees and charges. Different terms, fees or other loan amounts might result in a different comparison rate.";
                break;
                //STAFF
            case '010':
            case '011':
            case '012':
            case '013':
            case '014':
            case '015':
            case '016':
            case '017':
            case '018':
                message = "The comparison rate is based on an unsecured loan of $30,000 over the term of 5 years. WARNING : This comparison rate is true only for the examples given and may not include all fees and charges. Different terms, fees or other loan amounts might result in a different comparison rate.";
                break;
            default:
                //PUBLIC
                message = "The comparison rate is based on an unsecured loan of $30,000 over the term of 5 years. WARNING : This comparison rate is true only for the examples given and may not include all fees and charges. Different terms, fees or other loan amounts might result in a different comparison rate.";
                break;
        }

        return message;


    }.property('AppC.marketCell'),


    hasQantas: function() {
        var result = false;
        if (this.get('productCode') === 'Q' || this.get('productCode') === 'N') {
            result = true;
        }
        return result;
    }.property('productCode'),

    isPremier: function() {
        var result = false;
        if (this.get('productCode') === 'M' || this.get('productCode') === 'N') {
            result = true;
        }
        return result;
    }.property('productCode')


});

