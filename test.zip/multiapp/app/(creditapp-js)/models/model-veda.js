/*****************************************************************************
 * MODEL Veda response
 *****************************************************************************/


AppC.VedaResponse = Ember.Object.extend({


    /**
     * Properties
     */


    ajaxStatus:false,
    response:null


});


AppC.vedaResponse = AppC.VedaResponse.create();
