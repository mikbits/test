/*****************************************************************************
 * MODEL Mother class
 *****************************************************************************/


AppC.Model = Ember.Object.extend({

    formatCurrency: function (intNum) {
        if (!AppC.StepController.prototype.formatCurrency) {
            return;
        }
        return AppC.StepController.prototype.formatCurrency(intNum);
    },


    embossing: function () {
        return this.getEmbossing(this.get('firstName'), this.get('middleName'), this.get('lastName'));
    }.property('firstName', 'middleName', 'lastName'),


    getEmbossing: function (fn, mn, ln) {
        var f = fn ? fn : '';
        var f0 = fn ? fn[0] : '';
        var m = mn ? mn : '';
        var m0 = mn ? mn[0] : '';
        var l = ln ? ln : '';
        var e0 = f + ' ' + m + ' ' + l;
        var e1 = f + ' ' + m0 + ' ' + l;
        var e2 = f + ' ' + l;
        var e3 = f0 + ' ' + l;
        var e4 = f0 + ' ' + l.slice(0, 17);

        if ((e0.length < 20) && m) {
            return e0;

        } else if (((e1.length < 20) && m)) {
            return e1;

        } else if (((e2.length < 20) && !m)) {
            return e2;

        } else if (e3.length < 20) {
            return e3;

        } else {
            return e4;
        }

    }


});
