/*****************************************************************************
 * MODEL Self ID
 *****************************************************************************/


AppC.SelfIdData = Ember.Object.extend({


    /**
     * Properties
     */
    applicantType: null,
    cdmId: null,

    // First applicant
    title: null,
    firstName: null,
    lastName: null,
    email: null,

    licenceNeeded: null,
    medicareNeeded: null,
    passportNeeded: null,
    licenceProvided: null,
    passportProvided: null,

    ozLicenceSelected: false, // Checkbox boolean
    passportSelected: false, // Checkbox boolean
    medicareSelected: false, // Checkbox boolean
    licenceState: null,
    licenceExpiryDate: null,
    licenceNumber: null,
    licenceCardNumber: null,
    photoId:null,

    ozPassportCountryBirth: null,
    ozPassportPlaceBirth: null,
    ozPassportNameBirth: null,
    ozPassportNumber: null,
    ozPassportCountry: null,

    intPassportCountry: null,
    intPassportNumber: null,
    licencePostCode: '',

    passportFirstNameCitiz: null,
    passportNameCitiz: null,
    passportState: '',

    medicareColor: null,
    medicareExpiryDate: null,
    medicareMiddleName: null,

    intPassportNumberChanged:function(){
        if(this.get('intPassportNumber')){
            this.set('photoId','IP')
        }
    }.observes('intPassportNumber'),

    ozPassportNumberChanged:function(){
        if(this.get('ozPassportNumber')){
            this.set('photoId','AP')
        }
    }.observes('ozPassportNumber'),

    licenceProvidedChanged: function(){
        this.set('ozLicenceSelected',true)
    }.observes('licenceProvided'),

    passportProvidedChanged: function(){
        this.set('passportSelected',true)
    }.observes('passportProvided'),



    /**
     * Computed properties
     */


    isVicLicence: function(){
        return this.get('ozLicenceSelected') && this.get('licenceState') === 'VIC';

    }.property('ozLicenceSelected','licenceState'),

    licenceStateRe: function () {
        return this.get('ozLicenceSelected') ? this.get('licenceState') : null;
    }.property('licenceState', 'ozLicenceSelected'),


    licenceExpiryDateRe: function () {
        return this.get('ozLicenceSelected') && this.get('licenceState') === 'WA' ? this.get('licenceExpiryDate') : null;
    }.property('licenceExpiryDate', 'ozLicenceSelected', 'licenceState'),


    licenceNumberRe: function () {
        return this.get('ozLicenceSelected') ? this.get('licenceNumber') : null;
    }.property('licenceNumber', 'ozLicenceSelected'),


    licenceCardNumberRe: function () {
        return this.get('ozLicenceSelected') && this.get('licenceState') === 'NSW' ? this.get('licenceCardNumber') : null;
    }.property('licenceCardNumber', 'ozLicenceSelected', 'licenceState'),

    licencePostCodeRe: function () {
        return this.get('ozLicenceSelected') ? this.get('licencePostCode') : null;
    }.property('licencePostCode', 'ozLicenceSelected'),

    photoIdRe: function () {
        return this.get('ozLicenceSelected') ? this.get('photoId') : null;
    }.property('ozLicenceSelected', 'photoId'),


    ozPassportCountryBirthRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('ozPassportCountryBirth') : null;
    }.property('ozPassportCountryBirth', 'photoId', 'passportSelected'),

    ozPassportCountryRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('ozPassportCountry') : null;
    }.property('ozPassportCountry', 'photoId', 'passportSelected'),


    ozPassportPlaceBirthRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('ozPassportPlaceBirth') : null;
    }.property('ozPassportPlaceBirth', 'photoId', 'passportSelected'),


    ozPassportNameBirthRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('ozPassportNameBirth') : null;
    }.property('ozPassportNameBirth', 'photoId', 'passportSelected'),


    ozPassportNumberRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('ozPassportNumber') : null;
    }.property('ozPassportNumber', 'photoId', 'passportSelected'),


    intPassportCountryRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'IP' ? this.get('intPassportCountry') : null;
    }.property('intPassportCountry', 'photoId', 'passportSelected'),


    intPassportNumberRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'IP' ? this.get('intPassportNumber') : null;
    }.property('intPassportNumber', 'photoId', 'passportSelected'),

    medicareNumberRe: function () {
        return this.get('medicareSelected') ? this.get('medicareNumber') : null;
    }.property('medicareSelected', 'medicareNumber'),

    medicareRefNumberRe: function () {
        return this.get('medicareSelected') ? this.get('medicareRefNumber') : null;
    }.property('medicareRefNumber', 'medicareSelected'),


    passportFirstNameCitizRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('passportFirstNameCitiz') : null;
    }.property('passportSelected', 'photoId', 'passportFirstNameCitiz'),

    passportNameCitizRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('passportNameCitiz') : null;
    }.property('passportSelected', 'photoId', 'passportNameCitiz'),

    passportStateRe: function () {
        return this.get('passportSelected') && this.get('photoId') === 'AP' ? this.get('passportState') : null;
    }.property('passportSelected', 'photoId', 'passportState'),


    /**
     * Methods
     */


    getselfIdData: function () {

        return {
            licenceState: this.get('licenceStateRe'),
            licenceExpiryDate: this.get('licenceExpiryDateRe'),
            licenceNumber: this.get('licenceNumberRe'),
            licenceCardNumber: this.get('licenceCardNumberRe'),
            licencePostCode: this.get('licencePostCodeRe'),
            medicareNumber: this.get('medicareNumberRe'),
            medicareRefNumber: this.get('medicareRefNumberRe'),
            medicareColor: this.get('medicareColor'),
            medicareMiddleName: this.get('medicareMiddleName'),
            medicareExpiryDate: this.get('medicareExpiryDate'),
            ozPassportCountryBirth: this.get('ozPassportCountryBirthRe'),
            ozPassportPlaceBirth: this.get('ozPassportPlaceBirthRe'),
            ozPassportNameBirth: this.get('ozPassportNameBirthRe'),
            ozPassportNumber: this.get('ozPassportNumberRe'),

            ozPassportCountry: this.get('ozPassportCountryRe'),
            intPassportCountry: this.get('intPassportCountryRe'),
            intPassportNumber: this.get('intPassportNumberRe'),
            passportFirstNameCitiz: this.get('passportFirstNameCitizRe'),
            passportNameCitiz: this.get('passportNameCitizRe'),
            passportState: this.get('passportStateRe'),
            photoId: this.get('photoIdRe')
        };

    },

    getapplicantData: function () {
        return {
            title: this.get('title'),
            lastName: this.get('lastName'),
            firstName: this.get('firstName'),
            email: this.get('email')
        }
    },

    getapplicantType: function () {
        return this.get('applicantType');
    }

});


AppC.selfIdData = AppC.SelfIdData.create();
