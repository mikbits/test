/*****************************************************************************
 * MODEL Self ID
 *****************************************************************************/


AppC.DtdAccountData = AppC.Model.extend({


    /**
     * Properties
     */

    countryTax: null,
    countryBirth: null,
    hasMultipleNat: null,
	nationality: function(){
		return AppC.step3Data.get('nationality');
	}.property('AppC.step3Data.nationality'),
    nationality2: null,
    nationality3: null,
    usPersonForTax: null,
    tfn: null,
    tfnExempted: null,
    industry: null,
    incomeSource: null,
    activities: [],
    mainReason: null,
    noDebitCard: false,
    provided: false,
    agreed: false,
	

    /**
     * Computed properties
     */

    countryTaxFull: function () {
        return AppC.countries.getName(this.get('countryTax'));
    }.property('countryTax'),

    countryBirthFull: function () {
        return AppC.countries.getName(this.get('countryBirth'));
    }.property('countryBirth'),

    nationality2Full: function () {
        return AppC.countries.getName(this.get('nationality2'));
    }.property('nationality2'),

    nationality3Full: function () {
        return AppC.countries.getName(this.get('nationality3'));
    }.property('nationality3'),

    nationality2Re:function () {
        return this.get('hasMultipleNat') ? this.get('nationality2') : null;
    }.property('nationality2', 'hasMultipleNat'),

    nationality3Re: function () {
        var value = this.get('nationality3');
        return (this.get('hasMultipleNat') && (value != 'seperator')) ? value : null;
    }.property('nationality3', 'hasMultipleNat'),	
	
    tfnExemptedFull: function () {
        return AppC.tfnExemptions.getName(this.get('tfnExempted'));
    }.property('tfnExempted'),

    industryFull: function () {
        return AppC.industries.getName(this.get('industry'));
    }.property('industry'),

    incomeSourceFull: function () {
        return AppC.incomes.getName(this.get('incomeSource'));
    }.property('incomeSource'),

    activitiesFull: function () {
        return this.getActivStr();
    }.property('activities'),

    mainReasonFull: function () {
        return AppC.purposes.getName(this.get('mainReason'));
    }.property('mainReason'),


    /**
     * Methods
     */

    getActivStr: function () {
        var arr = this.get('activities'), str = '';
        $.each(arr, function (i, v) {
            str += AppC.activities.getName(v) + '<br>';
        });
        return str;
    },

    getObject: function () {

        var obj = {
            countryTax: this.get('countryTax'),
            //countryBirth: this.get('countryBirth'),
            tfn: this.get('tfn'),
            tfnExempted: this.get('tfnExempted'),
            industry: this.get('industry'),
            incomeSource: this.get('incomeSource'),
            activities: this.get('activities'),
            mainReason: this.get('mainReason'),
            noDebitCard: this.get('noDebitCard'),
            nationality2:this.get('nationality2Re'),
            nationality3:this.get('nationality3Re'),
	    usPersonForTax:this.get('usPersonForTax')
        };

        return obj;

    },

    getSubmitObj: function () {

        return {
            provided: this.get('provided'),
            agreed: this.get('agreed')
        }

    }


});


AppC.dtdAccountData = AppC.DtdAccountData.create();
