
/*****************************************************************************
 * MODEL Step 2
 *****************************************************************************/


AppC.Step2Data = AppC.Model.extend({


    /**
     * Properties
     */

    // New
    isSso: false,
    isCustomer: null,


    isCustomerChanged: function() {
        if (!AppC.step2Data.get('existingCustomerNo') && AppC.isWoolworths) {
            AppC.step2Data.set('existingCustomerNo', 9344);
        }
    }.observes('isCustomer'),
    

    numOfCardsChanged: function() {
    	if(this.get('numOfCards')<3){
    		this.set('cardNum3',null);
    		this.set('cardIssuedBy3',null);
    		this.set('cardBalTranAmt3',null);
    	}
    	if(this.get('numOfCards')<2){
    		this.set('cardNum2',null);
    		this.set('cardIssuedBy2',null);
    		this.set('cardBalTranAmt2',null);
    	}
    	if(this.get('numOfCards')<1){
    		this.set('cardNum1',null);
    		this.set('cardIssuedBy1',null);
    		this.set('cardBalTranAmt1',null);
    		this.set('balanceTransfer',null);
    		
    		this.set('totalBalOwing',null);
    		this.set('combCreditLmt',null);
    	}
    }.observes('numOfCards'),

    

    existingCustomerNo: null,
    timeMBankYear: null,
    timeMBankMonth: null,
    combCreditLmt: null,
    numOfCards: null,
    totalBalOwing: null,
    balanceTransfer: null,

    cardNum1: null,
    cardIssuedBy1: null,
    cardBalTranAmt1: null,

    cardNum2: null,
    cardIssuedBy2: null,
    cardBalTranAmt2: null,

    cardNum3: null,
    cardIssuedBy3: null,
    cardBalTranAmt3: null,

    currentCard: 1,
    ddAcctHolder: null,
    ddFinInst: null,
    otherFinInst: null,

    ddAcctNum: null,
    ddAcctBSB: null,
    isShowII: false,


    /**
     * Computed properties for back-end
     */

    existingCustomerNoRe: function () {
        return this.get('isCustomer') ? this.get('existingCustomerNo') : null;
    }.property('isCustomer', 'existingCustomerNo'),

    combCreditLmtRe: function () {
        return parseInt(this.get('numOfCards')) > 0 ? this.get('combCreditLmt') : null;
    }.property('numOfCards', 'combCreditLmt'),

    totalBalOwingRe: function () {
        return parseInt(this.get('numOfCards')) > 0 ? this.get('totalBalOwing') : null;
    }.property('numOfCards', 'totalBalOwing'),

    combCreditLmtFormat: function () {
        return this.formatCurrency(this.get('combCreditLmt'));
    }.property('combCreditLmt'),

    totalBalOwingFormat: function () {
        return this.formatCurrency(this.get('totalBalOwing'));
    }.property('totalBalOwing'),


    balanceTransferRe: function () {
        return (this.get('combCreditLmt') && this.get('totalBalOwing') && (parseInt(this.get('combCreditLmt')) >= parseInt(this.get('totalBalOwing')))) ? this.get('balanceTransfer') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer'),

    cardNum1Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardNum1') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'cardNum1'),

    cardIssuedBy1Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardIssuedBy1') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'cardIssuedBy1'),

    cardBalTranAmt1Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardBalTranAmt1') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'cardBalTranAmt1'),



    cardBalTranAmt1Format: function () {
        return this.get('balanceTransferRe') ? this.formatCurrency(this.get('cardBalTranAmt1')) : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'cardBalTranAmt1'),



    cardNum2Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardNum2') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardNum2'),

    cardIssuedBy2Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardIssuedBy2') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardIssuedBy2'),

    cardBalTranAmt2Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardBalTranAmt2') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardBalTranAmt2'),



    cardBalTranAmt2Format: function () {
        return this.get('balanceTransferRe') ? this.formatCurrency(this.get('cardBalTranAmt2')) : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardBalTranAmt2'),



    cardNum3Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardNum3') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardNum3'),

    cardIssuedBy3Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardIssuedBy3') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardIssuedBy3'),

    cardBalTranAmt3Re: function () {
        return this.get('balanceTransferRe') ? this.get('cardBalTranAmt3') : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardBalTranAmt3'),



    cardBalTranAmt3Format: function () {
        return this.get('balanceTransferRe') ? this.formatCurrency(this.get('cardBalTranAmt3')) : null;
    }.property('combCreditLmt', 'totalBalOwing', 'balanceTransfer', 'currentCard', 'cardBalTranAmt3'),

    showCreditLmt: function(){
        return parseInt(this.get('numOfCards')) > 0 ? true : false;
    }.property('numOfCards'),

    showBalanceTransfer: function(){
        return !AppC.get('isLoan') && !AppC.get('isInRa') && this.get('numOfCards')>0;
    }.property('AppC.isLoan', 'AppC.isInRa','numOfCards'),

    showCard2: function(){
        return this.get('currentCard') >= 2 || this.get('cardNum2') ? true : false;
    }.property('numOfCards', 'currentCard', 'cardNum2'),

    showCard3: function(){
        return this.get('currentCard') == 3 || this.get('cardNum3')? true : false;
    }.property('numOfCards', 'currentCard', 'cardNum3'),

    addCard: function(){
        return parseInt(this.get('numOfCards')) > this.get('currentCard') && this.get('currentCard') != 3 ? true : false;
    }.property('numOfCards', 'currentCard'),

    removeCard: function(){
        return parseInt(this.get('numOfCards')) > 1 && this.get('currentCard') > 1 || this.get('cardNum3') || this.get('cardNum2') ? true : false;
    }.property('numOfCards', 'currentCard', 'cardNum2', 'cardNum3'),

    ddAcctHolderRe: function () {
        return AppC.get('isLoan') ? this.get('ddAcctHolder') : null;
    }.property('AppC.isLoan', 'ddAcctHolder'),

    ddFinInstRe: function () {
        return AppC.get('isLoan') ? this.get('ddFinInst') : null;
    }.property('AppC.isLoan', 'ddFinInst'),

    isOtherDdFinInst: function () {
        var bool = false;
        if (this.get('ddFinInst') == 'OTHER') {
            bool = true;
        }
        return bool;
    }.property('ddFinInst'),

    ddAcctNumRe: function () {
        return AppC.get('isLoan') ? this.get('ddAcctNum') : null;
    }.property('AppC.isLoan', 'ddAcctNum'),

    ddAcctBSBRe: function () {
        return AppC.get('isLoan') ? this.get('ddAcctBSB') : null;
    }.property('AppC.isLoan', 'ddAcctBSB'),

    getObject: function () {

        return {
            isCustomer: this.get('isCustomer'),
            existingCustomerNo: this.get('existingCustomerNoRe'),
            timeMBankYear: this.get('timeMBankYear'),
            timeMBankMonth: this.get('timeMBankMonth'),
            combCreditLmt: this.get('combCreditLmtRe'),
            numOfCards: this.get('numOfCards'),
            totalBalOwing: this.get('totalBalOwingRe'),

            cardNum1: this.get('cardNum1Re'),
            cardIssuedBy1: this.get('cardIssuedBy1Re'),
            cardBalTranAmt1: this.get('cardBalTranAmt1Re'),

            cardNum2: this.get('cardNum2Re'),
            cardIssuedBy2: this.get('cardIssuedBy2Re'),
            cardBalTranAmt2: this.get('cardBalTranAmt2Re'),

            cardNum3: this.get('cardNum3Re'),
            cardIssuedBy3: this.get('cardIssuedBy3Re'),
            cardBalTranAmt3: this.get('cardBalTranAmt3Re'),

            ddAcctHolder: this.get('ddAcctHolderRe'),
            ddFinInst: this.get('ddFinInstRe'),
            otherFinInst: this.get('otherFinInst'),
            ddAcctNum: this.get('ddAcctNumRe'),
            ddAcctBSB: this.get('ddAcctBSBRe'),
            balanceTransfer: this.get('balanceTransfer')
        };

    }


});


AppC.step2Data = AppC.Step2Data.create();

