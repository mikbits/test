/*****************************************************************************
 * MODEL Step 5
 *****************************************************************************/


AppC.Step5Data = AppC.Model.extend({


    /**
     * Properties
     */

    // if the limited
    //geo code
    addr4Validated: null,

    isPartnerOutAdd: false,

    isLimited: null,
    isJoint: null,
    partnerHasSameAddress: true,

    salaryWtTax: null,
    salaryFreq: null,

    incomeWtTax: null,
    incomeFreq: null,

    incomeGross: null,


    partnerIncomeWtTax: null,
    partnerIncomeFreq: null,
    residentialStatus: null,

    valueOfEstate: null,

    valueOfVehiclesOrBoats: null,
    valueOfSavingShares: null,

    shareOfMortgageOrRent: null,
    shareOfOtherLoans: null,
    shareOfLivingExp: null,
    totalMortgageBal: null,

    limitDesired: null,

    addressLive: null,

    partnerAddress: null,
    partnerTitle: null,
    partnerFirstName: null,
    partnerMiddleName: null,
    partnerLastName: null,

    partnerGender: null,
    partnerBirthDate: null,
    partnerNationality: null,
    partnerOccupation: null,
    partnerHomePhone: null,
    partnerMobilePhone: null,

    partnerAddressUnitNb: null,
    partnerAddressStreetNb: null,
    partnerAddressStreet: null,
    partnerAddressStreetType: null,
    partnerAddressSuburb: null,
    partnerAddressState: null,
    partnerAddressPostcode: null,

    partnerIntAddr1: null,
    partnerIntAddr2: null,
    partnerIntAddr3: null,
    partnerAddressCountry: null,

    isIntMobilePhone: null,
    partnerIntMobilePhone: null,

    isIntHomePhone: null,
    partnerIntHomePhone: null,

    partnerCardColour: null,
    partnerCustRewardInd: null,
    partnerCustRewardNum: null,


    partnerTitleRe: function () {
        return this.get('isJoint') ? this.get('partnerTitle') : null;
    }.property('isJoint', 'partnerTitle'),

    partnerFirstNameRe: function () {
        return this.get('isJoint') ? this.get('partnerFirstName') : null;
    }.property('isJoint', 'partnerFirstName'),


    partnerMiddleNameRe: function () {
        return this.get('isJoint') ? this.get('partnerMiddleName') : null;
    }.property('isJoint', 'partnerMiddleName'),

    partnerLastNameRe: function () {
        return this.get('isJoint') ? this.get('partnerLastName') : null;
    }.property('isJoint', 'partnerLastName'),



    partnerGenderRe: function () {
        return this.get('isJoint') ? this.get('partnerGender') : null;
    }.property('isJoint', 'partnerGender'),


    partnerBirthDateRe: function () {
        return this.get('isJoint') ? this.get('partnerBirthDate') : null;
    }.property('isJoint', 'partnerBirthDate'),


    partnerNationalityRe: function () {
        return this.get('isJoint') ? this.get('partnerNationality') : null;
    }.property('isJoint', 'partnerNationality'),


    partnerOccupationRe: function () {
        return this.get('isJoint') ? this.get('partnerOccupation') : null;
    }.property('isJoint', 'partnerOccupation'),


    partnerHomePhoneRe: function () {
        var value = this.get('isJoint') ? this.get('partnerHomePhone') : null;
        if (value) {
            return value.replace(/\-/g, '');
        } else {
            return null;
        }
    }.property('isJoint', 'partnerHomePhone'),


    partnerMobilePhoneRe: function () {
        var value = this.get('isJoint')? this.get('partnerMobilePhone') : null;
        if (value) {
            return value.replace(/\-/g, '');
        } else {
            return null;
        }
    }.property('isJoint', 'partnerMobilePhone'),


    partnerAddressUnitNbRe: function () {
        return this.get('isJoint') ? this.get('partnerAddressUnitNb') : null;
    }.property('isJoint', 'partnerAddressUnitNb', 'partnerHasSameAddress'),



    partnerAddressStreetNbRe: function () {
        return this.get('isJoint') ? this.get('partnerAddressStreetNb') : null;
    }.property('isJoint', 'partnerAddressStreetNb', 'partnerHasSameAddress'),



    partnerAddressStreetRe: function () {
        return this.get('isJoint') ? this.get('partnerAddressStreet') : null;
    }.property('isJoint', 'partnerAddressStreet', 'partnerHasSameAddress'),


    partnerAddressStreetTypeRe: function () {
        return this.get('isJoint')  ? this.get('partnerAddressStreetType') : null;
    }.property('isJoint', 'partnerAddressStreetType', 'partnerHasSameAddress'),


    partnerAddressSuburbRe: function () {
        return this.get('isJoint')  ? this.get('partnerAddressSuburb') : null;
    }.property('isJoint', 'partnerAddressSuburb', 'partnerHasSameAddress'),


    partnerAddressStateRe: function () {
        return this.get('isJoint') ? this.get('partnerAddressState') : null;
    }.property('isJoint', 'partnerAddressState', 'partnerHasSameAddress'),


    partnerAddressPostcodeRe: function () {
        return this.get('isJoint') ? this.get('partnerAddressPostcode') : null;
    }.property('isJoint', 'partnerAddressPostcode', 'partnerHasSameAddress'),

    partnerIntAddr1Re: function () {
        return this.get('isPartnerOutAdd') ? this.get('partnerIntAddr1') : null;
    }.property('isPartnerOutAdd', 'partnerIntAddr1'),

    partnerIntAddr2Re: function () {
        return this.get('isPartnerOutAdd') ? this.get('partnerIntAddr2') : null;
    }.property('isPartnerOutAdd', 'partnerIntAddr2'),

    partnerIntAddr3Re: function () {
        return this.get('isPartnerOutAdd') ? this.get('partnerIntAddr3') : null;
    }.property('isPartnerOutAdd', 'partnerIntAddr3'),

    partnerAddressCountryRe: function () {
        return this.get('isPartnerOutAdd') ? this.get('partnerAddressCountry') : null;
    }.property('isPartnerOutAdd', 'partnerAddressCountry'),

    limitDesiredRe: function () {
        return this.get('isLimited') ? this.get('limitDesired') : null;
    }.property('isLimited', 'limitDesired'),

    limitDesiredFormat: function () {
        return this.formatCurrency(this.get('limitDesired'));
    }.property('limitDesired'),

    /**
     * Other computed properties
     */

    partnerGenderLong: function () {
        return AppC.genders.getName(this.get('partnerGender'));
    }.property('partnerGender'),


    partnerOccupationLong: function () {
        return AppC.occupations.getName(this.get('partnerOccupation'));
    }.property('partnerOccupation'),

    partnerNationalityLong: function () {
        return AppC.countries.getName(this.get('partnerNationality'));
    }.property('partnerNationality'),

    partnerOccupationLong: function () {
        return AppC.occupations.getName(this.get('partnerOccupation'));
    }.property('partnerOccupation'),

    salaryWtTaxRe: function () {
        return this.formatCurrency(this.get('salaryWtTax'));
    }.property('salaryWtTax'),

    incomeWtTaxRe: function () {
        return this.formatCurrency(this.get('incomeWtTax'));
    }.property('incomeWtTax'),

    partnerIncomeWtTaxRe: function () {
        return this.formatCurrency(this.get('partnerIncomeWtTax'));
    }.property('partnerIncomeWtTax'),

    valueOfEstateRe: function () {
        return this.formatCurrency(this.get('valueOfEstate'));
    }.property('valueOfEstate'),

    valueOfVehiclesOrBoatsRe: function () {
        return this.formatCurrency(this.get('valueOfVehiclesOrBoats'));
    }.property('valueOfVehiclesOrBoats'),

    valueOfSavingSharesRe: function () {
        return this.formatCurrency(this.get('valueOfSavingShares'));
    }.property('valueOfSavingShares'),

    shareOfMortgageOrRentRe: function () {
        return this.formatCurrency(this.get('shareOfMortgageOrRent'));
    }.property('shareOfMortgageOrRent'),

    shareOfOtherLoansRe: function () {
        return this.formatCurrency(this.get('shareOfOtherLoans'));
    }.property('shareOfOtherLoans'),

    shareOfLivingExpRe: function () {
        return this.formatCurrency(this.get('shareOfLivingExp'));
    }.property('shareOfLivingExp'),

    salaryFreqLong: function () {
        return AppC.period.getName(this.get('salaryFreq'));
    }.property('salaryFreq'),

    incomeFreqLong: function () {
        return AppC.period.getName(this.get('incomeFreq'));
    }.property('incomeFreq'),

    partnerIncomeFreqLong: function () {
        return AppC.period.getName(this.get('partnerIncomeFreq'));
    }.property('partnerIncomeFreq'),





    /**
     * Methods
     */


    getObject: function () {
        var obj = {
            salaryWtTax: this.get('salaryWtTax'),
            salaryFreq: this.get('salaryFreq'),
            incomeWtTax: this.get('incomeWtTax'),
            incomeFreq: this.get('incomeFreq'),
            incomeGross: this.get('incomeGross'),
            partnerIncomeWtTax: this.get('partnerIncomeWtTax'),
            partnerIncomeFreq: this.get('partnerIncomeFreq'),
            residentialStatus: this.get('residentialStatus'),

            valueOfEstate: this.get('valueOfEstate')?this.get('valueOfEstate'):0,
            valueOfVehiclesOrBoats: this.get('valueOfVehiclesOrBoats'),
            valueOfSavingShares: this.get('valueOfSavingShares'),


            shareOfMortgageOrRent: this.get('shareOfMortgageOrRent'),
            shareOfOtherLoans: this.get('shareOfOtherLoans'),
            shareOfLivingExp: this.get('shareOfLivingExp'),
            totalMortgageBal: this.get('totalMortgageBal')?this.get('totalMortgageBal'):0,

            limitDesired: this.get('limitDesiredRe'),
            isLimited: this.get('isLimited'),
            isJoint: this.get('isJoint'),
            partnerHasSameAddress: this.get('partnerHasSameAddress')
            };

        if (this.get('isJoint')) {
            obj.partnerTitle = this.get('partnerTitleRe'),
            obj.partnerFirstName = this.get('partnerFirstNameRe'),
            obj.partnerMiddleName = this.get('partnerMiddleNameRe'),
            obj.partnerLastName = this.get('partnerLastNameRe'),
            obj.partnerGender = this.get('partnerGenderRe'),
            obj.partnerBirthDate = this.get('partnerBirthDateRe'),
            obj.partnerNationality = this.get('partnerNationalityRe'),
            obj.partnerOccupation = this.get('partnerOccupationRe'),
            obj.partnerHomePhone = this.get('partnerHomePhoneRe'),
            obj.partnerMobilePhone = this.get('partnerMobilePhoneRe'),
            obj.partnerCardColour = this.get('partnerCardColour'),
            obj.partnerCustRewardInd = this.get('partnerCustRewardInd'),
            obj.partnerCustRewardNum = this.get('partnerCustRewardNum')
        };

        if (!this.get('partnerHasSameAddress')) {
            obj.partnerAddressUnitNb = this.get('partnerAddressUnitNbRe'),
            obj.partnerAddressStreetNb = this.get('partnerAddressStreetNbRe'),
            obj.partnerAddressStreet = this.get('partnerAddressStreetRe'),
            obj.partnerAddressStreetType = this.get('partnerAddressStreetTypeRe'),
            obj.partnerAddressSuburb = this.get('partnerAddressSuburbRe'),
            obj.partnerAddressState = this.get('partnerAddressStateRe'),
            obj.partnerAddressPostcode = this.get('partnerAddressPostcodeRe')
        };

        return obj;

    }


});


AppC.step5Data = AppC.Step5Data.create();
