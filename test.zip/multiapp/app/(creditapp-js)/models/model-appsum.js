/*****************************************************************************
 * MODEL Application summary
 *****************************************************************************/


AppC.AppSumData = Ember.Object.extend({


    /**
     * Properties
     */


    applicationId: null,
    branch: null,
    name: null,
    status: null,
    step: null,
    dateSubmitted: null,
    lastUpdateDate: null,
    productName: null,


    /**
     * Computed properties
     */


    accounts: function () {

        var acc = '';

        acc += this.productName;
        acc += '<br/>';

        return acc;

    }.property('productName')


});
