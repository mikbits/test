/*****************************************************************************
 * MODEL Ramp
 *****************************************************************************/


AppC.EntryData = AppC.Model.extend({


    /**
     * Properties
     */


    estimatedFinanceAmount: null,
    customerAtMerchantStore: true,
    customerAtState: null,
    storeId: null,
    staffId: null,
    branchId: null,

    storeIdRe: function () {
        return this.get('customerAtMerchantStore') ? this.get('storeId') : null;
    }.property('customerAtMerchantStore', 'storeId'),

    getObject: function () {
        return {
            estimatedFinanceAmount: this.get('estimatedFinanceAmount'),
            customerAtMerchantStore: this.get('customerAtMerchantStore'),
            storeId: this.get('storeIdRe'),
            staffId: this.get('staffId'),
            branchId: this.get('branchId'),
            customerAtState: this.get('customerAtState')
        };
    }

});


AppC.entryData = AppC.EntryData.create();
