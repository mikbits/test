/*****************************************************************************
 * MODEL Response
 *****************************************************************************/


AppC.ResponseData = AppC.Model.extend({


    title: null,
    firstName: null,
    lastName: null,
    email: null,
    partnerFirstName: null,
    partnerLastName: null,
    applicationId: null,

    applicantData: {},
    productData: {},
	purchaseData: {},
	
    partnerData:null,


    /**
     * Pending ID
     */


    pendingId: null,
    partnerPendingId: null,
	redirectURL: null,

	outcomeStatusINCOME: Em.computed.alias('AppC.outcomeStatusINCOME'),
	outcomeStatusIDINCOME: Em.computed.alias('AppC.outcomeStatusIDINCOME'),
	outcomeStatusINCOMEADDR: Em.computed.alias('AppC.outcomeStatusINCOMEADDR'),


    /**
     * Common part
     */


    creditLimitRe: function () {
        var amount = AppC.get('isLoan') ? "loan amount of " + this.formatCurrency(this.productData.loanAmt) : "credit limit of " + this.formatCurrency(this.productData.creditLimit);
        return amount;
    }.property('productData.creditLimit', 'AppC.isLoan', 'productData.loanAmt'),


    creditLimitFormatRe: function () {
        var amount = AppC.get('isLoan') ? this.formatCurrency(this.productData.loanAmt) : this.formatCurrency(this.productData.creditLimit);
        return amount;
    }.property('productData.creditLimit', 'AppC.isLoan', 'productData.loanAmt'),

    finAmountRe: function () {
        var amount = this.applicantData.estimatedFinanceAmount,
            limit = this.productData.creditLimit;
        if (Math.round(amount) > Math.round(limit)){
            return "This is less than the finance amount " + this.formatCurrency(amount) + " you applied for.<br>You need to find alternative means to bridge the gap.";
        } else {
            return "This covers the finance amount " + this.formatCurrency(amount) + " you applied for.";
        }
    }.property('applicantData.estimatedFinanceAmount', 'productData.creditLimit'),

    applicationIdRe: function () {
        return this.get('applicationId');
    }.property('applicationId'),
    /**
     * Approved
     */


    isJoint: null,
    bundle: null,

    bsb: null,
    bsbAccountNb: null,
    accountStatus: null,

    personalBankingNb: null,

    d2dBsb: null,
    d2dAccountNb: null,
    mcBsb: null,
    mcAccountNb: null,
    ssBsb: null,
    ssAccountNb: null,
    fsBsb: null,
    fsAccountNb: null,
    ostBsb: null,
    ostAccountNb: null,
    bankingNb: null,
    partnerBankingNb: null,
    multicurrencyMain: null,
    otherCurrencies: [],
    ostStatus:null,
    ostUser: null,


    /**
     * Conditional Approved
     */


    hsbcBranch: null,
    ausPost: null,
    hsbcBranchThd: null,
    ausPostFax: null,
    raName: null,
    storeId: null,
    finAmount: null,
    maintenanceFinishHoursMinutes: null,


    /**
     * Self ID
     */


    selfIdData: null,

    isOstSuccess: function () {
        var result=false;
        if(this.get('ostStatus')==='Y'){
            result=true;
        }
        return result;
    }.property('ostStatus'),

    isOstError: function () {
        var result=false;
        if(this.get('ostStatus')==='E'){
            result=true;
        }
        return result;
    }.property('ostStatus'),

    isOstFailed: function () {
        var result=false;
        if(this.get('ostStatus')==='N'){
            result=true;
        }
        return result;
    }.property('ostStatus'),

    divideArrowClass: function(){
        var counter=0;
        if(this.get('d2dAccountNb')){
            counter=counter+1;
        }
        if(this.get('mcAccountNb')){
            counter=counter+1;
        }
        if(this.get('ssAccountNb')){
            counter=counter+1;
        }
        if(this.get('fsAccountNb')){
            counter=counter+1;
        }
        if(this.get('ostUser')){
            counter=counter+1;
        }
        return 'divide-arrow-multi'+counter;
    }.property('d2dAccountNb','mcAccountNb','ssAccountNb','fsAccountNb','ostUser')


});


AppC.responseData = AppC.ResponseData.create();
