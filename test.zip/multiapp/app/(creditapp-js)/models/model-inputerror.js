/*****************************************************************************
 * MODEL Input error
 *****************************************************************************/


AppC.InputError = Ember.Object.extend({


    /**
     * Properties
     */


    field:null, // String
    error:null, // Boolean


    /**
     * Life cycle hooks
     */


    init:function (field, error) {
        this._super();
        this.set('field', field);
        this.set('error', error);
    }


});
