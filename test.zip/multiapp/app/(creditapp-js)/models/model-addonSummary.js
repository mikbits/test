/*****************************************************************************
 * MODEL Select Product
 *****************************************************************************/


AppC.AddonSummaryData = AppC.Model.extend({


    /**
     * Properties
     */

	applicationNumber:null,
	merchantTxnRefId:null,
	authorisationNumber:null,
	merchantGroup:null,
	cardNo:null,
	promoTerm:null,
	financeAmount:null,
	highestValueGoodsPrice:null,
	highestValueGoodsDesc:null,
	pickupStoreIds:null,
	customerName:null,
	customerDob:null,
	status:null,
	createDate:null,
	lastUpdateDate:null,

	isDeclined: function(){
        return this.get('status') == "DE";
    }.property('status'),
	
    getObject: function () {
        return {
            applicationNumber: this.get('applicationNumber'),
            merchantTxnRefId: this.get('merchantTxnRefId'),
			authorisationNumber:this.get('authorisationNumber'),
            merchantGroup: this.get('merchantGroup'),
            cardNo: this.get('cardNo'),
            promoTerm: this.get('promoTerm'),
            financeAmount: this.get('financeAmount'),
			highestValueGoodsPrice:this.get('highestValueGoodsPrice'),
			highestValueGoodsDesc:this.get('highestValueGoodsDesc'),
			pickupStoreIds:this.get('pickupStoreIds'),
			customerName:this.get('customerName'),
			customerDob:this.get('customerDob'),
			status:this.get('status'),
			createDate:this.get('createDate'),
			lastUpdateDate:this.get('lastUpdateDate')
        };
    }

});


AppC.addonSummaryData = AppC.AddonSummaryData.create();
