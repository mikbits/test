/*****************************************************************************
 * MODEL Step 6
 *****************************************************************************/


AppC.Step6Data = AppC.Model.extend({


    /**
     * Properties
     */


    creditLimitIncrease:null, // Default value
    creditLimitEMGIncrease:null, // Default value


    agreePCD:false, // Default
    agreeConditonsOfUse:false,

    userInput: null,
    captchErrorMessage:null,


    getObject:function () {

        return {

            creditLimitIncrease: this.get('creditLimitIncrease'),
            creditLimitEMGIncrease: this.get('creditLimitEMGIncrease'),

            agreePCD: this.get('agreePCD'),
            agreeConditonsOfUse: this.get('agreeConditonsOfUse'),

            userInput:this.get('userInput')
        };

    }



});


AppC.step6Data = AppC.Step6Data.create();
