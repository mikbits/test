/*****************************************************************************
 * MODEL Step 4
 *****************************************************************************/


AppC.Step4Data = AppC.Model.extend({


    /**
     * Properties
     */

    // GeoCode
    addr1Validated: null,
    addr2Validated: null,
    addr3Validated: null,
    addr5Validated: null,

    address: null,
    employerAddress: null,

    // applicant
    unitNb: null,
    streetNb: null,
    street: null,
    streetType: null,
    suburb: null,
    state: null,
    postcode: null,

    previousAddressUnitNb: null,
    previousAddressStreetNb: null,
    previousAddressStreet: null,
    previousAddressStreetType: null,
    previousAddressSuburb: null,
    previousAddressState: null,
    previousAddressPostcode: null,

    years: null,
    months: null,

    relativeTitle: null,
    relativeFirstName: null,
    relativeLastName: null,
    relativePhoneNum: null,
    relativeRelationship: null,

    employmentStatus: null,
    employerName: null,
    employerPhoneNum: null,
    employerAddressUnitNb: null,
    employerAddressStreetNb: null,
    employerAddressStreet: null,
    employerAddressStreetType: null,
    employerAddressSuburb: null,
    employerAddressState: null,
    employerAddressPostcode: null,

    selfEmployerAddressUnitNb: null,
    selfEmployerAddressStreetNb: null,
    selfEmployerAddressStreet: null,
    selfEmployerAddressStreetType: null,
    selfEmployerAddressSuburb: null,
    selfEmployerAddressState: null,
    selfEmployerAddressPostcode: null,
    
    
    
    employeeYears: null,
    employeeMonths: null,

    contractLengthYears: null,
    contractlengthMonths: null,

    occupation: null,
    job: null,

    businessNature: null,


    /**
     *  Computed properties for back-end
     */


    relativePhoneNumRe: function () {

        var phoneNum = this.get('relativePhoneNum') || null;

        if (phoneNum) {
            return phoneNum.replace(/\-/g, '');
        } else {
            return null;
        }

    }.property('relativePhoneNum'),

    employerPhoneNumRe: function () {
        var phoneNum = this.get('employerPhoneNum') || null;

        if (phoneNum) {
            return phoneNum.replace(/\-/g, '');
        } else {
            return null;
        }

    }.property('employerPhoneNum'),

    employmentStatusLong: function () {
        return AppC.employmentstatus.getName(this.get('employmentStatus'));
    }.property('employmentStatus'),

    relativeRelationshipLong: function () {
        return AppC.relationship.getName(this.get('relativeRelationship'));
    }.property('relativeRelationship'),



    getObject: function () {

        var obj = {
            unitNb: this.get('unitNb'),
            streetNb: this.get('streetNb'),
            street: this.get('street'),
            streetType: this.get('streetType'),
            suburb: this.get('suburb'),
            state: this.get('state'),
            postcode: this.get('postcode'),
            years: this.get('years'),
            months: this.get('months'),

            relativeTitle: this.get('relativeTitle'),
            relativeFirstName: this.get('relativeFirstName'),
            relativeLastName: this.get('relativeLastName'),
            relativePhoneNum: this.get('relativePhoneNumRe'),
            relativeRelationship: this.get('relativeRelationship'),
            employmentStatus: this.get('employmentStatus')
        };

        if (parseInt(this.get('years')) < 3) {
            obj.previousAddressUnitNb = this.get('previousAddressUnitNb'),
            obj.previousAddressStreetNb = this.get('previousAddressStreetNb'),
            obj.previousAddressStreet = this.get('previousAddressStreet'),
            obj.previousAddressStreetType = this.get('previousAddressStreetType'),
            obj.previousAddressSuburb = this.get('previousAddressSuburb'),
            obj.previousAddressState = this.get('previousAddressState'),
            obj.previousAddressPostcode = this.get('previousAddressPostcode')
        };

        if (
            this.get('employmentStatus') == 'F' ||
            this.get('employmentStatus') == 'P' ||
            this.get('employmentStatus') == 'C' ||
            this.get('employmentStatus') == 'A' ||
            this.get('employmentStatus') == 'S' ||
            this.get('employmentStatus') == 'O'
        ){

            if (this.get('employmentStatus') == 'C') {
                obj.contractLengthYears = this.get('contractLengthYears'),
                obj.contractlengthMonths = this.get('contractlengthMonths')
            }

            if (this.get('employmentStatus') == 'S') {
                obj.businessNature = this.get('businessNature'),
                obj.employerAddressUnitNb = this.get('selfEmployerAddressUnitNb'),
                obj.employerAddressStreetNb = this.get('selfEmployerAddressStreetNb'),
                obj.employerAddressStreet = this.get('selfEmployerAddressStreet'),
                obj.employerAddressStreetType = this.get('selfEmployerAddressStreetType'),
                obj.employerAddressSuburb = this.get('selfEmployerAddressSuburb'),
                obj.employerAddressState = this.get('selfEmployerAddressState'),
                obj.employerAddressPostcode = this.get('selfEmployerAddressPostcode')
            }else{
                obj.employerAddressUnitNb = this.get('employerAddressUnitNb'),
                obj.employerAddressStreetNb = this.get('employerAddressStreetNb'),
                obj.employerAddressStreet = this.get('employerAddressStreet'),
                obj.employerAddressStreetType = this.get('employerAddressStreetType'),
                obj.employerAddressSuburb = this.get('employerAddressSuburb'),
                obj.employerAddressState = this.get('employerAddressState'),
                obj.employerAddressPostcode = this.get('employerAddressPostcode')
            }

            obj.occupation = this.get('occupation'),
            obj.job = this.get('job'),


            obj.employerName = this.get('employerName'),
            obj.employerPhoneNum = this.get('employerPhoneNumRe'),
            obj.employeeYears = this.get('employeeYears'),
            obj.employeeMonths = this.get('employeeMonths')
        }


        return obj;

    }


});


AppC.step4Data = AppC.Step4Data.create();
