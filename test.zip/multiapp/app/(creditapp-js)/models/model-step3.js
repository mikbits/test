/*****************************************************************************
 * MODEL Step 3
 *****************************************************************************/


AppC.Step3Data = AppC.Model.extend({


    /**
     * Properties
     */

    // First applicant
    gender: null,
    maritalStatus: null,
    isResident: null,
    nationality: null,
    numOfDependants: null,
    qffNum: null,

    licenceState: null,
    licenceNumber: null,

    photoId: 'DL',
    ozPassportCountryBirth: null,
    ozPassportPlaceBirth: null,
    ozPassportNameBirth: null,

    passportNameCitiz: null,
    passportFirstNameCitiz: null,

    ozPassportNumber: null,
    intPassportCountry: null,
    intPassportNumber: null,
    licenceExpiryDate: null,
    licenceCardNumber: null,
    licencePostCode: null,
    passportState: '',
    isAltPhotoId: null,

    /**
     * Other computed properties
     */

    intPassportCountryLong: function () {
        return AppC.countries.getName(this.get('intPassportCountry'));
    }.property('intPassportCountry'),

    ozPassportCountryBirthLong: function () {
        return AppC.countries.getName(this.get('ozPassportCountryBirth'));
    }.property('aupassport'),

    nationalityLong: function () {
        return AppC.countries.getName(this.get('nationality'));
    }.property('nationality'),




    licenceCardNumberRe: function () {
        return this.get('photoId') === 'DL' && this.get('licenceState') === 'NSW' ? this.get('licenceCardNumber') : null;
    }.property('photoId', 'licenceState', 'licenceCardNumber'),

    licenceExpiryDateRe: function () {
        return this.get('photoId') === 'DL' && this.get('licenceState') === 'WA' ? this.get('licenceExpiryDate') : null;
    }.property('photoId', 'licenceState', 'licenceExpiryDate'),

    licenceNumberRe: function () {
        return this.get('photoId') === 'DL'? this.get('licenceNumber') : null;
    }.property('photoId', 'licenceNumber'),

    licenceStateRe: function () {
        return this.get('photoId') === 'DL'? this.get('licenceState') : null;
    }.property('photoId', 'licenceState'),



    ozPassportCountryBirthRe: function () {
        return this.get('photoId') === 'AP'? this.get('ozPassportCountryBirth') : null;
    }.property('photoId', 'ozPassportCountryBirth'),

    ozPassportPlaceBirthRe: function () {
        return this.get('photoId') === 'AP'? this.get('ozPassportPlaceBirth'): null;
    }.property('photoId', 'ozPassportPlaceBirth'),

    ozPassportNameBirthRe: function () {
        return this.get('photoId') === 'AP'? this.get('ozPassportNameBirth') : null;
    }.property('photoId', 'ozPassportNameBirth'),

    ozPassportNumberRe: function () {
        return this.get('photoId') === 'AP' ? this.get('ozPassportNumber') : null;
    }.property('photoId', 'passportNumber'),

    passportFirstNameCitizRe:function () {
        return this.get('photoId') === 'AP' && this.get('ozPassportCountryBirth') != 'AUS' ? this.get('passportFirstNameCitiz') : null;
    }.property('photoId', 'ozPassportCountryBirth', 'passportFirstNameCitiz'),

    passportNameCitizRe: function () {
        return this.get('photoId') === 'AP' && this.get('ozPassportCountryBirth') != 'AUS' ? this.get('passportNameCitiz') : null;
    }.property('photoId', 'ozPassportCountryBirth', 'passportNameCitiz'),



    intPassportCountryRe: function () {
        return this.get('photoId') === 'IP' ? this.get('intPassportCountry') : null;
    }.property('photoId', 'intPassportCountry'),

    intPassportNumberRe: function () {
        return this.get('photoId') === 'IP' ? this.get('intPassportNumber') : null;
    }.property('photoId', 'intPassportNumber'),

    genderLong: function () {
        return AppC.genders.getName(this.get('gender'));
    }.property('gender'),

    maritalStatusLong: function () {
        return AppC.maritalStatus.getName(this.get('maritalStatus'));
    }.property('maritalStatus'),



    /**
     * Methods
     */


    getObject: function () {

        return  {
            qffNum: this.get('qffNum'),
            numOfDependants: this.get('numOfDependants'),
            gender: this.get('gender'),
            maritalStatus: this.get('maritalStatus'),
            isResident: this.get('isResident'),
            nationality: this.get('nationality'),
            licenceState: this.get('licenceStateRe'),
            licenceNumber: this.get('licenceNumberRe'),
            photoId: this.get('photoId'),
            ozPassportCountryBirth: this.get('ozPassportCountryBirthRe'),
            ozPassportPlaceBirth: this.get('ozPassportPlaceBirthRe'),
            ozPassportNameBirth: this.get('ozPassportNameBirthRe'),
            passportNameCitiz: this.get('passportNameCitizRe'),
            ozPassportNumber: this.get('ozPassportNumberRe'),
            intPassportNumber: this.get('intPassportNumberRe'),
            intPassportCountry: this.get('intPassportCountryRe'),
            passportFirstNameCitiz: this.get('passportFirstNameCitizRe'),
            licenceExpiryDate: this.get('licenceExpiryDateRe'),
            licenceCardNumber: this.get('licenceCardNumberRe'),
            licencePostCode: this.get('licencePostCode'),
            passportState: this.get('passportState'),
            isAltPhotoId: this.get('isAltPhotoId')
        };

    }


});


AppC.step3Data = AppC.Step3Data.create();
