/*****************************************************************************
 * MODEL Select Product
 *****************************************************************************/


AppC.FinalizeExistingData = AppC.Model.extend({


    /**
     * Properties
     */

	consentsToElectronic:false,
	addonDeclarationPrivacyConsent:false,
	cardHolderName:null,
	cardNumber:null,	
	cardExpiry:null,
	cardCvv:null,
	dob:null,
	
	isApproved:false,
	applicationId:null,
	authorisationNumber:null,
	merchantTxnNumber:null,
	redirectUrl:null,
	errorCode:null,
	errorMessage:null,

    getObject: function () {
        return {
            consentsToElectronic: this.get('consentsToElectronic'),
            addonDeclarationPrivacyConsent: this.get('addonDeclarationPrivacyConsent'),
            cardHolderName: this.get('cardHolderName'),
            cardNumber: this.get('cardNumber'),
            cardExpiry: this.get('cardExpiry'),
            cardCvv: this.get('cardCvv'),
			dob:this.get('dob'),
			isApproved:this.get('isApproved'),
			applicationId:this.get('applicationId'),
			authorisationNumber:this.get('authorisationNumber'),
			merchantTxnNumber:this.get('merchantTxnNumber'),
			redirectUrl:this.get('redirectUrl'),
			errorCode:this.get('errorCode'),
			errorMessage:this.get('errorMessage')
        };
    }

});


AppC.finalizeExistingData = AppC.FinalizeExistingData.create();
