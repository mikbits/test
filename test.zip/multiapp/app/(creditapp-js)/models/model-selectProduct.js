/*****************************************************************************
 * MODEL Select Product
 *****************************************************************************/


AppC.SelectProductData = AppC.Model.extend({


    /**
     * Properties
     */


    estimatedFinanceAmount: null,
    customerAtMerchantStore: true,
    customerAtState: null,
    storeId: null,
    staffId: null,
    branchId: null,

	estimatedFinanceAmount: null,
    customerAtMerchantStore: true,
    customerAtState: null,
    storeId: null,
    staffId: null,
    branchId: null,
    claimAusResident: false,
    claimOver18: false,
    claimIncomeOver20k: false,
    claimGoodCreditHistory: false,
    electronicAccepted: false,
    declarationPrivacyConsent: false,
    tcAcknowledge: false,
    hsbcRedirectAgree: false,
    productCode: "T",
	
    storeIdRe: function () {
        return this.get('customerAtMerchantStore') ? this.get('storeId') : null;
    }.property('customerAtMerchantStore', 'storeId'),

    getObject: function () {
        return {
            estimatedFinanceAmount: this.get('estimatedFinanceAmount'),
            customerAtMerchantStore: this.get('customerAtMerchantStore'),
            storeId: this.get('storeIdRe'),
            staffId: this.get('staffId'),
            branchId: this.get('branchId'),
            customerAtState: this.get('customerAtState'),

			claimAusResident:this.get('claimAusResident'),
			claimOver18:this.get('claimOver18'),
			claimIncomeOver20k:this.get('claimIncomeOver20k'),
			claimGoodCreditHistory:this.get('claimGoodCreditHistory'),	
			electronicAccepted:this.get('electronicAccepted'),
			declarationPrivacyConsent:this.get('declarationPrivacyConsent'),
			tcAcknowledge:this.get('tcAcknowledge'),
			hsbcRedirectAgree:this.get('hsbcRedirectAgree'),
			productCode:this.get('productCode')
        };
    }

});


AppC.selectProductData = AppC.SelectProductData.create();
