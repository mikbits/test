/*****************************************************************************
 * MODEL Step 1
 *****************************************************************************/


AppC.Step1Data = AppC.Model.extend({


    /**
     * Properties
     */

    currentDate: '',
    threeYearsLater: '',
    productName: '',

    // First applicant
    title: null,
    firstName: null,
    middleName: null,
    lastName: null,
    birthDate: null,
    homePhone: null,
    mobilePhone: null,
    email: null,
    emailConfirm: null,
    maidenName: null,
    agreesPolicy: false,

    // Card Attributes
    incomeReF: null,
    minCreditF: null,
    maxCreditF: null,
    annualFeeF: null,

    // Woolworths only
    isBlack: true,
    isBlue: false,
    isPink: false,
    isGreen: false,

    loanRate: null,
    loanAmtBinding: 'AppC.loanAmt',
    loanPurposeBinding: 'AppC.loanPurpose',
    loanOtherPurposeBinding: 'AppC.loanOtherPurpose',
    loanTermBinding: 'AppC.loanTerm',
    repaymentAdjustBinding: 'AppC.repaymentAdjust',

    isShowSel: null,

    isNew: null,
    isConsolidate: null,
    /**
     * Computed properties
     */

    productNameChanged: function() {
        if (AppC.get('productName')) {
            $(document).attr('title', AppC.get('productName'));
        }
    }.observes('AppC.productName'),


    /**
     * Computed properties for back end
     */


    homePhoneRe: function () {
        var value = this.get('homePhone') ? this.get('homePhone') : '';
        return value.replace(/\-/g, '');
    }.property('homePhone'),


    mobilePhoneRe: function () {
        var value = this.get('mobilePhone') ? this.get('mobilePhone') : '';
        return value.replace(/\-/g, '');
    }.property('mobilePhone'),

    cardColour: null,
    cardColourOb: function () {

        if (AppC.isWoolworths) {

            if (this.isBlack) {
                this.set('cardColour', '0001');
                return;
            }

            if (this.isGreen) {
                this.set('cardColour', '0002');
                return;
            }

            if (this.isBlue) {
                this.set('cardColour', '0003');
                return;
            }

            if (this.isPink) {
                this.set('cardColour', '0004');
                return;
            }

        }

        return null;

    }.observes('isBlack', 'isGreen', 'isBlue', 'isPink', 'AppC.isWoolworths'),

    changeImage: function () {

        var pathPrefix = './images/';

        if (AppC.isWoolworths) {

            if (this.isBlack) {
                AppC.set('imgFileName', pathPrefix + 'cardBlack.png');
                return;
            }

            if (this.isGreen) {
                AppC.set('imgFileName', pathPrefix + 'cardGreen.png');
                return;
            }

            if (this.isBlue) {
                AppC.set('imgFileName', pathPrefix + 'cardBlue.png');
                return;
            }

            if (this.isPink) {
                AppC.set('imgFileName', pathPrefix + 'cardPink.png');
                return;
            }

        }

    }.observes('isBlack', 'isGreen', 'isBlue', 'isPink', 'AppC.isWoolworths'),

    loanOtherPurposeRe: function () {
        return this.get('loanPurpose') == 'OO' ? this.get('loanOtherPurpose') : null;
    }.property('loanPurpose', 'loanOtherPurpose'),

    /**
     * Other computed properties
     */

    getObject: function () {

        var obj = {
            title: this.get('title'),
            firstName: this.get('firstName'),
            middleName: this.get('middleName'),
            lastName: this.get('lastName'),
            email: this.get('email'),
            emailConfirm: this.get('emailConfirm'),
            homePhone: this.get('homePhoneRe'),
            mobilePhone: this.get('mobilePhoneRe'),
            birthDate: this.get('birthDate'),
            maidenName: this.get('maidenName'),
            agreesPolicy: this.get('agreesPolicy')
        };

        if (parseInt(AppC.organizationCode, 10) === 300) {
            obj.cardColour = this.get('cardColour');
        }

        if (AppC.logo === 'W') {
            obj.loanAmt = this.get('loanAmt');
            obj.loanPurpose = this.get('loanPurpose');

            switch (obj.loanPurpose) {
                case '1':
                    obj.loanPurpose = (this.get('isNew') ? 'NC': 'UC');
                    break
                case '2':
                    obj.loanPurpose = (this.get('isNew') ? 'NB': 'UB');
                    break
                case '7':
                    obj.loanPurpose = (this.get('isConsolidate') ? 'RH': 'DC');
                    break
            }

            if(this.get('loanPurpose') == 'OO') {
                obj.loanOtherPurpose = this.get('loanOtherPurposeRe');
            }

            obj.loanTerm = this.get('loanTerm');
            obj.loanRate = this.get('loanRate');
        }

        return obj;

    },

    // Observers

    changeCardAttr: function () {

        var formatFn = AppC.StepController.prototype.formatCurrency,
            _this = this;

        if (typeof formatFn !== 'function') {
            setTimeout(function () {
                _this.changeCardAttr();
            }, 500);
            return;
        }

        var obj = {
            incomeReF: formatFn(AppC.incomeRe),
            minCreditF: formatFn(AppC.minCredit),
            maxCreditF: formatFn(AppC.maxCredit),
            annualFeeF: formatFn(AppC.annualFee)
        };

       this.set('incomeReF', obj.incomeReF);
       this.set('minCreditF', obj.minCreditF);
       this.set('maxCreditF', obj.maxCreditF);
       this.set('annualFeeF', obj.annualFeeF);

    }.observes('AppC.incomeRe', 'AppC.minCredit', 'AppC.maxCredit', 'AppC.annualFee'),

    changeWWImg: function () {

        var pathPrefix = './images/';

        if (!this.get('cardColour')) {
            return;
        }

        switch (this.get('cardColour')) {

            // black, green, blue, pink

            case '0001':
            AppC.set('imgFileName', pathPrefix + 'cardBlack.png');
            break;

            case '0002':
            AppC.set('imgFileName', pathPrefix + 'cardGreen.png');
            break;

            case '0003':
            AppC.set('imgFileName', pathPrefix + 'cardBlue.png');
            break;

            case '0004':
            AppC.set('imgFileName', pathPrefix + 'cardPink.png');
            break;

        }

    }.observes('cardColour'),

    purposeLong: function () {
       return AppC.purpose.getName(this.get('loanPurpose'));
    }.property('loanPurpose'),
    
    loanPurposeChanged: function () {
        if(this.get('loanPurpose')==='NC'){
        	this.set('isNew',true);
        	this.set('loanPurpose','1');
        }else if(this.get('loanPurpose')==='UC'){
        	this.set('isNew',false);
        	this.set('loanPurpose','1');        	
        } else if(this.get('loanPurpose')==='NB'){
        	this.set('isNew',true);
        	this.set('loanPurpose','2');
        } else if(this.get('loanPurpose')==='UB'){
        	this.set('isNew',false);
        	this.set('loanPurpose','2');	
        } else if(this.get('loanPurpose')==='RH'){
        	this.set('isConsolidate',true);
        	this.set('loanPurpose','7');
        } else if(this.get('loanPurpose')==='DC'){
        	this.set('isConsolidate',false);
        	this.set('loanPurpose','7');        	
        }
     }.observes('loanPurpose'),
     
    

    monthPay: function () {
        var amount = parseInt(this.get('loanAmt'), 10);
        var year = parseInt(this.get('loanTerm'), 10);
        var aprMonthly = parseFloat(this.get('loanRate')) * 100 / 12 / 10000;
        var estFee = 150;
        var maintFee = parseInt(this.get('repaymentAdjust'), 10);
        var repayment = '...';
        if (amount >= 5000 && amount <= 50000) {
            repayment = Math.round((((amount + estFee) * aprMonthly) / (1 - Math.pow(1 + aprMonthly, -(year)))) + maintFee);
            return this.formatCurrency(repayment);
        }
        return '...';
    }.property('loanAmt', 'loanTerm', 'loanRate', 'repaymentAdjust'),

    showYears: function () {
        return parseInt(this.get('loanTerm'), 10) / 12;
    }.property('loanTerm'),

    showRate: function () {
        return this.get('loanRate') + '%';
    }.property('loanRate')
});


AppC.step1Data = AppC.Step1Data.create();
