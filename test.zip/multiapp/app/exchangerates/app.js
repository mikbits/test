ExchangeRateApp = Ember.Application.create({
    setBusy: function () {
        $('div#busy').modal({focus: true});
        $('a.modalCloseImg').remove();
    },

    setReady: function () {
        $.modal.close();
    }

});

ExchangeRateApp.Router.map(function () {
    this.resource('exchangeRate');
    this.resource('error');
});

ExchangeRateApp.IndexRoute = Ember.Route.extend({
  redirect: function() {
    this.transitionTo('exchangeRate');
  }
});





ExchangeRateApp.ExchangeRateController = Ember.Controller.extend({
	//jsonEndPointUrl: '/cgi-bin/dummyserver.py',
	jsonEndPointUrl: '/multiapp/multiapp',
	jsonTimeOut: 60000,

	refreshExchangeRate:function(){
		var requestObject = Ember.Object.create();
        requestObject.set('cmd','getExchangeRates');

        var handleAjaxResponse=this.handleAjaxResponse;
        var handleAjaxError=this.handleAjaxError;

		var requestString=JSON.stringify(requestObject);

        $.ajax({
            url: this.get('jsonEndPointUrl'),
            type: 'post',
            contentType: 'application/json', // Type of data sent to server
            data: requestString, // data sent to server, must be string
            dataType: 'json', // Type of response received from server
            timeout: this.get('jsonTimeOut'),
            success: function (response) {
                handleAjaxResponse(requestObject, response);
                ExchangeRateApp.setReady();
            },

            error: function (jqXHR, textStatus, errorThrown) {
                handleAjaxError(textStatus);
                ExchangeRateApp.setReady();
            }

        });

	},



    handleAjaxError: function(textStatus){
    	//
    },

	handleAjaxResponse: function(request, response){
        if((typeof(response) != "undefined") && (typeof(response[0]) != "undefined")){
            response=response[0];
        }
        ExchangeRateApp.set('exchangeRateData',ExchangeRateApp.ExchangeRateData.create());
        var exchangeRateData=ExchangeRateApp.get('exchangeRateData');
        exchangeRateData.setProperties(response);
        if(response.rates){

            response.rates.forEach(function (rate) {
                var exchangeRateRecord=ExchangeRateApp.ExchangeRateRecord.create();
                exchangeRateRecord.setProperties(rate);
                exchangeRateData.exchangeRateRecords.addObject(exchangeRateRecord);
            });
        }
	}

});


ExchangeRateApp.ExchangeRateView = Ember.View.extend({

	willInsertElement: function(){
		ExchangeRateApp.setBusy();
		this.get('controller').refreshExchangeRate();
	}

});

ExchangeRateApp.ExchangeRateData = Ember.Object.extend({
	lastUpdateDateTime: null,
	exchangeRateRecords: []
});

ExchangeRateApp.exchangeRateData = ExchangeRateApp.ExchangeRateData.create();

ExchangeRateApp.ExchangeRateRecord= Ember.Object.extend({
	currencyCode: null,
	buyPrice:null,
	sellPrice:null
});



