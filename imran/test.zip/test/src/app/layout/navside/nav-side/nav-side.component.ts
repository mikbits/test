import { Component, OnInit } from '@angular/core';
import {User} from "@app/_models";
import {AccountService} from "@app/_services";

@Component({
  selector: 'app-nav-side',
  templateUrl: './nav-side.component.html',
  styleUrls: ['./nav-side.component.less']
})
export class NavSideComponent implements OnInit {
  user?: User | null;
  constructor(private accountService: AccountService) {
    this.accountService.user.subscribe(x => this.user = x);
  }

  ngOnInit(): void {
  }

}
