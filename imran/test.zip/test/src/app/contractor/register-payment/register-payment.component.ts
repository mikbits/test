import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {AlertService} from "@app/_services";
import {first} from "rxjs/operators";
import {PaymentService} from "@app/_services/payment.service";

@Component({
  selector: 'app-register-payment',
  templateUrl: './register-payment.component.html',
  styleUrls: ['./register-payment.component.less']
})
export class RegisterPaymentComponent implements OnInit {
  form!: FormGroup;
  loading = false;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private paymentService: PaymentService,
    private alertService: AlertService
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      customerName: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.minLength(10)]],
      customerAddress: ['', Validators.required],
      job: ['', Validators.required]
    });
  }
// convenience getter for easy access to form fields
  get f() { return this.form.controls; }
  onSubmit() {
    this.submitted = true;

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    }

    this.loading = true;
    this.paymentService.registerPaymentSchedule(this.form.value)
      .pipe(first())
      .subscribe({
        next: () => {
          this.alertService.success('Payment Schedule Creation successful', { keepAfterRouteChange: true });
          this.router.navigate(['../paymentSchedule'], { relativeTo: this.route });
        },
        error: error => {
          this.alertService.error(error);
          this.loading = false;
        }
      });
  }
}
