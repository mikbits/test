import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {PaymentService} from "@app/_services/payment.service";
import {first} from "rxjs/operators";
import {PaymentSchedule} from "@app/_models/paymentSchedule";

interface Transaction {
  item: string;
  cost: number;
}

@Component({
  selector: 'app-payment-schedule',
  templateUrl: './payment-schedule.component.html',
  styleUrls: ['./payment-schedule.component.less']
})
export class PaymentScheduleComponent implements OnInit {

  paymentSchedules?: any[];

  displayedColumns: string[] = ['item', 'cost'];
  transactions: Transaction[] = [
    {item: 'Beach ball', cost: 4},
    {item: 'Towel', cost: 5},
    {item: 'Frisbee', cost: 2},
    {item: 'Sunscreen', cost: 4},
    {item: 'Cooler', cost: 25},
    {item: 'Swim suit', cost: 15},
  ];
  constructor(    private router: Router,
                  private paymentService: PaymentService) { }

  ngOnInit(): void {
    this.paymentService.getAll()
      .pipe(first())
      .subscribe(paymentSchedules => {
        console.log(paymentSchedules);
        this.paymentSchedules = paymentSchedules;
      });
  }
  deletePaymentSchedule(id: string) {
    const paysch = this.paymentSchedules!.find(x => x.id === id);
    paysch.isDeleting = true;
    this.paymentService.delete(id)
      .pipe(first())
      .subscribe(() => this.paymentSchedules = this.paymentSchedules!.filter(x => x.id !== id));
  }
  navigate() {
    this.scrollToTop();
    this.router.navigate(["../registerPayment"]);
  }
  scrollToTop() {
    window.scroll(0, 0);
  }
  /** Gets the total cost of all transactions. */
  getTotalCost() {
    return this.transactions.map(t => t.cost).reduce((acc, value) => acc + value, 0);
  }
}
