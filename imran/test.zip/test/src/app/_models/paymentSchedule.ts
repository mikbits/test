﻿export class PaymentSchedule {
    id?: string;
    customerName?: string;
    customerAddress?: string;
    mobile?: string;
    job?: string;
    token?: string;
}
