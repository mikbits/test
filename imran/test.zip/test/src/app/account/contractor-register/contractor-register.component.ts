import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {AccountService, AlertService} from "@app/_services";
import {first} from "rxjs/operators";
import {ConfirmedValidator} from "@app/_helpers/confirmed.validator";

@Component({
  selector: 'app-contractor-register',
  templateUrl: './contractor-register.component.html',
  styleUrls: ['./contractor-register.component.less']
})
export class ContractorRegisterComponent implements OnInit {
  form!: FormGroup;
  loading = false;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private accountService: AccountService,
    private alertService: AlertService
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      companyName: ['', Validators.required],
      companyAbn: ['', Validators.required],
      companyAddress: ['', Validators.required],
      contactName: ['', Validators.required],
      contactAddress: ['', Validators.required],
      contactDob: ['', Validators.required],
      contactDl: ['', Validators.required],
      accName: ['', Validators.required],
      accBsb: ['', Validators.required],
      accNumber: ['', Validators.required]
    }, {
      validator: ConfirmedValidator('password', 'confirmPassword')
    });
  }
// convenience getter for easy access to form fields
  get f() { return this.form.controls; }

  onSubmit() {
    this.submitted = true;

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    }

    this.loading = true;
    this.accountService.register(this.form.value)
      .pipe(first())
      .subscribe({
        next: () => {
          this.alertService.success('Registration successful', { keepAfterRouteChange: true });
          this.router.navigate(['../login'], { relativeTo: this.route });
        },
        error: error => {
          this.alertService.error(error);
          this.loading = false;
        }
      });
  }
}
