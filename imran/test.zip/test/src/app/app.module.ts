﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AppRoutingModule } from './app-routing.module';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AppComponent } from './app.component';
import { AlertComponent } from './_components';
import { HomeComponent } from './home';
import { LandingComponent } from './landing/landing/landing.component';
import { ContractorHomeComponent } from './contractor-home/contractor-home.component';
import { NavTopComponent } from './layout/navtop/nav-top/nav-top.component';
import { NavSideComponent } from './layout/navside/nav-side/nav-side.component';
import { ProfileComponent } from './contractor/profile/profile.component';
import { PaymentScheduleComponent } from './contractor/payment-schedule/payment-schedule.component';
import { ManageUsersComponent } from './contractor/manage-users/manage-users.component';
import { RegisterPaymentComponent } from './contractor/register-payment/register-payment.component';
import {MatTableModule} from "@angular/material/table";

@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        AppRoutingModule,
        MatTableModule
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent,
        LandingComponent,
        ContractorHomeComponent,
        NavTopComponent,
        NavSideComponent,
        ProfileComponent,
        PaymentScheduleComponent,
        ManageUsersComponent,
        RegisterPaymentComponent
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})
export class AppModule { };
