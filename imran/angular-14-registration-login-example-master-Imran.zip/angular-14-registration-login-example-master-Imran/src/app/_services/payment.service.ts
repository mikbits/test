﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '@environments/environment';
import { User } from '@app/_models';
import {PaymentSchedule} from "@app/_models/paymentSchedule";
import {Payment} from "@app/_models/payment";

@Injectable({ providedIn: 'root' })
export class PaymentService {
    private userSubject: BehaviorSubject<User | null>;
    public user: Observable<User | null>;

    private paymentScheduleSubject: BehaviorSubject<PaymentSchedule | null>;
    public paymentSchedule: Observable<PaymentSchedule | null>;

    constructor(
        private router: Router,
        private http: HttpClient
    ) {
        this.userSubject = new BehaviorSubject(JSON.parse(localStorage.getItem('user')!));
        this.user = this.userSubject.asObservable();

        this.paymentScheduleSubject = new BehaviorSubject(JSON.parse(localStorage.getItem('cpay-payschs')!));
        this.paymentSchedule = this.userSubject.asObservable();
    }

    public get userValue() {
        return this.userSubject.value;
    }

    public get paymentScheduleValue() {
      return this.paymentScheduleSubject.value;
    }

    registerPaymentSchedule(paymentSchedule: PaymentSchedule) {
        return this.http.post(`${environment.apiUrl}/registerPaymentSchedule`, paymentSchedule);
    }

    updatePaymentSchedule(id:String, paymentSchedule: PaymentSchedule) {
      return this.http.put(`${environment.apiUrl}/payschs/${id}`, paymentSchedule);
    }


    addPayment(payment: Payment) {
      return this.http.post<Payment>(`${environment.apiUrl}/addPayment`, payment);
    }
    updatePayment(payment: Payment) {
      return this.http.post(`${environment.apiUrl}/updatePayment`, payment);
    }
    deletePayment(id: number): Observable<Payment> {
      return this.http.delete<Payment>(`${environment.apiUrl}/${id}`);
    }

    getAll() {
        return this.http.get<PaymentSchedule[]>(`${environment.apiUrl}/payschs`);
    }

    getById(id: string) {
        return this.http.get<PaymentSchedule>(`${environment.apiUrl}/payschs/${id}`);
    }

    update(id: string, params: any) {
        return this.http.put(`${environment.apiUrl}/payschs/${id}`, params)
            .pipe(map(x => {
                // update stored user if the logged in user updated their own record
                if (id == this.userValue?.id) {
                    // update local storage
                    const user = { ...this.userValue, ...params };
                    localStorage.setItem('user', JSON.stringify(user));

                    // publish updated user to subscribers
                    this.userSubject.next(user);
                }
                return x;
            }));
    }

    delete(id: string) {
        return this.http.delete(`${environment.apiUrl}/payschs/${id}`)
            .pipe(map(x => {
                return x;
            }));
    }
}
