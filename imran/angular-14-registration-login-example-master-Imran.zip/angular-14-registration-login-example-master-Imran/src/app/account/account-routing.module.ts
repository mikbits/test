import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout.component';
import { LoginComponent } from './login.component';
import { RegisterComponent } from './register.component';
import {ContractorLoginComponent} from "@app/account/contractor-login/contractor-login.component";
import {ContractorRegisterComponent} from "@app/account/contractor-register/contractor-register.component";
import {CustomerLoginComponent} from "@app/account/customer/customer-login/customer-login.component";

const routes: Routes = [
    {
        path: '', component: LayoutComponent,
        children: [
            { path: 'login', component: LoginComponent },
            { path: 'register', component: RegisterComponent },
            { path: 'contractor-login', component: ContractorLoginComponent },
            { path: 'contractor-register', component: ContractorRegisterComponent },
            { path: 'customer-login', component: CustomerLoginComponent, pathMatch: 'full' },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AccountRoutingModule { }
