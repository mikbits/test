import { Component, OnInit } from '@angular/core';
import {Customer} from "@app/_models/customer";
import {AccountService} from "@app/_services";

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.less']
})
export class CustomerHomeComponent implements OnInit {
  customer: Customer | null;
  constructor(private accountService: AccountService) {
    this.customer = this.accountService.customerValue;
  }

  ngOnInit(): void {
  }

}
