import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {PaymentService} from "@app/_services/payment.service";
import {CustomerPaymentService} from "@app/_services/customerPayment.service";
import {first} from "rxjs/operators";

@Component({
  selector: 'app-customer-payment-schedule',
  templateUrl: './customer-payment-schedule.component.html',
  styleUrls: ['./customer-payment-schedule.component.less']
})
export class CustomerPaymentScheduleComponent implements OnInit {
  customerPaymentSchedules?: any[];
  constructor(private router: Router,
              private paymentService: PaymentService,
              private customerPaymentService: CustomerPaymentService) { }

  ngOnInit(): void {
    this.customerPaymentService.getAll()
      .pipe(first())
      .subscribe(customerPaymentSchedules => {
        console.log(customerPaymentSchedules);
        this.customerPaymentSchedules = customerPaymentSchedules;
      });
  }

}
