import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPaymentScheduleComponent } from './customer-payment-schedule.component';

describe('CustomerPaymentScheduleComponent', () => {
  let component: CustomerPaymentScheduleComponent;
  let fixture: ComponentFixture<CustomerPaymentScheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerPaymentScheduleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerPaymentScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
