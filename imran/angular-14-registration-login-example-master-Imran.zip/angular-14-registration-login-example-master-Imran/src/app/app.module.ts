﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AppRoutingModule } from './app-routing.module';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AppComponent } from './app.component';
import { AlertComponent } from './_components';
import { HomeComponent } from './home';
import { LandingComponent } from './landing/landing/landing.component';
import { ContractorHomeComponent } from './contractor-home/contractor-home.component';
import { NavTopComponent } from './layout/navtop/nav-top/nav-top.component';
import { NavSideComponent } from './layout/navside/nav-side/nav-side.component';
import { ProfileComponent } from './contractor/profile/profile.component';
import { PaymentScheduleComponent } from './contractor/payment-schedule/payment-schedule.component';
import { ManageUsersComponent } from './contractor/manage-users/manage-users.component';
import { RegisterPaymentComponent } from './contractor/register-payment/register-payment.component';
import {MatTableModule} from "@angular/material/table";
import {MatInputModule} from "@angular/material/input";
import {MatButtonModule} from "@angular/material/button";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatNativeDateModule} from "@angular/material/core";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {MatDialogModule} from "@angular/material/dialog";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { AddPaymentComponent } from './contractor/add-payment/add-payment.component';
import {CustomerHomeComponent} from "@app/account/customer/customer-home/customer-home.component";

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        HttpClientModule,
        AppRoutingModule,
        MatTableModule,
        MatInputModule,
        MatButtonModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatCheckboxModule,
        MatDialogModule,
        FormsModule
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent,
        LandingComponent,
        ContractorHomeComponent,
        NavTopComponent,
        NavSideComponent,
        ProfileComponent,
        PaymentScheduleComponent,
        ManageUsersComponent,
        RegisterPaymentComponent,
        AddPaymentComponent,
        CustomerHomeComponent
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})
export class AppModule { };
