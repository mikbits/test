﻿import { Component } from '@angular/core';

import { AccountService } from './_services';
import { User } from './_models';
import {Customer} from "@app/_models/customer";

@Component({ selector: 'app-root', templateUrl: 'app.component.html' })
export class AppComponent {
    user?: User | null;
    customer?: Customer | null;

    constructor(private accountService: AccountService) {
        this.accountService.user.subscribe(x => this.user = x);
        this.accountService.customer.subscribe(x => this.customer = x);
    }

    logout() {
        this.accountService.logout();
    }
    logoutCustomer() {
      this.accountService.logoutCustomer();
    }
}
