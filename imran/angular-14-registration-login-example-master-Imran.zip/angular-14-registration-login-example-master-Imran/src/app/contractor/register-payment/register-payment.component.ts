import { Component, OnInit } from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {AlertService} from "@app/_services";
import {first} from "rxjs/operators";
import {PaymentService} from "@app/_services/payment.service";
import {Payment, PaymentColumns} from "@app/_models/payment";
import {MatTableDataSource} from "@angular/material/table";

@Component({
  selector: 'app-register-payment',
  templateUrl: './register-payment.component.html',
  styleUrls: ['./register-payment.component.less']
})
export class RegisterPaymentComponent implements OnInit {
  form!: FormGroup;
  loading = false;
  submitted = false;

  displayedColumns: string[] = PaymentColumns.map((col) => col.key)
  columnsSchema: any = PaymentColumns
  dataSource = new MatTableDataSource<Payment>()
  valid: any = {}
  id?: string;
  formTableData !:FormArray<any>;
  total?: number;

  // Initial rows
  initialRows: Payment[] = [
    {
      id: 0,
      firstName: '',
      lastName: '',
      email: '',
      birthDate: '',
      isEdit: true,
      isSelected: false,
    }
  ];

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private paymentService: PaymentService,
    private alertService: AlertService
  ) {
    //this.dataSource.data = this.initialRows;
  }

  ngOnInit(): void {
    this.total=0;
    this.id = this.route.snapshot.params['id'];

    this.form = this.formBuilder.group({
      customerName: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.minLength(10)]],
      customerAddress: ['', Validators.required],
      job: ['', Validators.required],
      tableData: this.formBuilder.array([])
    });

    if (this.id) {
      this.paymentService.getById(this.id).subscribe((result: any) => {
        //this.tableData = result.tableData;
        if(result.tableData != null) {
          this.total=0;
          for(let i=0;i<result.tableData.length;i++) {
            this.addPayment();
            this.total += parseInt(result.tableData[i].amount);
          }
        }
       this.form.setValue({
          id:result.id,
          customerName:result.customerName,
          mobile:result.mobile,
          customerAddress:result.customerAddress,
          job:result.job,
          tableData: result.tableData,
        });
      });

      // edit mode
      this.loading = true;
      this.paymentService.getById(this.id)
        .pipe(first())
        .subscribe(x => {
          this.form.patchValue(x);
          this.loading = false;
        });
    }
  }
// convenience getter for easy access to form fields
  get f() { return this.form.controls; }
  onSubmit() {
    console.log(this.form.value)
    this.submitted = true;

    // reset alerts on submit
    this.alertService.clear();

    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    }

    this.loading = true;
    this.savePaymentSchedule()
      .pipe(first())
      .subscribe({
        next: () => {
          this.alertService.success('Payment Schedule saved', { keepAfterRouteChange: true });
          this.router.navigate(['/paymentSchedule'], { relativeTo: this.route });
        },
        error: error => {
          this.alertService.error(error);
          this.loading = false;
        }
      });
  }

  private savePaymentSchedule() {
    // create or update user based on id param
    return this.id
      ? this.paymentService.updatePaymentSchedule(this.id!, this.form.getRawValue())
      : this.paymentService.registerPaymentSchedule(this.form.getRawValue());
  }
  addPayment() {
    this.formTableData = this.form.get("tableData") as FormArray;
    this.formTableData.push(this.generateRow());
  }
  generateRow() {
    return this.formBuilder.group({
      payid: this.formBuilder.control({value:0, disabled:true}),
      isactive: this.formBuilder.control(false),
      startDate: this.formBuilder.control(''),
      finishDate: this.formBuilder.control(''),
      amount: this.formBuilder.control(''),
    });
  }
  get tableData() {
    return this.form.get("tableData") as FormArray;
  }
  removePayment(index:any) {
    this.formTableData = this.form.get("tableData") as FormArray;
    this.formTableData.removeAt(index);
  }

  addRow() {
    const newRow: Payment = {
      id: 0,
      firstName: '',
      lastName: '',
      email: '',
      birthDate: '',
      isEdit: true,
      isSelected: false,
    }
    this.dataSource.data = [newRow, ...this.dataSource.data];
    return false;
  }

  removeSelectedRows() {

  }

  editRow(row: Payment) {
    if (row.id === 0) {
      this.paymentService.addPayment(row).subscribe((newPayment: Payment) => {
        row.id = newPayment.id
        row.isEdit = false
      })
    } else {
      this.paymentService.updatePayment(row).subscribe(() => (row.isEdit = false))
    }
  }
  isAllSelected() {
    return this.dataSource.data.every((item) => item.isSelected)
  }

  isAnySelected() {
    return this.dataSource.data.some((item) => item.isSelected)
  }

  selectAll(event: any) {
    this.dataSource.data = this.dataSource.data.map((item) => ({
      ...item,
      isSelected: event.checked,
    }))
  }
  removeRow(id: number) {
    this.paymentService.deletePayment(id).subscribe(() => {
      this.dataSource.data = this.dataSource.data.filter(
        (u: Payment) => u.id !== id,
      )
    })
  }
  inputHandler(e: any, id: number, key: string) {
    if (!this.valid[id]) {
      this.valid[id] = {}
    }
    this.valid[id][key] = e.target.validity.valid
  }

  disableSubmit(id: number) {
    if (this.valid[id]) {
      return Object.values(this.valid[id]).some((item) => item === false)
    }
    return false
  }

  // payment
  /*
  editRow(row: User) {
    if (row.id === 0) {
      this.userService.addUser(row).subscribe((newUser: User) => {
        row.id = newUser.id
        row.isEdit = false
      })
    } else {
      this.userService.updateUser(row).subscribe(() => (row.isEdit = false))
    }
  }

  addRow() {
    const newRow: User = {
      id: 0,
      firstName: '',
      lastName: '',
      email: '',
      birthDate: '',
      isEdit: true,
      isSelected: false,
    }
    this.dataSource.data = [newRow, ...this.dataSource.data]
  }

  removeRow(id: number) {
    this.userService.deleteUser(id).subscribe(() => {
      this.dataSource.data = this.dataSource.data.filter(
        (u: User) => u.id !== id,
      )
    })
  }

  removeSelectedRows() {
    const users = this.dataSource.data.filter((u: User) => u.isSelected)
    this.dialog
      .open(ConfirmDialogComponent)
      .afterClosed()
      .subscribe((confirm) => {
        if (confirm) {
          this.userService.deleteUsers(users).subscribe(() => {
            this.dataSource.data = this.dataSource.data.filter(
              (u: User) => !u.isSelected,
            )
          })
        }
      })
  }

  inputHandler(e: any, id: number, key: string) {
    if (!this.valid[id]) {
      this.valid[id] = {}
    }
    this.valid[id][key] = e.target.validity.valid
  }

  disableSubmit(id: number) {
    if (this.valid[id]) {
      return Object.values(this.valid[id]).some((item) => item === false)
    }
    return false
  }

  isAllSelected() {
    return this.dataSource.data.every((item) => item.isSelected)
  }

  isAnySelected() {
    return this.dataSource.data.some((item) => item.isSelected)
  }

  selectAll(event: any) {
    this.dataSource.data = this.dataSource.data.map((item) => ({
      ...item,
      isSelected: event.checked,
    }))
  }
  */

}
