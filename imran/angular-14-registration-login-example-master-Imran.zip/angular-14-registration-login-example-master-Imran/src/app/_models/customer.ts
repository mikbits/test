﻿export class Customer {
    id?: string;
    customerName?: string;
    customerId?: string;
    customerAddress?: string;
    mobile?: string;
    job?: string;
    token?: string;
}
