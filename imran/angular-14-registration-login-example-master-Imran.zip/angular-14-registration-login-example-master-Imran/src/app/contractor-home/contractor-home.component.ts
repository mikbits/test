import { Component, OnInit } from '@angular/core';
import {User} from "@app/_models";
import {AccountService} from "@app/_services";

@Component({
  selector: 'app-contractor-home',
  templateUrl: './contractor-home.component.html',
  styleUrls: ['./contractor-home.component.less']
})
export class ContractorHomeComponent implements OnInit {
  user: User | null;

  constructor(private accountService: AccountService) {
    this.user = this.accountService.userValue;
  }

  ngOnInit(): void {
  }

}
