import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AuthGuard} from './_helpers';
import {LandingComponent} from "@app/landing/landing/landing.component";
import {ContractorHomeComponent} from "@app/contractor-home/contractor-home.component";
import {PaymentScheduleComponent} from "@app/contractor/payment-schedule/payment-schedule.component";
import {RegisterPaymentComponent} from "@app/contractor/register-payment/register-payment.component";
import {CustomerHomeComponent} from "@app/account/customer/customer-home/customer-home.component";

const accountModule = () => import('./account/account.module').then(x => x.AccountModule);
const usersModule = () => import('./users/users.module').then(x => x.UsersModule);

const routes: Routes = [
    { path: '', component: ContractorHomeComponent, canActivate: [AuthGuard] },
    { path: 'users', loadChildren: usersModule, canActivate: [AuthGuard] },
    { path: 'account', loadChildren: accountModule },
    { path: 'landing', component: LandingComponent },
    { path: 'manageUsers', loadChildren: usersModule, canActivate: [AuthGuard] },
    { path: 'paymentSchedule', component: PaymentScheduleComponent, canActivate: [AuthGuard] },
    { path: 'registerPaymentSchedule', component: RegisterPaymentComponent, canActivate: [AuthGuard] },
    { path: 'paymentSchedule/edit/:id', component: RegisterPaymentComponent, pathMatch: 'full', canActivate: [AuthGuard] },
    { path: 'customer', component: CustomerHomeComponent, canActivate: [AuthGuard] },

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
